import argparse
from pathlib import Path
from .common import load_manifest, new_directory, write_json, write_jsonl


def inventory(args):
    """Explicit Layer/label layout only. Unknown identity fields stay blank."""
    root = Path(args.root).resolve()
    if not root.is_dir():
        raise ValueError('Root does not exist')
    files = sorted(p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff'})
    if not files:
        raise ValueError('No images found')
    rows, taxonomy = [], {}
    for number, path in enumerate(files):
        parts = path.relative_to(root).parts
        if len(parts) < 3:
            raise ValueError('Expected root/Layer/machine_label/.../image')
        layer, label = parts[:2]
        taxonomy.setdefault(layer, set()).add(label)
        rows.append({'sample_id': f'image_{number:08d}', 'case_id': '', 'group_id': '',
                     'layer': layer, 'machine_label': label, 'view': '', 'domain': '',
                     'split': 'unassigned', 'image_path': str(path), 'reference_source': 'historical'})
    output = new_directory(args.output)
    write_jsonl(output / 'manifest_DRAFT.jsonl', rows)
    write_json(output / 'taxonomy_DRAFT.json', {k: sorted(v) for k, v in taxonomy.items()})
    print('Draft only: fill case/group/view/domain/split and review taxonomy before validate.')
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description='SEM machine-label audit experiments; offline, no automatic relabeling')
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('inventory', help='Draft inventory for root/Layer/label/images')
    p.add_argument('--root', required=True)
    p.add_argument('--output', required=True)
    p = sub.add_parser('validate', help='Validate manifest, image files, ROI and split leakage')
    p.add_argument('--manifest', required=True)
    p = sub.add_parser('extract', help='Extract frozen HF DINOv3 features, no training')
    p.add_argument('--manifest', required=True)
    p.add_argument('--model-dir', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--size', type=int, default=512)
    p.add_argument('--batch-size', type=int, default=8)
    p.add_argument('--device', default='cuda')
    p.add_argument('--normalization', choices=['lvd', 'sat'], default='lvd')
    p.add_argument('--pooling', choices=['cls', 'cls_patch_mean_max'], default='cls')
    p.add_argument('--input-mode', choices=['full', 'roi'], default='full')
    p = sub.add_parser('score', help='Evaluate original labels against same-Layer references')
    p.add_argument('--cache', required=True)
    p.add_argument('--taxonomy', required=True)
    p.add_argument('--config')
    p.add_argument('--split', choices=['reference', 'dev', 'test', 'production'], default='dev')
    p.add_argument('--output', required=True)
    p = sub.add_parser('evaluate', help='Compare scores to separate human labels')
    p.add_argument('--scores', required=True)
    p.add_argument('--labels', required=True)
    p.add_argument('--sampling', choices=['diagnostic', 'representative'], default='diagnostic')
    p.add_argument('--view', choices=['I00', 'I02', 'I03', 'I04', 'fused'], help='Filter before evaluation; fused_scores is recommended')
    p.add_argument('--output', required=True)
    p = sub.add_parser('demo', help='Run synthetic feature smoke test without torch/GPU; not SEM accuracy')
    p.add_argument('--output', required=True)
    args = parser.parse_args(argv)
    if args.command == 'inventory':
        result = inventory(args)
    elif args.command == 'validate':
        rows = load_manifest(args.manifest)
        result = f'Validated {len(rows)} images; group and exact-pixel cross-split checks passed'
    elif args.command == 'extract':
        from .features import extract
        result = extract(args)
    elif args.command == 'score':
        from .retrieval import score
        result = score(args)
    elif args.command == 'evaluate':
        from .evaluation import evaluate
        result = evaluate(args)
    else:
        from .demo import demo
        result = demo(args.output)
    print(result)


if __name__ == '__main__':
    main()
