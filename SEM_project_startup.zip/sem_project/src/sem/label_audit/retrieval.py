"""Exact cosine kNN evidence with group deduplication and explicit abstention."""
from collections import Counter, defaultdict
import json
from pathlib import Path
import numpy as np
from .common import load_cache, new_directory, sha256, write_json, write_jsonl

DEFAULTS = {'k': [5, 10, 20], 'min_similarity': 0.5, 'min_neighbors': 5,
            'min_class_references': 3, 'support_fraction': 0.6,
            'review_margin': 0.2, 'reference_mode': 'all', 'exclude_same_batch': False,
            'views': ['I02', 'I03', 'I04'],
            'threshold_status': 'exploratory_not_validated'}

REASONS_ZH = {'original_label_not_in_taxonomy': '原标签不在该Layer类别字典中',
              'original_class_reference_shortage': '原类别独立参考数量不足',
              'too_few_similar_independent_references': '达到相似度门槛的独立参考不足',
              'layer_class_coverage_incomplete': '该Layer部分候选类别参考不足',
              'neighborhood_ambiguous': '近邻对不同类别的支持未拉开差距'}


def config_from(path):
    config = dict(DEFAULTS)
    if path:
        supplied = json.loads(Path(path).read_text(encoding='utf-8-sig'))
        unknown = set(supplied) - set(config)
        if unknown:
            raise ValueError(f'Unknown config keys: {unknown}')
        config.update(supplied)
    if (not isinstance(config['k'], list) or not config['k'] or
            any(type(k) is not int or k < 1 for k in config['k']) or len(set(config['k'])) != len(config['k'])):
        raise ValueError('k must contain distinct positive integers')
    if any(type(config[k]) is not int or config[k] < 1 for k in ('min_neighbors', 'min_class_references')):
        raise ValueError('Minimum counts must be positive integers')
    if config['min_neighbors'] > min(config['k']):
        raise ValueError('min_neighbors cannot exceed smallest k')
    if not -1 <= config['min_similarity'] <= 1 or not .5 < config['support_fraction'] <= 1 or not 0 < config['review_margin'] <= 1:
        raise ValueError('Invalid score thresholds')
    if config['reference_mode'] not in {'all', 'historical', 'expert'} or type(config['exclude_same_batch']) is not bool:
        raise ValueError('Invalid reference policy')
    if (not isinstance(config['views'], list) or not config['views'] or
            len(set(config['views'])) != len(config['views']) or
            any(v not in {'I00', 'I02', 'I03', 'I04'} for v in config['views'])):
        raise ValueError('views must be a nonempty unique list of supported views')
    return config


def ref_label(row):
    return row['reference_label'] if row['reference_source'] == 'expert' else row['machine_label']


def key(row):
    return row['layer'], row['view'], row['domain']


def audit(rows, features, taxonomy, config, split):
    banks = defaultdict(list)
    bank_labels = {}
    for i, row in enumerate(rows):
        if row['layer'] not in taxonomy:
            raise ValueError(f'Layer missing from taxonomy: {row["layer"]}')
        if config['exclude_same_batch'] and not row.get('batch_id'):
            raise ValueError('exclude_same_batch requires batch_id on all records')
        if row['split'] != 'reference' or row['view'] not in config['views']:
            continue
        if config['reference_mode'] != 'all' and row['reference_source'] != config['reference_mode']:
            continue
        label = ref_label(row)
        if label not in taxonomy[row['layer']]:
            raise ValueError(f'Reference label not in taxonomy: {label}')
        group_key = (row['layer'], row['group_id'])
        previous = bank_labels.setdefault(group_key, label)
        if previous != label:
            raise ValueError('Reference group has conflicting labels; resolve it or run separate banks')
        banks[key(row)].append(i)
    queries = [i for i, row in enumerate(rows) if row['split'] == split and row['view'] in config['views']]
    if not queries:
        raise ValueError(f'No queries in split {split}')
    for qi in queries:
        q = rows[qi]
        # Only same Layer AND detector view AND acquisition domain are comparable.
        indices = banks.get(key(q), [])
        eligible = [i for i in indices if rows[i]['group_id'] != q['group_id'] and
                    rows[i]['case_id'] != q['case_id'] and
                    rows[i]['pixel_sha256'] != q['pixel_sha256'] and
                    (not config['exclude_same_batch'] or rows[i]['batch_id'] != q['batch_id'])]
        # Canonical one image per group in this stratum avoids giving groups
        # with many repeated acquisitions more chances to win a max similarity.
        canonical = {}
        for i in sorted(eligible, key=lambda i: rows[i]['sample_id']):
            canonical.setdefault(rows[i]['group_id'], i)
        unique_pixels = {}
        for i in canonical.values():
            h = rows[i]['pixel_sha256']
            if h in unique_pixels and ref_label(rows[unique_pixels[h]]) != ref_label(rows[i]):
                raise ValueError('Identical reference pixels have conflicting labels')
            unique_pixels.setdefault(h, i)
        eligible = list(unique_pixels.values())
        similarities = np.clip(features[eligible] @ features[qi], -1, 1) if eligible else np.array([])
        ordered = sorted(zip(eligible, similarities), key=lambda pair: (-float(pair[1]), rows[pair[0]]['sample_id']))
        valid = [(i, float(s)) for i, s in ordered if s >= config['min_similarity']]
        coverage = Counter(ref_label(rows[i]) for i in eligible)
        expert_distances = {}
        for i, sim in ordered:
            if rows[i]['reference_source'] == 'expert':
                expert_distances.setdefault(ref_label(rows[i]), round(1 - float(sim), 6))
        for k in config['k']:
            near = valid[:k]
            counts = Counter(ref_label(rows[i]) for i, _ in near)
            n = len(near)
            support = counts[q['machine_label']] / n if n else None
            alternatives = sorted((label for label in counts if label != q['machine_label']),
                                  key=lambda label: (-counts[label], label))
            competitor = alternatives[0] if alternatives else None
            competitor_fraction = counts[competitor] / n if competitor else (0.0 if n else None)
            margin = support - competitor_fraction if n else None
            missing_classes = [label for label in taxonomy[q['layer']] if coverage[label] < config['min_class_references']]
            issues = []
            if q['machine_label'] not in taxonomy[q['layer']]:
                issues.append('original_label_not_in_taxonomy')
            if coverage[q['machine_label']] < config['min_class_references']:
                issues.append('original_class_reference_shortage')
            if n < config['min_neighbors']:
                issues.append('too_few_similar_independent_references')
            # A support verdict requires competitor coverage as well. Otherwise
            # a bank containing only the original class can falsely look perfect.
            if missing_classes:
                issues.append('layer_class_coverage_incomplete')
            if issues:
                status = 'insufficient_evidence'
            elif support >= config['support_fraction'] and margin >= config['review_margin']:
                status = 'supports_original'
            elif competitor_fraction >= config['support_fraction'] and -margin >= config['review_margin']:
                status = 'review_recommended'
            else:
                status = 'insufficient_evidence'
                issues.append('neighborhood_ambiguous')
            neighbors = [{'sample_id': rows[i]['sample_id'], 'case_id': rows[i]['case_id'],
                          'group_id': rows[i]['group_id'], 'label': ref_label(rows[i]),
                          'reference_source': rows[i]['reference_source'], 'similarity': round(s, 6),
                          'image_path': rows[i]['image_path'], 'roi_xyxy': rows[i].get('roi_xyxy')}
                         for i, s in near]
            explanation = (f'同Layer、同视图及成像域内有{n}个有效独立近邻，'
                           f'其中{counts[q["machine_label"]]}个支持原标签{q["machine_label"]}。')
            if competitor:
                explanation += f'竞争类别{competitor}获{counts[competitor]}个近邻支持。'
            if issues:
                explanation += '证据不足原因：' + '、'.join(REASONS_ZH[c] for c in issues) + '。'
            elif status == 'review_recommended':
                explanation += '建议人工复核，候选类别仅供参考，不自动改标。'
            else:
                explanation += '当前参考证据支持原标签，不代表已验证的正确概率。'
            yield {'sample_id': q['sample_id'], 'case_id': q['case_id'], 'group_id': q['group_id'],
                   'layer': q['layer'], 'view': q['view'], 'domain': q['domain'], 'split': split,
                   'machine_label': q['machine_label'], 'output_type': q['machine_label'],
                   'k_requested': k, 'effective_neighbors': n,
                   'status': status, 'consistency_score': support, 'label_correct_probability': None,
                   'class_support': {label: counts[label] / n if n else None for label in taxonomy[q['layer']]},
                   'competitor_label': competitor, 'competitor_support': competitor_fraction,
                   'support_margin': margin,
                   'suggested_label': competitor if status == 'review_recommended' else None,
                   'top_similarity': float(ordered[0][1]) if ordered else None,
                   'class_reference_counts': dict(coverage), 'undercovered_classes': missing_classes,
                   'expert_nearest_cosine_distance': expert_distances,
                   'reason_codes': issues, 'reason_zh': explanation, 'neighbors': neighbors,
                   'threshold_status': config['threshold_status']}


def score(args):
    rows, features, metadata = load_cache(args.cache)
    config = config_from(args.config)
    taxonomy = json.loads(Path(args.taxonomy).read_text(encoding='utf-8-sig'))
    if not isinstance(taxonomy, dict) or not taxonomy or any(
            not isinstance(v, list) or len(v) < 2 or len(v) != len(set(v)) or
            any(not isinstance(x, str) or not x for x in v) for v in taxonomy.values()):
        raise ValueError('taxonomy must map each Layer to at least two distinct class strings')
    output = new_directory(args.output)
    write_json(output / 'run.json', {'status': 'incomplete'})
    results = list(audit(rows, features, taxonomy, config, args.split))
    from .fusion import fuse
    fused = fuse(results, config)
    write_jsonl(output / 'scores.jsonl', results)
    write_jsonl(output / 'fused_scores.jsonl', fused)
    write_json(output / 'run.json', {'status': 'complete', 'split': args.split, 'config': config,
               'taxonomy': taxonomy, 'cache_metadata': metadata, 'scorer_sha256': sha256(__file__),
               'scores_sha256': sha256(output / 'scores.jsonl'), 'query_count': len(results) // len(config['k']),
               'fused_scores_sha256': sha256(output / 'fused_scores.jsonl'),
               'fusion_sha256': sha256(Path(__file__).with_name('fusion.py')),
               'case_count': len(fused) // len(config['k']),
               'method': 'unweighted_cosine_knn_consistency_v1_not_SimiFeat_reproduction'})
    return output
