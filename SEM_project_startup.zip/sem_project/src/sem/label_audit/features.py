"""Frozen local HF DINOv3 ViT extraction; no classifier or Qwen required."""
import hashlib
import os
from pathlib import Path
import numpy as np
from .common import load_manifest, new_directory, save_cache, sha256, write_json


def model_digest(directory):
    files = sorted(p for p in Path(directory).rglob('*') if p.is_file() and p.suffix in {'.json', '.bin', '.safetensors'})
    if not files or not any(p.suffix in {'.bin', '.safetensors'} for p in files):
        raise ValueError('Expected local HF config and weights')
    h = hashlib.sha256()
    for path in files:
        h.update(path.relative_to(directory).as_posix().encode())
        h.update(sha256(path).encode())
    return h.hexdigest()


def extract(args):
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    import torch
    import transformers
    from transformers import AutoModel
    from PIL import Image, ImageOps, __version__ as pillow_version
    if args.size <= 0 or args.size % 16 or args.batch_size <= 0:
        raise ValueError('size must be a positive multiple of 16; batch-size must be positive')
    if args.device.startswith('cuda') and not torch.cuda.is_available():
        raise RuntimeError('CUDA requested but unavailable')
    rows = load_manifest(args.manifest)
    if args.input_mode == 'roi' and any(not r.get('roi_xyxy') for r in rows):
        raise ValueError('ROI comparison requires a valid ROI for every reference AND query')
    directory = Path(args.model_dir).resolve()
    fingerprint = model_digest(directory)
    output = new_directory(args.output)
    write_json(output / 'metadata.json', {'status': 'incomplete'})
    model = AutoModel.from_pretrained(str(directory), local_files_only=True).to(args.device).eval()
    if getattr(model.config, 'model_type', '') != 'dinov3_vit':
        raise ValueError('This extractor supports HF DINOv3 ViT only; inspect config.json')
    model.requires_grad_(False)
    mean = np.array([.485, .456, .406] if args.normalization == 'lvd' else [.430, .411, .296], dtype=np.float32)
    std = np.array([.229, .224, .225] if args.normalization == 'lvd' else [.213, .156, .143], dtype=np.float32)
    features = []
    with torch.inference_mode():
        for start in range(0, len(rows), args.batch_size):
            pixels = []
            for row in rows[start:start + args.batch_size]:
                if sha256(row['image_path']) != row['source_sha256']:
                    raise ValueError('Image changed after manifest validation')
                with Image.open(row['image_path']) as im:
                    im = im.convert('RGB')
                    if args.input_mode == 'roi':
                        im = im.crop(row['roi_xyxy'])
                    im = ImageOps.pad(im, (args.size, args.size), method=Image.Resampling.BICUBIC,
                                      color=(0, 0, 0), centering=(.5, .5))
                    array = (np.array(im, dtype=np.float32) / 255.0 - mean) / std
                    pixels.append(torch.from_numpy(array.transpose(2, 0, 1).copy()))
            tokens = model(pixel_values=torch.stack(pixels).to(args.device)).last_hidden_state
            if tokens.ndim != 3:
                raise ValueError('Expected ViT [batch,tokens,hidden] output')
            pooled = tokens[:, 0]
            if args.pooling == 'cls_patch_mean_max':
                patches = tokens[:, 1 + int(model.config.num_register_tokens):]
                pooled = torch.cat([pooled, patches.mean(1), patches.amax(1)], dim=1)
            features.append(pooled.float().cpu().numpy())
            print(f'Extracted {min(start + args.batch_size, len(rows))}/{len(rows)}', flush=True)
    metadata = {'kind': 'frozen_hf_dinov3_vit', 'model_dir': str(directory),
                'model_sha256': fingerprint, 'extractor_sha256': sha256(__file__),
                'manifest_sha256': sha256(args.manifest), 'size': args.size,
                'input_mode': args.input_mode, 'pooling': args.pooling,
                'normalization': args.normalization, 'resize': 'Pillow_ImageOps.pad_BICUBIC_black_center',
                'torch_version': torch.__version__, 'transformers_version': transformers.__version__,
                'pillow_version': pillow_version, 'device': args.device,
                'note': 'Frozen pretrained weights only; model scores are not probabilities'}
    save_cache(output, rows, np.concatenate(features), metadata)
    return output
