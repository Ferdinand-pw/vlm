"""Deterministic synthetic features, deliberately NOT a DINO or SEM benchmark."""
from types import SimpleNamespace
import numpy as np
from .common import new_directory, save_cache, write_json, write_jsonl
from .retrieval import score
from .evaluation import evaluate


def demo(output):
    output = new_directory(output)
    rng = np.random.default_rng(42)
    rows, features, labels = [], [], []
    for layer in ('L_demo_1', 'L_demo_2'):
        for cls, center in [('A', [1., 0., 0.]), ('B', [0., 1., 0.])]:
            for i in range(12):
                sample = f'{layer}_{cls}_ref_{i}'
                rows.append({'sample_id': sample, 'case_id': sample, 'group_id': sample,
                             'layer': layer, 'machine_label': cls, 'view': 'I02', 'domain': 'synthetic',
                             'split': 'reference', 'image_path': 'SYNTHETIC_NO_IMAGE',
                             'pixel_sha256': sample, 'reference_source': 'historical'})
                features.append(np.array(center) + rng.normal(0, .02, 3))
        for i in range(10):
            sample = f'{layer}_query_{i}'
            true = 'A' if i < 5 else 'B'
            machine = ('B' if true == 'A' else 'A') if i in (1, 6) else true
            rows.append({'sample_id': sample, 'case_id': sample, 'group_id': sample,
                         'layer': layer, 'machine_label': machine, 'view': 'I02', 'domain': 'synthetic',
                         'split': 'dev', 'image_path': 'SYNTHETIC_NO_IMAGE',
                         'pixel_sha256': sample, 'reference_source': 'historical'})
            features.append(np.array([1., 0., 0.] if true == 'A' else [0., 1., 0.]) + rng.normal(0, .02, 3))
            labels.append({'group_id': sample, 'expert_label': true})
    # Expand to three observations of the same physical defect. Include a
    # conflicting view and a missing view to exercise fusion abstention.
    expanded_rows, expanded_features = [], []
    for row, vector in zip(rows, features):
        for view in ('I02', 'I03', 'I04'):
            if row['sample_id'].endswith('query_4') and view == 'I04':
                continue
            expanded = {**row, 'sample_id': row['sample_id'] + '_' + view,
                        'pixel_sha256': row['pixel_sha256'] + '_' + view, 'view': view}
            expanded_rows.append(expanded)
            if row['sample_id'].endswith('query_2') and view == 'I04':
                vector_view = np.array([0., 1., 0.])
            else:
                vector_view = vector
            expanded_features.append(vector_view)
    rows, features = expanded_rows, expanded_features
    cache = new_directory(output / 'features')
    save_cache(cache, rows, features, {'kind': 'synthetic_demo_not_DINO', 'seed': 42})
    write_json(output / 'taxonomy.json', {'L_demo_1': ['A', 'B'], 'L_demo_2': ['A', 'B']})
    write_jsonl(output / 'human_labels.jsonl', labels)
    score(SimpleNamespace(cache=cache, config=None, taxonomy=output / 'taxonomy.json', split='dev', output=output / 'scores'))
    evaluate(SimpleNamespace(scores=output / 'scores/fused_scores.jsonl', labels=output / 'human_labels.jsonl',
                             sampling='diagnostic', output=output / 'evaluation'))
    (output / 'README.md').write_text('# 合成流程演示\n\n这里使用人为生成的三维特征，不是真实图像或DINO特征。结果仅证明文件流与检索评估逻辑可以运行，不代表SEM性能。\n', encoding='utf-8')
    return output
