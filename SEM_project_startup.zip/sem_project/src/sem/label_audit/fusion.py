"""Equal-view evidence fusion, never treating views as independent cases."""
from collections import defaultdict

REASONS_ZH = {'missing_expected_views': '缺少指定探测器视图',
              'one_or_more_views_lack_reference_evidence': '至少一个视图的参考证据不足',
              'cross_view_conflict': '不同视图明确支持不同类别',
              'fused_support_ambiguous': '融合后的类别支持差距不足'}


def fuse(scores, config):
    grouped = defaultdict(list)
    for row in scores:
        grouped[(row['k_requested'], row['group_id'])].append(row)
    output = []
    for (k, group_id), observations in sorted(grouped.items()):
        for field in ('layer', 'machine_label', 'split'):
            if len({r[field] for r in observations}) != 1:
                raise ValueError(f'Group {group_id} has conflicting {field}; cannot fuse')
        by_view = {r['view']: r for r in observations}
        if len(by_view) != len(observations):
            raise ValueError(f'Group {group_id} has multiple query images per view; select one acquisition triplet')
        expected = config['views']
        missing = [v for v in expected if v not in by_view]
        available = [by_view[v] for v in expected if v in by_view]
        original = observations[0]['machine_label']
        classes = sorted({label for r in available for label in r['class_support']})
        usable = [r for r in available if r['consistency_score'] is not None]
        # Mean over available nonempty views is diagnostic only if views are missing
        # or a view fails coverage checks; those cases cannot be auto-supported.
        supports = {label: sum(r['class_support'].get(label, 0) or 0 for r in usable) / len(usable)
                    if usable else None for label in classes}
        original_support = supports.get(original) if usable else None
        competitor = max((label for label in classes if label != original),
                         key=lambda label: (supports[label] or 0, label), default=None)
        competitor_support = supports.get(competitor) if competitor else (0 if usable else None)
        margin = original_support - competitor_support if original_support is not None else None
        reasons = []
        if missing:
            reasons.append('missing_expected_views')
        bad = {r['view']: [code for code in r['reason_codes'] if code != 'neighborhood_ambiguous']
               for r in available}
        bad = {view: codes for view, codes in bad.items() if codes}
        if bad or len(usable) != len(available):
            reasons.append('one_or_more_views_lack_reference_evidence')
        strong_votes = {r['machine_label'] if r['status'] == 'supports_original' else r['suggested_label']
                        for r in available if r['status'] in {'supports_original', 'review_recommended'}}
        conflict = len(strong_votes) > 1
        if conflict:
            reasons.append('cross_view_conflict')
        if reasons or not usable:
            status = 'insufficient_evidence'
        elif original_support >= config['support_fraction'] and margin >= config['review_margin']:
            status = 'supports_original'
        elif competitor_support >= config['support_fraction'] and -margin >= config['review_margin']:
            status = 'review_recommended'
        else:
            status = 'insufficient_evidence'
            reasons.append('fused_support_ambiguous')
        unique_neighbors = {n['group_id'] for r in available for n in r['neighbors']}
        reason = f'按{len(usable)}个可用视图等权平均标签支持度；近邻合计涉及{len(unique_neighbors)}个不同缺陷组，不将三视图当三例。'
        if reasons:
            reason += '需复核原因：' + '、'.join(REASONS_ZH[c] for c in reasons) + '。'
        elif status == 'review_recommended':
            reason += f'证据更支持{competitor}，保留原标签{original}并建议人工复核。'
        else:
            reason += f'当前证据支持原标签{original}。'
        output.append({'sample_id': f'fused:{group_id}', 'case_id': observations[0]['case_id'],
                       'group_id': group_id, 'layer': observations[0]['layer'], 'split': observations[0]['split'],
                       'view': 'fused', 'domain': 'per_view_matching', 'machine_label': original,
                       'output_type': original, 'k_requested': k, 'status': status,
                       'consistency_score': original_support, 'class_support': supports,
                       'competitor_label': competitor, 'competitor_support': competitor_support,
                       'support_margin': margin, 'label_correct_probability': None,
                       'suggested_label': competitor if status == 'review_recommended' else None,
                       'views_expected': expected, 'views_present': [r['view'] for r in available],
                       'views_missing': missing, 'cross_view_conflict': conflict,
                       'unique_reference_groups': len(unique_neighbors), 'view_quality_issues': bad,
                       'reason_codes': reasons, 'reason_zh': reason,
                       'view_results': [{'sample_id': r['sample_id'], 'view': r['view'], 'domain': r['domain'],
                                         'status': r['status'], 'consistency_score': r['consistency_score'],
                                         'competitor_label': r['competitor_label'], 'effective_neighbors': r['effective_neighbors']}
                                        for r in available],
                       'threshold_status': config['threshold_status'],
                       'fusion_method': 'equal_view_mean_with_quality_and_conflict_gates_v1'})
    return output
