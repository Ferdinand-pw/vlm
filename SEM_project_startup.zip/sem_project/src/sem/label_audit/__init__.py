"""Layer-scoped label audit experiments; scores are not probabilities."""
