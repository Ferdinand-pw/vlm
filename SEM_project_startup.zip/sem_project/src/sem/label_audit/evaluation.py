"""Human-label evaluation. Truth is loaded here only, never by the scorer."""
from collections import defaultdict
import math
from pathlib import Path
from .common import new_directory, read_jsonl, sha256, write_json


def ratio(a, b):
    return a / b if b else None


def metrics(groups):
    n = len(groups)
    errors = sum(not r['correct'] for r in groups)
    reviews = [r for r in groups if r['status'] == 'review_recommended']
    passed = [r for r in groups if r['status'] == 'supports_original']
    wrong_review = sum(not r['correct'] for r in reviews)
    unknown = sum(r['status'] == 'insufficient_evidence' for r in groups)
    ranking = sorted(groups, key=lambda r: (r['score'] is None, r['score'] if r['score'] is not None else 0, r['group_id']))
    budgets = {}
    for fraction in (.05, .1, .2):
        size = min(n, math.ceil(n * fraction))
        chosen = ranking[:size]
        found = sum(not r['correct'] for r in chosen)
        tie = bool(size and size < n and ranking[size - 1]['score'] == ranking[size]['score'])
        budgets[str(fraction)] = {'reviewed_groups': size, 'errors_found': found,
                                 'precision': ratio(found, size), 'error_recall': ratio(found, errors),
                                 'cutoff_tied': tie}
    return {'groups': n, 'known_label_errors': errors, 'original_label_accuracy': ratio(n - errors, n),
            'review_recommended_groups': len(reviews), 'review_precision': ratio(wrong_review, len(reviews)),
            'review_error_recall': ratio(wrong_review, errors),
            'correct_labels_sent_to_review_rate': ratio(len(reviews) - wrong_review, n - errors),
            'supported_groups': len(passed), 'supported_residual_error_rate': ratio(sum(not r['correct'] for r in passed), len(passed)),
            'insufficient_evidence_rate': ratio(unknown, n), 'ranked_review_budgets': budgets}


def evaluate_rows(scores, labels):
    truth = {}
    for row in labels:
        if not isinstance(row.get('group_id'), str) or not isinstance(row.get('expert_label'), str) or not row['expert_label']:
            raise ValueError('Truth rows require group_id and nonempty expert_label; omit unresolved cases')
        if row['group_id'] in truth:
            raise ValueError('Duplicate group in human labels')
        truth[row['group_id']] = row['expert_label']
    split_set = {r['split'] for r in scores}
    if len(split_set) != 1:
        raise ValueError('Do not mix evaluation splits')
    grouped = defaultdict(list)
    ids = set()
    for row in scores:
        identity = (row['sample_id'], row['k_requested'])
        if identity in ids:
            raise ValueError('Duplicate scored sample/k')
        ids.add(identity)
        grouped[(row['k_requested'], row['group_id'])].append(row)
    results = defaultdict(list)
    all_groups = {r['group_id'] for r in scores}
    for (k, group), observations in grouped.items():
        if group not in truth:
            continue
        machine_labels = {r['machine_label'] for r in observations}
        layers = {r['layer'] for r in observations}
        if len(machine_labels) != 1 or len(layers) != 1:
            raise ValueError('A physical-defect group must have one original label and Layer for group evaluation')
        statuses = {r['status'] for r in observations}
        status = ('review_recommended' if 'review_recommended' in statuses else
                  'insufficient_evidence' if 'insufficient_evidence' in statuses else 'supports_original')
        finite = [r['consistency_score'] for r in observations if r['consistency_score'] is not None]
        results[k].append({'group_id': group, 'layer': next(iter(layers)), 'status': status,
                           'score': min(finite) if finite else None,
                           'correct': next(iter(machine_labels)) == truth[group]})
    if not results:
        raise ValueError('No matching independent human labels')
    report = {'scored_groups': len(all_groups), 'human_labeled_groups': len(all_groups & truth.keys()),
              'label_coverage': len(all_groups & truth.keys()) / len(all_groups),
              'unused_truth_groups': len(truth.keys() - all_groups),
              'split': next(iter(split_set)), 'by_k': {},
              'aggregation': 'one group: min finite consistency; any review wins; else any insufficiency abstains',
              'ranking': 'all labeled groups, ascending consistency, null last; ties by group_id; includes insufficient-evidence cases',
              'warning': 'Metrics apply only to human-labeled subset. Selected low-score review is not production accuracy.'}
    for k, records in sorted(results.items()):
        layers = sorted({r['layer'] for r in records})
        report['by_k'][str(k)] = {'overall': metrics(records),
                                  'by_layer': {layer: metrics([r for r in records if r['layer'] == layer]) for layer in layers}}
    return report


def evaluate(args):
    scores, labels = read_jsonl(args.scores), read_jsonl(args.labels)
    if getattr(args, 'view', None):
        scores = [row for row in scores if row['view'] == args.view]
        if not scores:
            raise ValueError('No scores match requested view')
    report = evaluate_rows(scores, labels)
    report.update({'sampling_declared_by_operator': args.sampling,
                   'view_filter': getattr(args, 'view', None),
                   'scores_sha256': sha256(args.scores), 'labels_sha256': sha256(args.labels)})
    output = new_directory(args.output)
    write_json(output / 'metrics.json', report)
    lines = ['# 机台标签评估实验结果', '', '这是人工标注子集上的检错指标，不是概率校准结果。', '',
             f'评分案例组：{report["scored_groups"]}；有人工答案：{report["human_labeled_groups"]}。', '',
             '| k | 人工案例数 | 原标签错误数 | 最低分10%找到错误数 | 证据不足比例 |', '|---|---|---|---|---|']
    for k, result in report['by_k'].items():
        m = result['overall']
        lines.append(f'| {k} | {m["groups"]} | {m["known_label_errors"]} | {m["ranked_review_budgets"]["0.1"]["errors_found"]} | {m["insufficient_evidence_rate"]:.3f} |')
    lines += ['', '完整指标与各Layer结果见metrics.json。相同案例的多个视图按一个group统计。',
              '低分排序和规则判定是两项不同评估；证据不足案例不会自动改标。排序截断处并列分数请检查cutoff_tied。']
    (output / 'summary.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return output
