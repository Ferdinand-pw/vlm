import hashlib
import json
from pathlib import Path
import numpy as np

VIEWS = {'I00', 'I02', 'I03', 'I04'}
SPLITS = {'reference', 'dev', 'test', 'production'}


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_jsonl(path):
    with Path(path).open(encoding='utf-8-sig') as f:
        rows = [json.loads(line) for line in f if line.strip()]
    if not rows or any(not isinstance(row, dict) for row in rows):
        raise ValueError(f'Expected nonempty JSON object records: {path}')
    return rows


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def write_jsonl(path, rows):
    with Path(path).open('w', encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n')


def new_directory(path):
    path = Path(path).resolve()
    path.mkdir(parents=True, exist_ok=False)
    return path


def normalize(features):
    features = np.asarray(features, dtype=np.float32)
    if features.ndim != 2 or not features.shape[0] or not features.shape[1] or not np.isfinite(features).all():
        raise ValueError('Features must be a finite, nonempty [N,D] matrix')
    norms = np.linalg.norm(features, axis=1, keepdims=True)
    if (norms < 1e-10).any():
        raise ValueError('Zero feature vectors are not allowed')
    return features / norms


def load_manifest(path, check_images=True):
    from PIL import Image
    path = Path(path).resolve()
    rows = read_jsonl(path)
    ids, groups, cases, hashes = set(), {}, {}, {}
    required = ('sample_id', 'case_id', 'group_id', 'layer', 'machine_label', 'view', 'domain', 'split', 'image_path')
    for row in rows:
        if any(not isinstance(row.get(k), str) or not row[k].strip() for k in required):
            raise ValueError(f'Missing required nonempty string fields: {row}')
        if row['sample_id'] in ids:
            raise ValueError(f'Duplicate sample_id: {row["sample_id"]}')
        ids.add(row['sample_id'])
        if row['view'] not in VIEWS or row['split'] not in SPLITS:
            raise ValueError('view must be I00/I02/I03/I04 (never I01); split must be reference/dev/test/production')
        if any(k in row for k in ('true_label', 'expert_label', 'is_correct')):
            raise ValueError('Query ground truth belongs in a separate evaluation file')
        source = row.setdefault('reference_source', 'historical')
        if source not in {'historical', 'expert'}:
            raise ValueError('reference_source must be historical or expert')
        if row['split'] != 'reference' and (source != 'historical' or row.get('reference_label')):
            raise ValueError('Expert reference labels are allowed only on reference rows')
        if row['split'] == 'reference' and source == 'expert' and not row.get('reference_label'):
            raise ValueError('Expert references require reference_label')
        if source == 'historical' and row.get('reference_label'):
            raise ValueError('Historical references use machine_label; mark reviewed labels as expert')
        old = groups.setdefault(row['group_id'], (row['layer'], row['split']))
        if old != (row['layer'], row['split']):
            raise ValueError(f'Group crosses Layer or split: {row["group_id"]}')
        old_case = cases.setdefault(row['case_id'], (row['group_id'], row['layer'], row['split']))
        if old_case != (row['group_id'], row['layer'], row['split']):
            raise ValueError(f'Case has inconsistent grouping: {row["case_id"]}')
        image_path = Path(row['image_path'])
        row['image_path'] = str((path.parent / image_path).resolve() if not image_path.is_absolute() else image_path.resolve())
        roi = row.get('roi_xyxy')
        if roi is not None and (not isinstance(roi, list) or len(roi) != 4 or
                                any(type(x) is not int for x in roi) or
                                not (0 <= roi[0] < roi[2] and 0 <= roi[1] < roi[3])):
            raise ValueError('ROI must be integer pixel-edge [x1,y1,x2,y2], upper-left origin')
        if check_images:
            with Image.open(row['image_path']) as im:
                if im.mode not in {'L', 'RGB'} or getattr(im, 'n_frames', 1) != 1 or im.getexif().get(274, 1) != 1:
                    raise ValueError(f'Explicit depth/orientation conversion required: {row["image_path"]}')
                im.load()
                if roi and (roi[2] > im.width or roi[3] > im.height):
                    raise ValueError('ROI exceeds source image')
                # Pixel hash catches identical images re-encoded as different files.
                pixel_hash = hashlib.sha256(str(im.size).encode() + im.convert('RGB').tobytes()).hexdigest()
                row['pixel_sha256'] = pixel_hash
                row['image_wh'] = list(im.size)
            row['source_sha256'] = sha256(row['image_path'])
            old_hash = hashes.setdefault(pixel_hash, row['split'])
            if old_hash != row['split']:
                raise ValueError('Identical image pixels cross splits; fix leakage before extraction')
    return rows


def save_cache(path, rows, features, metadata):
    features = normalize(features)
    if len(rows) != len(features):
        raise ValueError('Feature count differs from record count')
    path = Path(path)
    np.save(path / 'features.npy', features, allow_pickle=False)
    write_jsonl(path / 'records.jsonl', rows)
    write_json(path / 'metadata.json', {**metadata, 'status': 'complete',
               'shape': list(features.shape), 'features_sha256': sha256(path / 'features.npy'),
               'records_sha256': sha256(path / 'records.jsonl')})


def load_cache(path):
    path = Path(path)
    meta = json.loads((path / 'metadata.json').read_text(encoding='utf-8'))
    if meta.get('status') != 'complete':
        raise ValueError('Feature cache is incomplete')
    for name, key in [('features.npy', 'features_sha256'), ('records.jsonl', 'records_sha256')]:
        if sha256(path / name) != meta[key]:
            raise ValueError(f'Cache checksum mismatch: {name}')
    rows = read_jsonl(path / 'records.jsonl')
    features = np.load(path / 'features.npy', allow_pickle=False)
    if list(features.shape) != meta['shape'] or len(rows) != len(features):
        raise ValueError('Cache shape mismatch')
    return rows, normalize(features), meta
