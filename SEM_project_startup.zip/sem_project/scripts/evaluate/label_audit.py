#!/usr/bin/env python3
"""Run from any directory; keep scripts and src together when deploying."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'src'))
from sem.label_audit.cli import main

if __name__ == '__main__':
    main()
