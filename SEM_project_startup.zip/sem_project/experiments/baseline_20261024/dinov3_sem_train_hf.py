#!/usr/bin/env python3
"""Offline DINOv3 SEM classifier: shared backbone and two classification heads.

ImageFolder: data/{train,val[,test]}/{normal,Particle_422,Void_471,C-Residue_4197,
Bump_411,Masking_433,InFilm_413}/image.jpg
No model or image is downloaded by this script.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import math
import os
import random
from collections import Counter
from pathlib import Path

os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')

CLASS_NAMES = ('Particle_422', 'Void_471', 'C-Residue_4197', 'Bump_411', 'Masking_433', 'InFilm_413')
NORMAL_NAME = 'normal'
BINARY_NAMES = ('normal', 'defect')
EXTS = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff', '.webp'}
NORMALIZATIONS = {
    'lvd': ((.485, .456, .406), (.229, .224, .225)),
    'sat': ((.430, .411, .296), (.213, .156, .143)),
}


def imports():
    import torch
    from PIL import Image, ImageOps
    from torch.utils.data import DataLoader
    from torchvision import datasets, transforms
    return torch, Image, ImageOps, DataLoader, datasets, transforms


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def model_fingerprint(args):
    path = Path(args.weights if args.backend == 'hub' else args.model_dir).resolve()
    files = [path] if path.is_file() else sorted(
        x for x in path.rglob('*') if x.is_file() and x.suffix in {'.json', '.safetensors', '.bin', '.pth'}
    )
    if not files:
        raise FileNotFoundError(f'No local checkpoint files found at {path}')
    h = hashlib.sha256()
    for f in files:
        h.update((f.relative_to(path).as_posix() if path.is_dir() else f.name).encode())
        h.update(file_sha(f).encode())
    return h.hexdigest()


def choose_device(args):
    torch, *_ = imports()
    if args.device == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA was requested but is not available')
    return torch.device('cuda' if args.device == 'auto' and torch.cuda.is_available() else
                        'cpu' if args.device == 'auto' else args.device)


def find_transformer_blocks(model):
    """Resolve common Meta hub, timm wrapper and HF ViT/DINOv3 nesting."""
    import torch
    candidates = [
        'blocks', 'timm_model.blocks', 'encoder.layer', 'encoder.layers',
        'dinov3.encoder.layer', 'dinov3.encoder.layers',
        'model.layer', 'model.encoder.layer', 'dinov3.model.layer',
        'vit.encoder.layer', 'vit.encoder.layers',
        'backbone.blocks', 'backbone.encoder.layer',
    ]
    for path in candidates:
        obj = model
        for part in path.split('.'):
            obj = getattr(obj, part, None)
            if obj is None:
                break
        if isinstance(obj, (torch.nn.ModuleList, torch.nn.Sequential)) and len(obj):
            return obj, path
    raise RuntimeError('Cannot locate transformer blocks; inspected: ' + ', '.join(candidates))


def load_backbone(args, device, unfreeze_layers=0):
    torch, *_ = imports()
    if args.backend == 'hub':
        repo = Path(args.repo_dir).resolve()
        weights = Path(args.weights).resolve()
        if not (repo / 'hubconf.py').is_file() or not weights.is_file():
            raise FileNotFoundError('Invalid --repo-dir/hubconf.py or --weights')
        model = torch.hub.load(str(repo), args.model_name, source='local', weights=str(weights))
    else:
        model_dir = Path(args.model_dir).resolve()
        if not (model_dir / 'config.json').is_file():
            raise FileNotFoundError(f'No config.json in {model_dir}')
        from transformers import AutoModel
        model = AutoModel.from_pretrained(str(model_dir), local_files_only=True)
    model.to(device)
    for p in model.parameters():
        p.requires_grad_(False)
    if unfreeze_layers:
        blocks, path = find_transformer_blocks(model)
        if unfreeze_layers > len(blocks):
            raise ValueError(f'--unfreeze-layers={unfreeze_layers} exceeds {len(blocks)} blocks')
        for block in blocks[-unfreeze_layers:]:
            for p in block.parameters():
                p.requires_grad_(True)
        print(f'Unfrozen {unfreeze_layers}/{len(blocks)} blocks ({path})', flush=True)
    model.eval()
    return model


def backbone_features(model, pixels, backend):
    torch, *_ = imports()
    if backend == 'hub':
        # Standard Meta DINOv3 hub ViT usually returns [B,D] directly.
        output = model(pixels)
        if isinstance(output, dict):
            output = output.get('x_norm_clstoken', output.get('last_hidden_state', output.get('x')))
    else:
        output = model(pixel_values=pixels)
        if hasattr(output, 'last_hidden_state') and output.last_hidden_state is not None:
            output = output.last_hidden_state
        elif hasattr(output, 'pooler_output') and output.pooler_output is not None:
            output = output.pooler_output
    if isinstance(output, (tuple, list)):
        output = output[0]
    if not isinstance(output, torch.Tensor):
        raise RuntimeError(f'Unexpected backbone output {type(output)}')
    if output.ndim == 3:
        # HF DINOv3: [CLS, register tokens, patch tokens]. Exclude registers from pooling.
        register_count = int(getattr(model.config, 'num_register_tokens', 0)) if backend == 'hf' else 0
        cls = output[:, 0]
        patches = output[:, 1 + register_count:]
        if patches.shape[1] == 0:
            raise RuntimeError('No patch tokens in 3D backbone output')
        output = torch.cat((cls, patches.mean(1), patches.amax(1)), dim=1)
    if output.ndim != 2 or output.shape[0] != pixels.shape[0]:
        raise RuntimeError(f'Expected [B,D] backbone output, got {tuple(output.shape)}')
    return output.float()


def make_transform(size, normalization):
    _, Image, ImageOps, _, _, transforms = imports()
    mean, std = NORMALIZATIONS[normalization]
    def pad_square(img):
        return ImageOps.pad(img.convert('RGB'), (size, size), method=Image.Resampling.BICUBIC,
                            color=(0, 0, 0), centering=(.5, .5))
    return transforms.Compose((pad_square, transforms.ToTensor(), transforms.Normalize(mean, std)))


def scan_imagefolders(root):
    _, _, _, _, datasets, _ = imports()
    names = sorted(set(CLASS_NAMES) | {NORMAL_NAME})
    split_names = ['train', 'val'] + (['test'] if (root / 'test').is_dir() else [])
    result, rows, hashes = {}, [], {}
    for split in split_names:
        directory = root / split
        if not directory.is_dir():
            raise FileNotFoundError(directory)
        actual = {p.name for p in directory.iterdir() if p.is_dir()}
        if actual != set(names):
            raise ValueError(f'{split}: missing={sorted(set(names)-actual)}, extra={sorted(actual-set(names))}')
        ds = datasets.ImageFolder(str(directory), is_valid_file=lambda p: Path(p).suffix.lower() in EXTS)
        counts = Counter(y for _, y in ds.samples)
        if ds.classes != names or any(counts[i] == 0 for i in range(len(names))):
            raise ValueError(f'{split}: class order incorrect or empty class')
        result[split] = ds
        for path, label in ds.samples:
            path = Path(path)
            digest = file_sha(path)
            if digest in hashes:
                raise ValueError(f'Duplicate images: {hashes[digest]} and {path}')
            hashes[digest] = path
            rows.append({'image_path': path.relative_to(root).as_posix(),
                         'split': split, 'class': names[label], 'is_normal': names[label] == NORMAL_NAME})
    return result, rows


def check_groups(rows, groups_csv):
    if not groups_csv:
        print('WARNING: no groups CSV; wafer/three-view leakage cannot be checked', flush=True)
        return 'not_checked'
    with Path(groups_csv).open(newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        if not {'image_path', 'group_id'}.issubset(reader.fieldnames or []):
            raise ValueError('groups CSV must include image_path and group_id')
        entries = {}
        for row in reader:
            name, group = row['image_path'].replace('\\', '/'), row['group_id'].strip()
            if not name or not group or name in entries:
                raise ValueError(f'Duplicate/empty group row: {name}')
            entries[name] = group
    paths = {r['image_path'] for r in rows}
    if set(entries) != paths:
        raise ValueError(f'Group entries mismatch: missing={list(paths-set(entries))[:5]}, extra={list(set(entries)-paths)[:5]}')
    seen = {}
    for row in rows:
        group = entries[row['image_path']]
        previous = seen.setdefault(group, row['split'])
        if previous != row['split']:
            raise ValueError(f'Group {group} crosses {previous} / {row["split"]}')
    return 'passed'


def make_head(in_dim, classes, hidden, dropout):
    torch, *_ = imports()
    return (torch.nn.Sequential(torch.nn.Linear(in_dim, hidden), torch.nn.GELU(),
                                torch.nn.Dropout(dropout), torch.nn.Linear(hidden, classes))
            if hidden > 0 else torch.nn.Linear(in_dim, classes))


def label_mapping(raw, normal_index):
    y11 = raw.clone()
    y11[raw == normal_index] = -1
    y11[raw > normal_index] -= 1
    return y11, (raw != normal_index).long()


def stats(truth, pred, names):
    torch, *_ = imports()
    n = len(names)
    matrix = torch.bincount(truth * n + pred, minlength=n*n).reshape(n, n)
    scores = {}
    for i, name in enumerate(names):
        tp = matrix[i, i].item()
        support = matrix[i].sum().item()
        predicted = matrix[:, i].sum().item()
        precision = tp / predicted if predicted else 0.
        recall = tp / support if support else 0.
        f1 = 2*precision*recall/(precision+recall) if precision+recall else 0.
        scores[name] = dict(support=support, precision=precision, recall=recall, f1=f1)
    return {'accuracy': matrix.diag().sum().item() / max(1, len(truth)),
            'macro_f1': sum(x['f1'] for x in scores.values()) / n,
            'per_class': scores, 'class_order': list(names),
            'confusion_matrix_rows_true_cols_pred': matrix.tolist()}


def eval_split(model, head11, head2, loader, backend, device, normal_index):
    torch, *_ = imports()
    model.eval(); head11.eval(); head2.eval()
    t11, p11, t2, p2 = [], [], [], []
    with torch.inference_mode():
        for pixels, labels in loader:
            pixels = pixels.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            features = backbone_features(model, pixels, backend)
            y11, y2 = label_mapping(labels, normal_index)
            mask = y11 >= 0
            if mask.any():
                t11.append(y11[mask].cpu())
                p11.append(head11(features[mask]).argmax(1).cpu())
            t2.append(y2.cpu()); p2.append(head2(features).argmax(1).cpu())
    return (stats(torch.cat(t11), torch.cat(p11), sorted(CLASS_NAMES)),
            stats(torch.cat(t2), torch.cat(p2), BINARY_NAMES))


def to_cpu_state(module):
    return {k: v.detach().cpu().clone() for k, v in module.state_dict().items()}


def config_for_checkpoint(args, fingerprint, rows):
    digest = hashlib.sha256(json.dumps(rows, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    return {'backend': args.backend, 'model_name': args.model_name if args.backend == 'hub' else None,
            'model_fingerprint': fingerprint, 'dataset_manifest_sha256': digest,
            'image_size': args.image_size, 'normalization': args.normalization,
            'unfreeze_layers': args.unfreeze_layers, 'mlp_hidden': args.mlp_hidden,
            'dropout': args.dropout, 'lr': args.lr, 'backbone_lr': args.backbone_lr,
            'weight_decay': args.weight_decay, 'class_weighting': args.class_weighting,
            'batch_size': args.feature_batch_size, 'warmup_epochs': args.warmup_epochs,
            'epochs': args.epochs, 'seed': args.seed,
            'defect_loss_weight': args.defect_loss_weight,
            'groups_csv_sha256': file_sha(args.groups_csv) if args.groups_csv else None}


def train(args):
    torch, _, _, DataLoader, _, _ = imports()
    random.seed(args.seed); torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    root = Path(args.data_dir).resolve()
    datasets, rows = scan_imagefolders(root)
    group_check = check_groups(rows, args.groups_csv)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    device = choose_device(args)
    fingerprint = model_fingerprint(args)
    config = config_for_checkpoint(args, fingerprint, rows)
    transform = make_transform(args.image_size, args.normalization)
    for ds in datasets.values():
        ds.transform = transform
    normal_index = datasets['train'].classes.index(NORMAL_NAME)
    loaders = {split: DataLoader(ds, batch_size=args.feature_batch_size, shuffle=(split == 'train'),
                                 num_workers=args.num_workers, pin_memory=(device.type == 'cuda'))
               for split, ds in datasets.items()}
    counts = Counter(y for _, y in datasets['train'].samples)
    if args.class_weighting == 'sqrt_inverse':
        defect_counts = torch.tensor([counts[datasets['train'].class_to_idx[name]] for name in sorted(CLASS_NAMES)], dtype=torch.float)
        binary_counts = torch.tensor([counts[normal_index], sum(v for k,v in counts.items() if k != normal_index)], dtype=torch.float)
        w11 = (defect_counts.sum() / (len(CLASS_NAMES) * defect_counts)).sqrt().to(device)
        w2 = (binary_counts.sum() / (2 * binary_counts)).sqrt().to(device)
    else:
        w11 = w2 = None
    model = load_backbone(args, device, args.unfreeze_layers)
    with torch.inference_mode():
        sample = torch.zeros(1, 3, args.image_size, args.image_size, device=device)
        dim = backbone_features(model, sample, args.backend).shape[1]
    head11 = make_head(dim, len(CLASS_NAMES), args.mlp_hidden, args.dropout).to(device)
    head2 = make_head(dim, 2, args.mlp_hidden, args.dropout).to(device)
    params = [{'params': list(head11.parameters()) + list(head2.parameters()), 'lr': args.lr}]
    backbone_params = [p for p in model.parameters() if p.requires_grad]
    if backbone_params:
        params.append({'params': backbone_params, 'lr': args.backbone_lr})
    optimizer = torch.optim.AdamW(params, weight_decay=args.weight_decay)
    # Set LR explicitly at the start of each epoch: never start at exactly zero.
    def lr_factor(epoch):
        warm = min(args.warmup_epochs, args.epochs)
        if warm and epoch <= warm:
            return epoch / warm
        progress = (epoch-warm) / max(1, args.epochs-warm)
        return .5*(1+math.cos(math.pi*progress))
    criterion11 = torch.nn.CrossEntropyLoss(weight=w11)
    criterion2 = torch.nn.CrossEntropyLoss(weight=w2)
    resume_path = output / 'resume.pt'
    best_score, best_epoch, best_state = -1., None, None
    history, start_epoch = [], 1
    if resume_path.exists() and not args.no_resume:
        resume = torch.load(resume_path, map_location='cpu', weights_only=False)
        if resume.get('config') != config or resume.get('feature_dim') != dim:
            raise ValueError('Resume config differs from current run; use a new --output-dir or --no-resume')
        model.load_state_dict(resume['backbone'], strict=True)
        head11.load_state_dict(resume['head_11'], strict=True)
        head2.load_state_dict(resume['head_2'], strict=True)
        optimizer.load_state_dict(resume['optimizer'])
        # Optimizer tensors may need to be moved after CPU checkpoint loading.
        for state in optimizer.state.values():
            for key, val in state.items():
                if isinstance(val, torch.Tensor):
                    state[key] = val.to(device)
        best_score = resume['best_score']; best_epoch = resume['best_epoch']
        best_state = resume['best_state']; history = resume['history']
        start_epoch = resume['next_epoch']
        print(f'Resumed from epoch {start_epoch}', flush=True)
    print(f'Feature dimension={dim}, trainable backbone parameters={sum(p.numel() for p in backbone_params)}', flush=True)
    for epoch in range(start_epoch, args.epochs+1):
        factor = lr_factor(epoch)
        for group, base in zip(optimizer.param_groups, [args.lr, args.backbone_lr]):
            group['lr'] = base * factor
        if args.unfreeze_layers > 0:
            model.train()
            # Frozen modules remain in eval mode, preventing unwanted dropout/state updates.
            for sub in model.modules():
                if not any(p.requires_grad for p in sub.parameters()):
                    sub.eval()
        else:
            model.eval()
        head11.train(); head2.train()
        total_loss, steps = 0., 0
        for pixels, labels in loaders['train']:
            pixels = pixels.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            if args.unfreeze_layers == 0:
                with torch.no_grad():
                    features = backbone_features(model, pixels, args.backend)
            else:
                features = backbone_features(model, pixels, args.backend)
            y11, y2 = label_mapping(labels, normal_index)
            loss = criterion2(head2(features), y2)
            mask = y11 >= 0
            if mask.any():
                loss = loss + args.defect_loss_weight * criterion11(head11(features[mask]), y11[mask])
            loss.backward()
            optimizer.step()
            total_loss += loss.item(); steps += 1
        r11, r2 = eval_split(model, head11, head2, loaders['val'], args.backend, device, normal_index)
        score = (r11['macro_f1'] + r2['macro_f1']) / 2
        record = {'epoch': epoch, 'train_loss': total_loss / max(1,steps),
                  'val_acc_11': r11['accuracy'], 'val_f1_11': r11['macro_f1'],
                  'val_acc_2': r2['accuracy'], 'val_f1_2': r2['macro_f1'],
                  'joint_f1': score, 'head_lr': optimizer.param_groups[0]['lr']}
        history.append(record)
        print(json.dumps(record), flush=True)
        if score > best_score:
            best_score, best_epoch = score, epoch
            best_state = {'backbone': to_cpu_state(model), 'head_11': to_cpu_state(head11),
                          'head_2': to_cpu_state(head2)}
        if epoch % args.save_every == 0 or epoch == args.epochs:
            torch.save({'config': config, 'feature_dim': dim, 'backbone': to_cpu_state(model),
                        'head_11': to_cpu_state(head11), 'head_2': to_cpu_state(head2),
                        'optimizer': optimizer.state_dict(), 'best_score': best_score,
                        'best_epoch': best_epoch, 'best_state': best_state,
                        'history': history, 'next_epoch': epoch+1}, resume_path)
    if best_state is None:
        raise RuntimeError('No trained checkpoint is available; check --epochs and resume state')
    model.load_state_dict(best_state['backbone'])
    head11.load_state_dict(best_state['head_11'])
    head2.load_state_dict(best_state['head_2'])
    reports11, reports2 = {}, {}
    for split in ['val'] + (['test'] if 'test' in loaders else []):
        reports11[split], reports2[split] = eval_split(model, head11, head2, loaders[split], args.backend, device, normal_index)
    checkpoint = {'head_11_state_dict': best_state['head_11'], 'head_2_state_dict': best_state['head_2'],
                  'backbone_state_dict': best_state['backbone'] if args.unfreeze_layers else None,
                  'class_names': sorted(CLASS_NAMES), 'binary_names': list(BINARY_NAMES),
                  'feature_dim': dim, 'backend': args.backend, 'model_name': config['model_name'],
                  'model_fingerprint': fingerprint, 'image_size': args.image_size,
                  'normalization': args.normalization, 'unfreeze_layers': args.unfreeze_layers,
                  'mlp_hidden': args.mlp_hidden, 'dropout': args.dropout,
                  'best_epoch': best_epoch, 'best_joint_f1': best_score}
    torch.save(checkpoint, output / 'classifier.pth')
    (output / 'metrics.json').write_text(json.dumps({'defect_type': reports11, 'normal_vs_defect': reports2}, indent=2), encoding='utf-8')
    (output / 'history.json').write_text(json.dumps(history, indent=2), encoding='utf-8')
    (output / 'data_manifest.json').write_text(json.dumps({'root': str(root), 'group_check': group_check, 'images': rows}, indent=2), encoding='utf-8')
    print(f'Saved {output / "classifier.pth"}; best epoch {best_epoch}; joint macro-F1={best_score:.4f}', flush=True)


def inspect(args):
    torch, *_ = imports()
    device = choose_device(args)
    model = load_backbone(args, device, args.unfreeze_layers)
    with torch.inference_mode():
        features = backbone_features(model, torch.zeros(1,3,args.image_size,args.image_size, device=device), args.backend)
    print(json.dumps({'backend': args.backend, 'device': str(device), 'feature_dim': features.shape[1],
                      'image_size': args.image_size, 'model_fingerprint': model_fingerprint(args)}, indent=2))


def predict(args):
    torch, Image, *_ = imports()
    device = choose_device(args)
    ckpt = torch.load(args.head, map_location='cpu', weights_only=True)
    if ckpt['backend'] != args.backend or ckpt['model_fingerprint'] != model_fingerprint(args):
        raise ValueError('Backend or local model weights differ from training')
    if args.backend == 'hub' and ckpt['model_name'] != args.model_name:
        raise ValueError('Hub model name differs from training')
    model = load_backbone(args, device, 0)
    if ckpt.get('backbone_state_dict') is not None:
        model.load_state_dict(ckpt['backbone_state_dict'], strict=True)
    model.eval()
    dim = ckpt['feature_dim']
    head11 = make_head(dim, len(ckpt['class_names']), ckpt.get('mlp_hidden',0), ckpt.get('dropout',0.)).to(device)
    head2 = make_head(dim, len(ckpt['binary_names']), ckpt.get('mlp_hidden',0), ckpt.get('dropout',0.)).to(device)
    head11.load_state_dict(ckpt['head_11_state_dict']); head2.load_state_dict(ckpt['head_2_state_dict'])
    head11.eval(); head2.eval()
    path = Path(args.image)
    if not path.is_file():
        raise FileNotFoundError(path)
    with Image.open(path) as img, torch.inference_mode():
        pixels = make_transform(ckpt['image_size'], ckpt['normalization'])(img).unsqueeze(0).to(device)
        features = backbone_features(model, pixels, args.backend)
        if features.shape[1] != dim:
            raise ValueError('Feature dimension mismatch')
        scores2 = torch.softmax(head2(features), dim=1)[0].cpu().tolist()
        defect_index = ckpt['binary_names'].index('defect')
        is_defect = scores2[defect_index] >= args.defect_threshold
        scores11 = torch.softmax(head11(features), dim=1)[0].cpu().tolist() if is_defect else None
    candidates = ([{'class': ckpt['class_names'][i], 'score': round(scores11[i], 6)}
                   for i in sorted(range(len(scores11)), key=lambda i: scores11[i], reverse=True)]
                  if scores11 is not None else None)
    result = {'image': str(path.resolve()), 'scope': 'whole_image',
              'stage1_normal_vs_defect': {name: round(p,6) for name,p in zip(ckpt['binary_names'], scores2)},
              'defect_threshold': args.defect_threshold, 'is_defect': bool(is_defect),
              'stage2_defect_type': candidates}
    text = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output:
        destination = Path(args.output)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(text+'\n', encoding='utf-8')
    print(text)


def common_args(p):
    p.add_argument('--backend', required=True, choices=('hub','hf'))
    p.add_argument('--repo-dir')
    p.add_argument('--weights')
    p.add_argument('--model-name', default='dinov3_vitb16')
    p.add_argument('--model-dir')
    p.add_argument('--device', default='auto', choices=('auto','cpu','cuda'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('inspect'); common_args(p)
    p.add_argument('--image-size', type=int, default=224)
    p.add_argument('--unfreeze-layers', type=int, default=0)
    p.set_defaults(func=inspect)
    p = commands.add_parser('train'); common_args(p)
    p.add_argument('--data-dir', required=True)
    p.add_argument('--groups-csv')
    p.add_argument('--output-dir', required=True)
    p.add_argument('--image-size', type=int, default=224)
    p.add_argument('--normalization', choices=NORMALIZATIONS, default='lvd')
    p.add_argument('--feature-batch-size', type=int, default=16, help='Images per training batch')
    p.add_argument('--head-batch-size', type=int, default=64, help='Legacy argument, ignored; uses --feature-batch-size')
    p.add_argument('--num-workers', type=int, default=4)
    p.add_argument('--epochs', type=int, default=50)
    p.add_argument('--lr', type=float, default=1e-3)
    p.add_argument('--backbone-lr', type=float, default=1e-5)
    p.add_argument('--weight-decay', type=float, default=1e-4)
    p.add_argument('--class-weighting', choices=('none','sqrt_inverse'), default='none')
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--warmup-epochs', type=int, default=5)
    p.add_argument('--save-every', type=int, default=5)
    p.add_argument('--unfreeze-layers', type=int, default=0)
    p.add_argument('--mlp-hidden', type=int, default=0)
    p.add_argument('--dropout', type=float, default=.1)
    p.add_argument('--defect-loss-weight', type=float, default=1.)
    p.add_argument('--no-resume', action='store_true')
    p.set_defaults(func=train)
    p = commands.add_parser('predict'); common_args(p)
    p.add_argument('--head', required=True)
    p.add_argument('--image', required=True)
    p.add_argument('--output')
    p.add_argument('--defect-threshold', type=float, default=.5)
    p.set_defaults(func=predict)
    args = parser.parse_args()
    if args.backend == 'hub' and (not args.repo_dir or not args.weights):
        parser.error('hub requires --repo-dir and --weights')
    if args.backend == 'hf' and not args.model_dir:
        parser.error('hf requires --model-dir')
    if hasattr(args,'image_size') and (args.image_size < 16 or args.image_size % 16):
        parser.error('--image-size must be a positive multiple of 16')
    if hasattr(args,'unfreeze_layers') and args.unfreeze_layers < 0:
        parser.error('--unfreeze-layers must be nonnegative')
    if args.command == 'train':
        if args.epochs < 1 or args.feature_batch_size < 1 or args.num_workers < 0 or args.save_every < 1:
            parser.error('Invalid epochs / batch size / worker count / save-every')
        if args.mlp_hidden < 0 or not 0 <= args.dropout < 1:
            parser.error('--mlp-hidden must be nonnegative, --dropout must be in [0,1)')
        if args.lr <= 0 or args.backbone_lr <= 0 or args.weight_decay < 0 or args.defect_loss_weight < 0:
            parser.error('Invalid learning rate / weight decay / defect loss weight')
        if args.warmup_epochs < 0:
            parser.error('--warmup-epochs must be nonnegative')
    if args.command == 'predict' and not 0 <= args.defect_threshold <= 1:
        parser.error('--defect-threshold must be in [0,1]')
    args.func(args)


if __name__ == '__main__':
    main()