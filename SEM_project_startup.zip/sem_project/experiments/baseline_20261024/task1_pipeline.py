#!/usr/bin/env python3
"""Task-one SEM pipeline: original -> local DINO -> layer/views -> local Qwen.

The DINO and Qwen environments may be different Conda environments. This
orchestrator itself needs only Python + Pillow and passes data via local files.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

from dino_bridge import run_predictor
from source_views import (DEFAULT_VIEW_REGEX, build_index, compose_views,
                          find_views, layer_from_path, resolve_original, sha256_file)

REPORT_TYPES = {
    "Particle_422", "Void_471", "C-Residue_4197",
    "Bump_411", "Masking_433", "InFilm_413",
    "normal", "unknown",
}


def python_prefix(python: str | None, conda_env: str | None, conda_exe: str) -> list[str]:
    if python and conda_env:
        raise ValueError("Choose a Python executable or Conda environment, not both")
    if conda_env:
        if not shutil.which(conda_exe):
            raise FileNotFoundError(f"Conda executable not found: {conda_exe}")
        return [conda_exe, "run", "-n", conda_env, "python"]
    if python:
        if not Path(python).is_file():
            raise FileNotFoundError(python)
        return [python]
    return [sys.executable]


def run(args):
    started = time.perf_counter()
    original = Path(args.image).resolve()
    if not original.is_file():
        raise FileNotFoundError(original)
    output = Path(args.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    if args.source_path:
        source = Path(args.source_path).resolve()
        if not source.is_file():
            raise FileNotFoundError(source)
        if sha256_file(original) != sha256_file(source):
            raise ValueError("--source-path does not have identical bytes to the original input")
        source_status = "explicit_exact_bytes"
    else:
        if not args.index_db:
            raise ValueError("Provide --index-db or an exact-byte --source-path")
        source, source_status = resolve_original(original, Path(args.index_db))
    layer = args.layer or layer_from_path(source, anchor=args.layer_anchor, parent=args.layer_parent)
    preflight_seconds = time.perf_counter() - started
    dino_prefix = python_prefix(args.dino_python, args.dino_conda_env, args.conda_exe)
    dino_started = time.perf_counter()
    dino = run_predictor(image=original,
                         script=Path(args.dino_script).resolve() if args.dino_script else None,
                         model_dir=Path(args.dino_model_dir).resolve() if args.dino_model_dir else None,
                         head=Path(args.dino_head).resolve() if args.dino_head else None,
                         python_prefix=dino_prefix,
                         json_file=Path(args.dino_json).resolve() if args.dino_json else None,
                         label_path=args.dino_label_path, label_regex=args.dino_label_regex,
                         device=args.dino_device,
                         extra_args=args.dino_extra_arg, output_dir=output)
    dino_seconds = time.perf_counter() - dino_started
    is_defect = dino.get("is_defect", True)
    composite_path = None
    composite_info = None
    views = {}
    if is_defect:
        views = find_views(source, args.view_regex)
        composite_path = output / "detectors_02R_03G_04B.png"
        composite_info = compose_views(views, original, composite_path, output / "channels.json")
    report_candidate = None
    if args.type_map:
        mapping = json.loads(Path(args.type_map).read_text(encoding="utf-8-sig"))
        if not isinstance(mapping, dict) or dino["candidate"] not in mapping:
            raise ValueError(f"Type map has no mapping for DINO label {dino['candidate']!r}")
        report_candidate = mapping[dino["candidate"]]
        if not isinstance(report_candidate, str) or not report_candidate.strip():
            raise ValueError("Mapped report candidate must be a nonempty string")
        if report_candidate not in REPORT_TYPES:
            raise ValueError(f"Mapped report label {report_candidate!r} is outside the bundled prompt's type vocabulary")
    elif dino["candidate"] not in REPORT_TYPES:
        raise ValueError(f"DINO label {dino['candidate']!r} is outside the report vocabulary. "
                         "Provide a reviewed --type-map before sending it to Qwen.")
    request = {"status": "prepared_from_real_files", "original_input": str(original),
               "original_sha256": sha256_file(original), "source_path": str(source),
               "source_match_status": source_status, "layer": layer,
               "views": {code: str(path) for code, path in views.items()} if is_defect else {},
               "composite_image": str(composite_path) if composite_path else None,
               "composite_metadata": composite_info,
               "dino": dino, "report_candidate": report_candidate, "is_defect": is_defect}
    request_path = output / "task1_request.json"
    request_path.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding="utf-8")
    qwen_prefix = python_prefix(args.qwen_python, args.qwen_conda_env, args.conda_exe)
    qwen_output = output / ("qwen_preview.json" if args.backend == "preview" else "qwen_report.json")
    command = qwen_prefix + [str(Path(__file__).resolve().with_name("qwen_task1.py")),
                             "--request", str(request_path), "--prompt", str(Path(args.prompt).resolve()),
                             "--backend", args.backend, "--output", str(qwen_output),
                             "--max-new-tokens", str(args.max_new_tokens)]
    if args.backend == "local-hf":
        if not args.qwen_model_dir:
            raise ValueError("--qwen-model-dir is required for local-hf")
        command += ["--model-dir", str(Path(args.qwen_model_dir).resolve())]
    qwen_started = time.perf_counter()
    subprocess.run(command, check=True)
    qwen_seconds = time.perf_counter() - qwen_started
    qwen_result = json.loads(qwen_output.read_text(encoding="utf-8-sig"))
    result = {"status": qwen_result["status"], "layer": layer, "dino_candidate": dino["candidate"],
              "request": str(request_path), "qwen_output": str(qwen_output),
              "timing_seconds": {"source_and_composite": round(preflight_seconds, 3),
                                 "dino": round(dino_seconds, 3), "qwen_process": round(qwen_seconds, 3),
                                 "total": round(time.perf_counter() - started, 3)}}
    result_path = output / "pipeline_result.json"
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(result_path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    index = commands.add_parser("index", help="Build exact-filename index for the original SEM library")
    index.add_argument("--source-root", required=True)
    index.add_argument("--index-db", required=True)
    index.set_defaults(action=lambda a: print(json.dumps(
        build_index(Path(a.source_root), Path(a.index_db)), ensure_ascii=False, indent=2)))
    run_parser = commands.add_parser("run", help="Resolve views, invoke DINO, and preview/run Qwen")
    run_parser.add_argument("--image", required=True, help="Original image to describe")
    source_group = run_parser.add_mutually_exclusive_group(required=True)
    source_group.add_argument("--index-db", help="SQLite index built with the index command")
    source_group.add_argument("--source-path", help="Exact original library path, same image bytes")
    layer_group = run_parser.add_mutually_exclusive_group(required=True)
    layer_group.add_argument("--layer-anchor", help="Layer is the directory immediately after this folder")
    layer_group.add_argument("--layer-parent", type=int, help="1=original file's parent, 2=grandparent")
    layer_group.add_argument("--layer", help="Explicit layer when path layout is not known")
    run_parser.add_argument("--view-regex", default=DEFAULT_VIEW_REGEX,
                            help="Regex on filename stem with named group view; default accepts 01-04 tokens")
    run_parser.add_argument("--dino-script", help="Company's dinov3_sem_train_hf.py")
    run_parser.add_argument("--dino-model-dir", help="Local HF DINOv3 directory")
    run_parser.add_argument("--dino-head", help="Trained classifier.pth")
    run_parser.add_argument("--dino-json", help="Alternative: existing DINO predict JSON")
    run_parser.add_argument("--dino-label-path", help="Dotted path to six-class label in DINO JSON")
    run_parser.add_argument("--dino-label-regex", help="If predictor prints text, named (?P<label>...) regex")
    run_parser.add_argument("--dino-device", default="cuda")
    run_parser.add_argument("--dino-extra-arg", action="append", default=[],
                            help="Repeat for additional predictor CLI args; use --dino-extra-arg=--flag")
    run_parser.add_argument("--dino-python")
    run_parser.add_argument("--dino-conda-env")
    run_parser.add_argument("--qwen-python")
    run_parser.add_argument("--qwen-conda-env")
    run_parser.add_argument("--conda-exe", default="conda")
    run_parser.add_argument("--prompt", required=True, help="Local SEM Markdown prompt; bundled SEM_prompt_task1.md")
    run_parser.add_argument("--type-map", help="Optional reviewed DINO label -> report label JSON")
    run_parser.add_argument("--backend", choices=("preview", "local-hf"), default="preview")
    run_parser.add_argument("--qwen-model-dir", help="Local Qwen3.8-27B directory")
    run_parser.add_argument("--max-new-tokens", type=int, default=2048)
    run_parser.add_argument("--output-dir", required=True)
    run_parser.set_defaults(action=run)
    args = parser.parse_args()
    if args.command == "run" and args.max_new_tokens < 1:
        parser.error("--max-new-tokens must be positive")
    args.action(args)


if __name__ == "__main__":
    main()