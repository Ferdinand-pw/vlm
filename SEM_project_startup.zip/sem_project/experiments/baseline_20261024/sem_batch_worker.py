#!/usr/bin/env python3
"""Persistent single-role inference worker for batch_run50.py.

Run DINO and Qwen in separate Python processes / (optionally) Conda envs.
One JSON input per line, one prefixed JSON result per line. No network calls.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import sys
import time
import traceback
from pathlib import Path

os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

PREFIX = "@@SEM_BATCH_RESULT@@"


def emit(record):
    print(PREFIX + json.dumps(record, ensure_ascii=False), flush=True)


def import_dino(path):
    path = Path(path).resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    spec = importlib.util.spec_from_file_location("sem_dino_train", str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def dino_role(args):
    import torch
    from PIL import Image
    mod = import_dino(args.dino_script)
    dev = mod.choose_device(type("D", (), {"device": args.dino_device})())
    dargs = type("D", (), {"backend": "hf", "model_dir": args.dino_model_dir})()
    ckpt = torch.load(args.dino_head, map_location="cpu", weights_only=True)
    if ckpt["backend"] != "hf" or ckpt["model_fingerprint"] != mod.model_fingerprint(dargs):
        raise ValueError("DINO classifier checkpoint does not match the HF model weights (fingerprint)")
    model = mod.load_backbone(dargs, dev, 0)
    if ckpt.get("backbone_state_dict") is not None:
        model.load_state_dict(ckpt["backbone_state_dict"], strict=True)
    model.eval()
    dim = ckpt["feature_dim"]
    head_11 = mod.make_head(dim, len(ckpt["class_names"]), ckpt.get("mlp_hidden", 0), ckpt.get("dropout", 0.0)).to(dev)
    head_2 = mod.make_head(dim, len(ckpt["binary_names"]), ckpt.get("mlp_hidden", 0), ckpt.get("dropout", 0.0)).to(dev)
    head_11.load_state_dict(ckpt["head_11_state_dict"])
    head_2.load_state_dict(ckpt["head_2_state_dict"])
    head_11.eval(); head_2.eval()
    transform = mod.make_transform(ckpt["image_size"], ckpt["normalization"])
    defect_idx = ckpt["binary_names"].index("defect")
    emit({"kind": "ready", "role": "dino", "device": str(dev)})
    for line in sys.stdin:
        if not line.strip():
            continue
        task = None
        try:
            task = json.loads(line)
            if task.get("action") == "stop":
                break
            with Image.open(task["image"]) as image, torch.inference_mode():
                pixels = transform(image).unsqueeze(0).to(dev)
                features = mod.backbone_features(model, pixels, "hf")
                if features.shape[1] != dim:
                    raise ValueError("DINO feature dimension mismatch")
                prob2 = torch.softmax(head_2(features), dim=1)[0].cpu().tolist()
                is_defect = bool(prob2[defect_idx] >= 0.5)
                if is_defect:
                    prob11 = torch.softmax(head_11(features), dim=1)[0].cpu().tolist()
                    stage2 = [{"class": ckpt["class_names"][i], "score": round(prob11[i], 6)}
                              for i in sorted(range(len(prob11)), key=lambda j: prob11[j], reverse=True)]
                    candidate = stage2[0]["class"]
                else:
                    stage2 = None
                    candidate = "normal"
            result = {"source": "persistent_dino_predict", "candidate": candidate,
                      "is_defect": is_defect, "stage1_normal_vs_defect":
                      {name: round(score, 6) for name, score in zip(ckpt["binary_names"], prob2)},
                      "stage2_defect_type": stage2, "input_image": str(Path(task["image"]).resolve())}
            emit({"kind": "result", "id": task["id"], "ok": True, "result": result})
        except Exception as exc:
            emit({"kind": "result", "id": task.get("id") if isinstance(task, dict) else None,
                  "ok": False, "error": str(exc), "traceback": traceback.format_exc()})


def prepare_messages(request, prompt):
    # Single-image flow's original build_messages is reused when there is a valid composite.
    composite = request.get("composite_image")
    meta = request.get("composite_metadata")
    if composite and meta and Path(composite).is_file():
        from qwen_task1 import build_messages
        return build_messages(request, prompt)
    # Honest single-view fallback: no fabricated RGB image or misleading detector claims.
    dino = request["dino"]
    candidate = request.get("report_candidate") or dino["candidate"]
    is_defect = dino.get("is_defect", True)
    hint = ("DINOv3判断原图正常（非人工真值）。仍须以原图证据判定。" if not is_defect
            else f"DINOv3提供的整图缺陷类型候选：{candidate}（非人工真值）。以原图可见证据为准。")
    ref_images = request.get("reference_images", {})
    i00_path = ref_images.get("00")
    i01_path = ref_images.get("01")
    has_i00 = i00_path and Path(i00_path).is_file()
    has_i01 = i01_path and Path(i01_path).is_file()
    ref_text = ""
    if has_i00 and has_i01:
        ref_text = (
            "第二张图是同一缺陷实例的I00全图，第三张图是同一位置的I01正常对比图。"
            "I00用于辅助确认缺陷全局位置，I01用于对比定位异常边界。"
            "对比时以第一张原图为准，第二、三张仅供参照。\n"
        )
    elif has_i01:
        ref_text = (
            "第二张图是同一位置的I01正常对比图（无缺陷状态），"
            "用于辅助定位缺陷位置和确认异常边界。对比时以第一张原图为准。\n"
        )
    elif has_i00:
        ref_text = (
            "第二张图是同一缺陷实例的I00全图，用于辅助确认缺陷全局位置。"
            "对比时以第一张原图为准。\n"
        )
    text = (f"layer：{request['layer']}\n"
            "仅提供一张原始SEM图。当前没有可靠的I02/I03/I04三探测器RGB合成图；"
            "不得臆测探测器支持的凹凸关系。位置坐标以此原图为准。\n"
            + ref_text + hint + "\n请严格按照系统提示词的最终格式输出。")
    content = [
        {"type": "image", "url": request["original_input"]},
        {"type": "text", "text": "第一张：原始SEM图（报告位置坐标基准）。"},
    ]
    img_label = 2
    if has_i00:
        content.append({"type": "image", "url": i00_path})
        content.append({"type": "text", "text": f"第{['一','二','三','四','五'][img_label]}张：I00缺陷全图（同一实例全视野参考）。"})
        img_label += 1
    if has_i01:
        content.append({"type": "image", "url": i01_path})
        content.append({"type": "text", "text": f"第{['一','二','三','四','五'][img_label]}张：I01正常对比图（同一位置无缺陷状态）。"})
        img_label += 1
    content.append({"type": "text", "text": text})
    return [{"role": "system", "content": [{"type": "text", "text": prompt}]},
            {"role": "user", "content": content}]


def qwen_role(args):
    # Keep EXACT SAME model/processor and generation API as successful qwen_task1.run_local.
    import torch
    from transformers import AutoModelForMultimodalLM, AutoProcessor
    from sem_report_format import validate_result

    model_dir = Path(args.qwen_model_dir)
    if not model_dir.is_dir() or not (model_dir / "config.json").is_file():
        raise FileNotFoundError(model_dir)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable in the Qwen Python environment")
    processor = AutoProcessor.from_pretrained(str(model_dir), trust_remote_code=True, local_files_only=True)
    model = AutoModelForMultimodalLM.from_pretrained(
        str(model_dir), trust_remote_code=True, local_files_only=True,
        torch_dtype=torch.bfloat16, device_map="auto", low_cpu_mem_usage=True).eval()
    prompt = Path(args.prompt).read_text(encoding="utf-8-sig").strip()
    if not prompt:
        raise ValueError("Prompt is empty")
    import transformers
    emit({"kind": "ready", "role": "qwen", "transformers": transformers.__version__,
          "python": sys.executable, "processor": type(processor).__name__,
          "model": type(model).__name__})
    for line in sys.stdin:
        if not line.strip():
            continue
        task = None
        try:
            task = json.loads(line)
            if task.get("action") == "stop":
                break
            request = json.loads(Path(task["request"]).read_text(encoding="utf-8-sig"))
            messages = prepare_messages(request, prompt)
            # The local multimodal processor expects every message.content to
            # be a list of typed dicts. Normalize even system-only text, while
            # preserving the exact text and image order.
            for message in messages:
                content = message.get("content")
                if isinstance(content, str):
                    message["content"] = [{"type": "text", "text": content}]
                elif not isinstance(content, list):
                    raise TypeError(f"Unsupported chat content type: {type(content).__name__}")
                elif any(not isinstance(block, dict) or "type" not in block for block in content):
                    raise TypeError("Chat content items must be typed dictionaries")
            inputs = processor.apply_chat_template(
                messages, add_generation_prompt=True, tokenize=True, return_dict=True,
                return_tensors="pt", enable_thinking=args.enable_thinking,
                reasoning_effort=args.reasoning_effort, preserve_thinking=False)
            input_length = inputs["input_ids"].shape[1]
            tail = processor.tokenizer.decode(inputs["input_ids"][0], skip_special_tokens=False)
            if not args.enable_thinking and not tail.rstrip().endswith("</think>"):
                raise RuntimeError("Qwen template did not close thinking mode as expected")
            device = model.get_input_embeddings().weight.device
            if device.type == "meta":
                raise RuntimeError("Qwen embeddings on meta; check device_map")
            inputs = {key: value.to(device) if torch.is_tensor(value) else value for key, value in inputs.items()}
            started = time.perf_counter()
            with torch.inference_mode():
                output = model.generate(**inputs, max_new_tokens=task["max_new_tokens"], do_sample=False,
                                        use_cache=True, pad_token_id=processor.tokenizer.pad_token_id,
                                        eos_token_id=processor.tokenizer.eos_token_id)
            if torch.cuda.is_available():
                torch.cuda.synchronize()
            ids = output[0, input_length:]
            raw_decoded = processor.tokenizer.decode(ids, skip_special_tokens=False,
                                                     clean_up_tokenization_spaces=False)
            # Split reasoning from the final report before stripping special tokens.
            if args.enable_thinking:
                if "</think>" in raw_decoded:
                    reasoning_raw, answer_raw = raw_decoded.split("</think>", 1)
                else:
                    reasoning_raw, answer_raw = raw_decoded, ""
                reasoning = processor.tokenizer.decode(
                    processor.tokenizer.encode(reasoning_raw, add_special_tokens=False),
                    skip_special_tokens=True, clean_up_tokenization_spaces=False).strip()
            else:
                reasoning, answer_raw = "", raw_decoded
            final = processor.tokenizer.decode(
                processor.tokenizer.encode(answer_raw, add_special_tokens=False),
                skip_special_tokens=True, clean_up_tokenization_spaces=False).strip()
            eos = model.generation_config.eos_token_id
            eos_set = {eos} if isinstance(eos, int) else set(eos or [])
            if not eos_set and processor.tokenizer.eos_token_id is not None:
                eos_set = {processor.tokenizer.eos_token_id}
            ended = bool(ids.numel() and ids[-1].item() in eos_set)
            result = {"status": "complete" if ended and final else "incomplete", "final": final,
                      "ended_with_eos": ended, "generated_tokens": int(ids.numel()),
                      "generation_seconds": round(time.perf_counter() - started, 3),
                      "reached_token_limit": int(ids.numel()) >= task["max_new_tokens"],
                      "layer": request["layer"], "dino_candidate": request["dino"]["candidate"]}
            result["enable_thinking"] = args.enable_thinking
            result["reasoning_effort"] = args.reasoning_effort
            result["reasoning"] = reasoning
            if args.enable_thinking and "</think>" not in raw_decoded:
                result["status"] = "incomplete"
                result["reasoning_incomplete"] = True
            validate_result(result, request["layer"])
            if result.get("reasoning_incomplete"):
                result["status"] = "incomplete"
            emit({"kind": "result", "id": task["id"], "ok": True, "result": result})
        except Exception as exc:
            emit({"kind": "result", "id": task.get("id") if isinstance(task, dict) else None,
                  "ok": False, "error": str(exc), "traceback": traceback.format_exc()})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--role", required=True, choices=("dino", "qwen"))
    parser.add_argument("--dino-script")
    parser.add_argument("--dino-model-dir")
    parser.add_argument("--dino-head")
    parser.add_argument("--dino-device", default="cuda")
    parser.add_argument("--qwen-model-dir")
    parser.add_argument("--prompt")
    parser.add_argument("--reasoning-effort", choices=("low", "medium", "high", "xhigh"), default="low")
    parser.add_argument("--enable-thinking", action="store_true")
    args = parser.parse_args()
    try:
        if args.role == "dino":
            dino_role(args)
        else:
            qwen_role(args)
    except Exception as exc:
        emit({"kind": "init_error", "role": args.role, "error": str(exc),
              "traceback": traceback.format_exc()})
        raise


if __name__ == "__main__":
    main()