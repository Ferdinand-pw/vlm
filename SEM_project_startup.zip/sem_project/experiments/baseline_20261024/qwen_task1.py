#!/usr/bin/env python3
"""Use original SEM + three-view composite + DINO candidate in local Qwen."""
from __future__ import annotations

import argparse
import json
import os
import re
import time
from pathlib import Path

from PIL import Image

os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

REPORT_TYPES = {
    "Particle_422", "Void_471", "C-Residue_4197",
    "Bump_411", "Masking_433", "InFilm_413",
    "normal", "unknown",
}


def normalize_report(text: str) -> str:
    """Only normalize whitespace and split morphology/type headers.

    Never invent defects, relabel classes, or change coordinates.
    """
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    out = []
    i = 0
    while i < len(lines):
        if lines[i] == "形貌：" and i + 1 < len(lines) and lines[i + 1].startswith("[类型]"):
            out.append("形貌：" + lines[i + 1])
            i += 2
        else:
            out.append(lines[i])
            i += 1
    return "\n".join(out)


def format_errors(text: str, layer: str) -> list[str]:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    errors = []
    if not lines or lines[0] != f"layer：{layer}":
        errors.append("Layer does not match source metadata")
    if len(lines) == 2 and lines[1] == "图像正常":
        return errors
    match = re.fullmatch(r"存在([1-9]\d*)处缺陷", lines[1]) if len(lines) > 1 else None
    if not match:
        return errors + ["Missing valid defect count or normal-image line"]
    count = int(match.group(1))
    if len(lines) != 2 + 8 * count:
        return errors + ["Defect count does not match eight-line blocks"]
    for index in range(count):
        block = lines[2 + 8 * index:2 + 8 * (index + 1)]
        if block[0] != f"缺陷{index + 1}：":
            errors.append(f"Defect {index + 1}: numbering")
        box = re.fullmatch(r"位置：.+，相对位置\[(\d+),(\d+),(\d+),(\d+)\]", block[1])
        if not box:
            errors.append(f"Defect {index + 1}: position format")
        elif not (0 <= int(box.group(1)) < int(box.group(3)) <= 1000 and
                  0 <= int(box.group(2)) < int(box.group(4)) <= 1000):
            errors.append(f"Defect {index + 1}: bbox coordinate range")
        type_match = re.fullmatch(r"形貌：\[类型\](.+)；", block[2])
        if not type_match or type_match.group(1) not in REPORT_TYPES:
            errors.append(f"Defect {index + 1}: type format")
        if not block[3].startswith("[形状]") or not block[4].startswith("[交互]") or not block[5].startswith("[方向]"):
            errors.append(f"Defect {index + 1}: missing attributes")
        if not block[6].startswith("尺寸：") or not re.fullmatch(
                r"严重程度：(1\(轻微\)|2\(中等\)|3\(严重\))", block[7]):
            errors.append(f"Defect {index + 1}: missing size/severity")
    return errors


def build_messages(request: dict, prompt: str) -> list[dict]:
    layer = request["layer"]
    dino = request["dino"]
    candidate = dino["candidate"]
    is_defect = dino.get("is_defect", True)
    composite = request.get("composite_metadata")
    has_composite = composite is not None and request.get("composite_image")
    dino_score = None
    if isinstance(dino.get("stage2_defect_type"), list) and dino["stage2_defect_type"]:
        dino_score = dino["stage2_defect_type"][0].get("score")
    candidate_text = request.get("report_candidate") or candidate
    if not is_defect:
        dino_text = (
            "独立DINOv3视觉分类器判断该图为正常图（无缺陷），正常置信度较高。"
            "它是模型预测，不是人工真值；若图像证据与候选冲突，按图像和系统提示词判定。"
        )
    else:
        score_text = f"（模型置信度 {dino_score:.2f}）" if dino_score is not None else ""
        dino_text = (
            f"独立DINOv3视觉分类器给出的整图缺陷类型候选：{candidate_text}{score_text}。"
            "它是模型预测，不是人工真值，也不是每处缺陷的独立分类。"
            "请综合原图可见形貌和三探测器合成图判断该候选类型是否与图像证据一致。"
            "若图像证据与候选明显冲突，按图像为准；报告只输出规定字段，不追加解释。"
            "不要把类别分数、文件名或路径写入结果，也不要从layer名称推断类型或严重程度。"
        )
    channel_text = ""
    if has_composite:
        channel_text = "；".join(
            f"{ch}=文件名I{composite['channels'][ch]['view_code']}，"
            f"{composite['channels'][ch]['detector']}，检测器位于{composite['channels'][ch]['direction']}"
            for ch in ("R", "G", "B")
        )
    if not is_defect:
        text = (
            f"layer：{layer}\n"
            f"{dino_text}\n"
            "请检查原图确认是否存在缺陷。若确认无缺陷，输出'图像正常'。"
        )
        content = [
            {"type": "image", "url": request["original_input"]},
            {"type": "text", "text": "第一张：原始SEM图。"},
            {"type": "text", "text": text},
        ]
    else:
        ref_images = request.get("reference_images", {})
        i00_path = ref_images.get("00")
        i01_path = ref_images.get("01")
        has_i00 = i00_path and Path(i00_path).is_file()
        has_i01 = i01_path and Path(i01_path).is_file()
        ref_text = ""
        if has_i00 and has_i01:
            ref_text = (
                "第三张图是同一缺陷实例的I00全图（缺陷左下全视野），"
                "第四张图是同一位置的I01正常对比图（无缺陷状态）。"
                "I00用于辅助确认缺陷全局位置和结构关系，I01用于对比定位异常边界和形貌变化。"
                "对比时以第一张原图为准，第三、四张仅供参照，不作为坐标基准。\n"
            )
        elif has_i01:
            ref_text = (
                "第三张图是同一位置的I01正常对比图（无缺陷状态），"
                "用于辅助定位缺陷位置、确认异常边界和对比形貌变化。"
                "对比时以第一张原图为准，第三张仅供参照，不作为坐标基准。\n"
            )
        elif has_i00:
            ref_text = (
                "第三张图是同一缺陷实例的I00全图（缺陷左下全视野），"
                "用于辅助确认缺陷全局位置和结构关系。"
                "对比时以第一张原图为准，第三张仅供参照，不作为坐标基准。\n"
            )
        text = (
            f"layer：{layer}\n"
            "第一张图是待描述的原始SEM图；第二张图是同一缺陷位置的三个探测器灰度信号合成图，"
            "仅用于辅助判断凹凸及确认可见形貌，不是真实材料颜色。两张图中的同一异常只计一次。\n"
            f"第二张图通道：{channel_text}。\n"
            f"{ref_text}"
            f"{dino_text}\n"
            "位置坐标以第一张原图为准。请严格输出系统提示词规定的结构化描述；证据不足时按提示词使用未知/未能判定。"
        )
        content = [
            {"type": "image", "url": request["original_input"]},
            {"type": "text", "text": "第一张：原始SEM图（报告坐标基准）。"},
            {"type": "image", "url": request["composite_image"]},
            {"type": "text", "text": "第二张：I02/I03/I04 三探测器RGB通道合成图。"},
        ]
        if has_i00:
            content.append({"type": "image", "url": i00_path})
            content.append({"type": "text", "text": "第三张：I00缺陷全图（同一实例的全视野参考）。"})
        if has_i01:
            label = "第四张" if has_i00 else "第三张"
            content.append({"type": "image", "url": i01_path})
            content.append({"type": "text", "text": f"{label}：I01正常对比图（同一位置无缺陷状态）。"})
        content.append({"type": "text", "text": text})
    return [{"role": "system", "content": [{"type": "text", "text": prompt}]},
            {"role": "user", "content": content}]


def run_local(messages: list[dict], model_dir: Path, max_new_tokens: int) -> dict:
    import torch
    from transformers import AutoModelForMultimodalLM, AutoProcessor

    if not model_dir.is_dir() or not (model_dir / "config.json").is_file():
        raise FileNotFoundError(f"Local Qwen model directory is incomplete: {model_dir}")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable for local Qwen; use --backend preview first")
    processor = AutoProcessor.from_pretrained(str(model_dir), trust_remote_code=True, local_files_only=True)
    model = AutoModelForMultimodalLM.from_pretrained(
        str(model_dir), trust_remote_code=True, local_files_only=True,
        torch_dtype=torch.bfloat16, device_map="auto", low_cpu_mem_usage=True).eval()
    inputs = processor.apply_chat_template(
        messages, add_generation_prompt=True, tokenize=True, return_dict=True,
        return_tensors="pt", enable_thinking=False, reasoning_effort="low", preserve_thinking=False)
    input_length = inputs["input_ids"].shape[1]
    tail = processor.tokenizer.decode(inputs["input_ids"][0], skip_special_tokens=False)
    if not tail.rstrip().endswith("</think>"):
        raise RuntimeError("Qwen template did not close thinking mode as expected")
    device = model.get_input_embeddings().weight.device
    if device.type == "meta":
        raise RuntimeError("Qwen embedding is offloaded to meta; check device_map")
    inputs = {key: value.to(device) if torch.is_tensor(value) else value for key, value in inputs.items()}
    started = time.perf_counter()
    with torch.inference_mode():
        output = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False,
                                use_cache=True, pad_token_id=processor.tokenizer.pad_token_id,
                                eos_token_id=processor.tokenizer.eos_token_id)
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    ids = output[0, input_length:]
    final = processor.tokenizer.decode(ids, skip_special_tokens=True,
                                       clean_up_tokenization_spaces=False).strip()
    eos = model.generation_config.eos_token_id
    eos_set = {eos} if isinstance(eos, int) else set(eos or [])
    if not eos_set and processor.tokenizer.eos_token_id is not None:
        eos_set = {processor.tokenizer.eos_token_id}
    ended = bool(ids.numel() and ids[-1].item() in eos_set)
    return {"status": "complete" if ended and final else "incomplete", "final": final,
            "ended_with_eos": ended, "generated_tokens": int(ids.numel()),
            "generation_seconds": round(time.perf_counter() - started, 3),
            "reached_token_limit": int(ids.numel()) >= max_new_tokens}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", required=True, help="Prepared JSON from task1_pipeline.py")
    parser.add_argument("--prompt", required=True, help="Local Markdown prompt")
    parser.add_argument("--backend", choices=("preview", "local-hf"), default="preview")
    parser.add_argument("--model-dir", help="Local Qwen3.8-27B directory")
    parser.add_argument("--max-new-tokens", type=int, default=2048)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.max_new_tokens < 1 or args.backend == "local-hf" and not args.model_dir:
        parser.error("Invalid token count or missing --model-dir")
    request = json.loads(Path(args.request).read_text(encoding="utf-8-sig"))
    if request.get("status") != "prepared_from_real_files":
        raise ValueError("Qwen request must be prepared from real local files")
    for field in ("original_input",):
        if not Path(request[field]).is_file():
            raise FileNotFoundError(request[field])
    if request.get("composite_image"):
        if not Path(request["composite_image"]).is_file():
            raise FileNotFoundError(request["composite_image"])
        with Image.open(request["original_input"]) as one, Image.open(request["composite_image"]) as two:
            if one.size != two.size:
                raise ValueError("Original and composite image sizes differ")
    prompt = Path(args.prompt).read_text(encoding="utf-8-sig").strip()
    if not prompt:
        raise ValueError("Prompt is empty")
    messages = build_messages(request, prompt)
    if args.backend == "preview":
        result = {"status": "preview_only_no_model_called", "messages": messages,
                  "dino_candidate": request["dino"]["candidate"], "layer": request["layer"]}
    else:
        result = run_local(messages, Path(args.model_dir), args.max_new_tokens)
        result["raw_final"] = result["final"]
        result["final"] = normalize_report(result["final"])
        result["layer"] = request["layer"]
        result["dino_candidate"] = request["dino"]["candidate"]
        result["format_errors"] = format_errors(result["final"], request["layer"])
        if result["status"] == "complete" and result["format_errors"]:
            result["status"] = "invalid_format"
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.backend == "local-hf":
        report = output.with_suffix(".md")
        # Always save the model's actual report, even if validation fails.
        report.write_text(result.get("final", "").strip() + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()