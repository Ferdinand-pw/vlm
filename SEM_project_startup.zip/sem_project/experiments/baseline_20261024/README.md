# 2026年10月24日用户提供的最新实验基线

本目录7个附件原样保存，代码未修改。source_manifest.json记录附件ID、字节数与SHA256。task1_pipeline.py是按脚本用途指定的归档文件名，原附件未提供原文件名。保留相邻模块布局，避免直接拆目录导致import失效。旧版在legacy/v0。

已通过6个Python文件的语法解析检查；未加载GPU模型、未运行训练或真实SEM推理。批处理仍缺sem_report_format.py；单图编排还缺dino_bridge.py。qwen_task1.py中有部分本地格式函数，但不能据此认定它可替代缺失模块的validate_result接口。

## 已核实实现

- dinov3_sem_train_hf.py使用共享骨干、正常异常头和6类缺陷类型头。head_11是变量名，不表示当前有11类。正常样本参与二分类损失，类型损失只使用缺陷样本。
- make_transform使用ImageOps.pad、BICUBIC、RGB转换、黑色居中补边和指定归一化。传入--image-size 512即在线生成512输入。现有离线工具使用LANCZOS，两者不能默认等价，也不必为统一尺寸先保存所有512副本。
- classifier.pth保存两个头；unfreeze_layers非零时还保存backbone_state_dict，预测会恢复它。这里只确认保存和恢复的代码，尚未检查服务器上已有权重文件。
- source_views已接受I00至I04，并增加find_reference_views。
- batch_run50在预测异常时查找I00/I01并写入reference_images；qwen_task1和persistent worker会将存在的参考图加入多模态消息。该链路是代码接入，尚非真实效果验证。
- 当前训练接口要求normal及6个缺陷类目录，不直接支持方案中拆分的A-only或B-only数据集。分任务训练是后续改造，不应直接拿task_a/task_b目录套此脚本。

## 继续接项目前需处理

1. v5提示词要求DINO判正常就直接输出正常；batch同时跳过RGB和I00/I01检索。与10月19日方案中的“模型候选不截断视觉复核”不同。本次尊重最新附件原样保留，没有擅自改策略。
2. compose_views仍要求三个探测器图和入口图同尺寸；qwen_task1入口也有原图与RGB尺寸检查，因此全图与局部图不同尺寸仍受限。
3. 单图编排task1_pipeline.py未调用find_reference_views、未写reference_images；不能把批处理的I01接入状态泛化到所有入口。
4. 无RGB路径prepare_messages中img_label初始值为2，而中文序数数组从0开始；实际第2/3张参考图被标成第3/4张。文字还写“仅提供一张”，与附带参考图不一致。
5. find_reference_views对同角色多个匹配文件采用覆盖赋值，缺少歧义拒绝；批处理重复源图审计主要比较RGB，未覆盖I00/I01参考内容。应补参考证据身份校验。
6. resume尚未完整验证I00/I01、模型权重、Prompt和预处理配置；使用旧output-root可能跳过新参考图构造，建议新实验使用新目录。
7. 尚无独立看图复核模型、属性多角色调用或离线512 manifest接入。prompts/reviewer_v1.md和evidence_roles_v5.md是先前方案草案，不是本目录实际使用的prompt_task1.md。

## 下一次需要的文件

补齐sem_report_format.py与dino_bridge.py即可继续核对本地模块接口；真实端到端测试还需要模型、少量同案例I00至I04和实际目录命名。本目录未进行自动修复或改写提示词。
