#!/usr/bin/env python3
"""Index original SEM files, resolve one source image, and combine views 02/03/04.

The only accepted detector mapping is the mapping confirmed by the user:
02 = Topography1 / lower-left / R,
03 = Topography2 / upper-right / G,
04 = Central / upper-center / B.
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from pathlib import Path

from PIL import Image

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
DEFAULT_VIEW_REGEX = r"I(?P<view>0[0-4])(?![A-Za-z0-9])"
VIEWS = {
    "02": {"channel": "R", "detector": "Topography1", "direction": "图像左下方"},
    "03": {"channel": "G", "detector": "Topography2", "direction": "图像右上方"},
    "04": {"channel": "B", "detector": "Central", "direction": "图像正上方"},
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_index(source_root: Path, database: Path) -> dict:
    root = source_root.resolve()
    if not root.is_dir():
        raise NotADirectoryError(root)
    database.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(database)
    try:
        connection.execute("CREATE TABLE IF NOT EXISTS files (name TEXT NOT NULL, path TEXT PRIMARY KEY)")
        connection.execute("CREATE INDEX IF NOT EXISTS files_name_idx ON files(name)")
        connection.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        connection.execute("DELETE FROM files")
        count = 0
        batch = []
        for file in root.rglob("*"):
            if file.is_file() and file.suffix.lower() in IMAGE_EXTS:
                batch.append((file.name, str(file.resolve())))
                count += 1
                if len(batch) >= 1000:
                    connection.executemany("INSERT INTO files(name,path) VALUES (?,?)", batch)
                    batch.clear()
        if batch:
            connection.executemany("INSERT INTO files(name,path) VALUES (?,?)", batch)
        connection.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES ('source_root',?)", (str(root),))
        connection.commit()
        return {"source_root": str(root), "indexed_images": count, "index_db": str(database.resolve())}
    finally:
        connection.close()


def resolve_original(query: Path, database: Path) -> tuple[Path, str]:
    """Use exact filename; if duplicated, require unique matching file bytes."""
    query = query.resolve()
    if not query.is_file():
        raise FileNotFoundError(query)
    if not database.is_file():
        raise FileNotFoundError(f"Source index missing: {database}; run index first")
    connection = sqlite3.connect(database)
    try:
        root_row = connection.execute("SELECT value FROM metadata WHERE key='source_root'").fetchone()
        if root_row is None:
            raise ValueError("Source index has no source_root metadata")
        root = Path(root_row[0])
        candidates = [Path(row[0]) for row in connection.execute(
            "SELECT path FROM files WHERE name=?", (query.name,))]
    finally:
        connection.close()
    candidates = [file for file in candidates if file.is_file()]
    if not candidates:
        raise FileNotFoundError(f"No original with exact filename {query.name!r} under {root}")
    if query in candidates:
        return query, "same_path"
    query_hash = sha256_file(query)
    if len(candidates) == 1:
        if sha256_file(candidates[0]) != query_hash:
            raise ValueError(f"The only source with filename {query.name!r} has different bytes from the input. "
                             "Verify the source image and filename before inferring layer or detector views.")
        return candidates[0], "unique_filename"
    matching = [file for file in candidates if sha256_file(file) == query_hash]
    if len(matching) == 1:
        return matching[0], "unique_content_among_same_name"
    raise ValueError(f"Ambiguous source for {query.name!r}: {len(candidates)} filename matches, "
                     f"{len(matching)} byte-identical matches. Provide a unique original path or rename the query copy.")


def layer_from_path(source: Path, *, anchor: str | None, parent: int | None) -> str:
    directories = source.resolve().parent.parts
    if (anchor is None) == (parent is None):
        raise ValueError("Choose exactly one of layer_anchor or layer_parent")
    if anchor is not None:
        indices = [i for i, part in enumerate(directories) if part == anchor]
        if len(indices) != 1 or indices[0] + 1 >= len(directories):
            raise ValueError(f"Layer anchor {anchor!r} does not occur exactly once before a child directory")
        layer = directories[indices[0] + 1]
    else:
        if parent < 1 or parent > len(directories):
            raise ValueError("Invalid layer parent depth")
        layer = directories[-parent]
    if not re.fullmatch(r"[\w.-]{1,64}", layer, re.UNICODE):
        raise ValueError(f"Suspicious layer directory name: {layer!r}")
    return layer


def view_key(file: Path, pattern: re.Pattern) -> tuple[str, str]:
    matches = list(pattern.finditer(file.stem))
    if len(matches) != 1:
        raise ValueError(f"Expected one 02/03/04 view token in {file.name!r}; found {len(matches)}. "
                         "Set --view-regex for the actual filename pattern.")
    match = matches[0]
    code = match.group("view")
    if code not in {*VIEWS, "00", "01"}:
        raise ValueError(f"Unexpected view code: {code}")
    start, end = match.span("view")
    return code, file.stem[:start - 1] + "<VIEW>" + file.stem[end:]


def find_views(original: Path, view_regex: str) -> dict[str, Path]:
    try:
        pattern = re.compile(view_regex)
    except re.error as exc:
        raise ValueError(f"Invalid view regex: {exc}") from exc
    if "view" not in pattern.groupindex:
        raise ValueError("--view-regex needs a named capture group (?P<view>02|03|04)")
    _, target_key = view_key(original, pattern)
    found: dict[str, list[Path]] = {code: [] for code in VIEWS}
    for sibling in original.parent.iterdir():
        if not sibling.is_file() or sibling.suffix.lower() not in IMAGE_EXTS:
            continue
        try:
            code, key = view_key(sibling, pattern)
        except ValueError:
            continue
        if code in found and key == target_key:
            found[code].append(sibling.resolve())
    if any(len(files) != 1 for files in found.values()):
        detail = {code: [str(path) for path in files] for code, files in found.items()}
        raise ValueError(f"Need exactly one sibling per view 02/03/04 for {original.name}: {detail}")
    return {code: files[0] for code, files in found.items()}


def find_reference_views(original: Path, view_regex: str) -> dict[str, Path]:
    """Find I00 (defect full view) and I01 (normal reference) for the same instance.

    Returns dict with keys "00" and/or "01", excluding the original itself.
    - If original is I00: returns {"01": path} only.
    - If original is I01: returns {"00": path} only.
    - If original is I02/I03/I04: returns {"00": path, "01": path} if found.
    - Missing views are simply omitted from the dict.
    """
    try:
        pattern = re.compile(view_regex)
    except re.error:
        return {}
    if "view" not in pattern.groupindex:
        return {}
    try:
        input_code, target_key = view_key(original, pattern)
    except ValueError:
        return {}
    result = {}
    for sibling in original.parent.iterdir():
        if not sibling.is_file() or sibling.suffix.lower() not in IMAGE_EXTS:
            continue
        try:
            code, key = view_key(sibling, pattern)
        except ValueError:
            continue
        if key != target_key:
            continue
        if code == "00" and input_code != "00":
            result["00"] = sibling.resolve()
        elif code == "01" and input_code != "01":
            result["01"] = sibling.resolve()
    return result


def grayscale_8bit(path: Path) -> Image.Image:
    with Image.open(path) as opened:
        if getattr(opened, "n_frames", 1) != 1:
            raise ValueError(f"Multi-frame image is not supported: {path}")
        if opened.mode == "L":
            return opened.copy()
        if opened.mode in {"RGB", "RGBA"}:
            rgb = opened.convert("RGB")
            r, g, b = rgb.split()
            if r.tobytes() == g.tobytes() == b.tobytes():
                return r
        raise ValueError(f"Expected an 8-bit grayscale SEM view at {path}; got mode {opened.mode}. "
                         "Convert 16-bit or color inputs explicitly with a documented rule before inference.")


def compose_views(views: dict[str, Path], original_input: Path, output: Path, metadata: Path) -> dict:
    channels = {code: grayscale_8bit(views[code]) for code in VIEWS}
    sizes = {image.size for image in channels.values()}
    with Image.open(original_input) as source:
        input_size = source.size
    if len(sizes) != 1 or input_size not in sizes:
        raise ValueError(f"Original and three detector images must align and have identical size: "
                         f"views={dict((k, v.size) for k, v in channels.items())}, original={input_size}")
    output.parent.mkdir(parents=True, exist_ok=True)
    composite = Image.merge("RGB", (channels["02"], channels["03"], channels["04"]))
    composite.save(output)
    payload = {"kind": "three_detector_sem_composite", "image_size_wh": list(input_size),
               "original_input": str(original_input.resolve()), "composite": str(output.resolve()),
               "channels": {VIEWS[code]["channel"]: {"view_code": code,
                           "detector": VIEWS[code]["detector"], "direction": VIEWS[code]["direction"],
                           "source_path": str(views[code]), "sha256": sha256_file(views[code])}
                            for code in VIEWS}}
    metadata.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload