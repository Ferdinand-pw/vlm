# SEM 项目起步包

2026年10月25日新增：[机台类型可信度实验模块](docs/机台类型可信度实验使用说明.md)。使用冻结DINOv3按Layer及探测器视图检索，支持I02/I03/I04单独评分和案例融合，保留机台原类型，输出复核证据。入口为scripts/evaluate/label_audit.py；先运行demo无需GPU。与下面的原六类分类及描述实验独立。

当前实验基线已更新为[2026年10月24日版本](experiments/baseline_20261024/README.md)，由configs/current_baseline.json指向。7份最新附件原样归档；批处理已有I00/I01图像输入，训练脚本已有在线512缩放补边。6份Python语法检查通过，尚未进行GPU端到端验证。旧附件保留在legacy/v0。

独立resize工具及复核提示词属于10月19日的项目起步内容。最新训练脚本使用BICUBIC，离线工具使用LANCZOS；不建议直接混用并视为同一预处理。独立视觉复核仍未接入。技术方案描述目标设计，实际代码状态以最新基线说明为准。

本地根目录为 `D:/AI_wp/SEM_description/sem_project`；公司服务器建议使用 `/input/sem_project`。目录内按相对路径组织，结构完全一致。详细分工见[目录与迁移说明](docs/目录与迁移说明.md)，方案正文见[技术方案](docs/技术方案.md)。模型、数据目录是占位，未放入真实权重和数据。

先在项目根目录执行 `python scripts/init_workspace.py`，可补齐压缩包中不保留的空目录。配置分别放在 `configs/paths.local.json` 和 `configs/paths.server.json`，不把个人绝对路径写死在业务代码里。当前resize命令仍显式传参，路径配置供后续流水线接入使用。

## 先运行512派生集

保留已有train/val/test/class目录结构，不替你重新划分案例。正式实验应先完成按案例/重复缺陷分组划分。

```bash
python -m pip install -r requirements.txt
python scripts/data/resize_dataset.py --help
python scripts/data/resize_dataset.py --source /input/sem_project/data/interim/task_b --output /input/sem_project/data/processed/task_b_512_v1 --size 512
python -m unittest discover -s tests -v
```

工具生成新PNG、manifest.jsonl和preprocessing.json。状态为complete才算本次派生完成。输入位深不支持时明确拒绝，不自动压缩16位；输出已存在时拒绝覆盖。请使用全新输出目录重试，不把未完成目录用于训练。

派生文件名称保留原扩展名，例如a.jpg变为a.jpg.png，避免同名不同格式覆盖。ImageFolder式训练一般可读取，但应核对你的训练代码。现有test1200.tsv与旧batch脚本仍用原图，不能直接将--test-root切换到派生目录：原始文件名及哈希匹配规则都不同。旧--source-map也不能绕过前置哈希匹配。

最新dinov3_sem_train_hf.py的make_transform已经在线等比例缩放补边，无中心裁剪。可继续使用原图加--image-size 512，不必先离线resize。若要用离线缓存，先统一插值与变换实现。当前脚本是normal加6个缺陷类别的联合双头训练，不能直接用于上面task_b-only数据；A/B拆分属于后续接口改造。

## 待接入的修改清单

1. source_views已支持I00至I04及参考检索；待处理同角色匹配歧义、入口图与局部RGB不同尺寸。
2. 最新版本采用DINO normal硬门控，与原方案不同，暂原样保留；后续明确是否继续该策略，再实现相应复核。离线manifest尚未接入。
3. 批处理已添加参考图；单图编排待补齐，worker无RGB分支的图片序号需修正。实际Prompt为最新快照的prompt_task1.md，不是prompts/evidence_roles_v5.md草案。
4. 新增复核调用：按prompts/reviewer_v1.md看同案例图像、初稿和程序校验结果；最多修订一次；保留初稿、复核、最终稿及人工复核状态。
5. sem_report_format与导出器：同步处理null、范围限定、复核状态和证据ID；旧格式校验不等于语义正确。
6. resume：将模型/图像/Prompt/预处理/生成参数/Schema版本纳入缓存身份。新实验用新output-root，避免复用旧输出。

## 缺少的文件与环境

训练脚本、worker和Qwen单图脚本已补齐；仍缺sem_report_format.py和dino_bridge.py。还需少量同案例I00至I04或完整案例路径清单，检查命名、尺寸、位深和倍率。服务器/input路径当前并未挂载到本工作区，因此没有运行真实SEM数据resize或GPU推理。

训练命令解冻末4层；最新源码确认classifier.pth会在解冻时保存骨干参数，并保存两个头及类别信息。尚未检查服务器上已有classifier.pth的实际内容。当前模型目录名仅作为部署标识，实际规格以config及加载日志为准。

工具的restore_box只负责派生图→原始源图的缩放补边回映射；不负责I02→I00的跨视野配准。测试使用合成图，覆盖原图不变、尺寸补边、坐标回映射、补边框拒绝、16位拒绝及覆盖保护，不代表SEM识别效果。
