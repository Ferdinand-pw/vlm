import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from sem.label_audit.common import load_manifest, normalize, save_cache, load_cache, write_jsonl
from sem.label_audit.retrieval import audit, config_from
from sem.label_audit.evaluation import evaluate_rows
from sem.label_audit.demo import demo
from sem.label_audit.fusion import fuse


def row(i, label, split='reference', layer='L1', group=None, view='I02', source='historical'):
    return {'sample_id': i, 'case_id': group or i, 'group_id': group or i,
            'machine_label': label, 'layer': layer, 'split': split, 'domain': 'D1',
            'view': view, 'reference_source': source, 'pixel_sha256': i,
            'image_path': 'synthetic.png'}


class LabelAuditTests(unittest.TestCase):
    def temp(self):
        return tempfile.TemporaryDirectory(prefix='_audit_test_', dir=Path(__file__).resolve().parent)

    def fixture(self):
        rows = [row(f'a{i}', 'A') for i in range(5)] + [row(f'b{i}', 'B') for i in range(5)] + [row('q', 'A', 'dev')]
        vectors = normalize([[1, 0]] * 5 + [[0, 1]] * 5 + [[0, 1]])
        config = config_from(None)
        config['k'] = [5]
        return rows, vectors, config

    def test_competitor_search_no_automatic_relabel_or_probability(self):
        rows, vectors, config = self.fixture()
        result = list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))[0]
        self.assertEqual(result['status'], 'review_recommended')
        self.assertEqual(result['competitor_label'], 'B')
        self.assertEqual(result['output_type'], 'A')
        self.assertIsNone(result['label_correct_probability'])
        self.assertEqual(result['consistency_score'], 0)

    def test_strict_layer_view_domain_and_self_exclusion(self):
        rows, vectors, config = self.fixture()
        rows += [row('other_layer', 'A', layer='L2'), row('other_view', 'A', view='I03'),
                 row('same_defect', 'A', group='q'), row('other_domain', 'A')]
        rows[-1]['domain'] = 'D2'
        vectors = np.vstack([vectors, [[0, 1]] * 4])
        result = list(audit(rows, vectors, {'L1': ['A', 'B'], 'L2': ['A', 'B']}, config, 'dev'))[0]
        self.assertEqual({n['sample_id'] for n in result['neighbors']}, {f'b{i}' for i in range(5)})

    def test_repeated_defect_cannot_fill_k(self):
        rows, vectors, config = self.fixture()
        for r in rows[5:10]:
            r['group_id'] = r['case_id'] = 'repeated'
        result = list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))[0]
        self.assertEqual(result['effective_neighbors'], 1)
        self.assertEqual(result['status'], 'insufficient_evidence')

    def test_missing_class_and_distant_query_abstain(self):
        rows, vectors, config = self.fixture()
        result = list(audit(rows, vectors, {'L1': ['A', 'B', 'C']}, config, 'dev'))[0]
        self.assertEqual(result['status'], 'insufficient_evidence')
        self.assertIn('C', result['undercovered_classes'])
        vectors[-1] = [-1, 0]
        result = list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))[0]
        self.assertEqual(result['effective_neighbors'], 0)
        self.assertIsNone(result['consistency_score'])

    def test_expert_labels_and_conflicting_reference_groups(self):
        rows, vectors, config = self.fixture()
        for r in rows[5:10]:
            r.update(machine_label='A', reference_source='expert', reference_label='B')
        result = list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))[0]
        self.assertEqual(result['competitor_label'], 'B')
        self.assertIn('B', result['expert_nearest_cosine_distance'])
        rows[5]['group_id'] = rows[0]['group_id']
        with self.assertRaises(ValueError):
            list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))

    def test_batch_isolation(self):
        rows, vectors, config = self.fixture()
        config['exclude_same_batch'] = True
        with self.assertRaises(ValueError):
            list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))
        for r in rows:
            r['batch_id'] = 'wafer_1'
        result = list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))[0]
        self.assertEqual(result['effective_neighbors'], 0)

    def test_manifest_rejects_i01_group_leakage_and_pixel_duplicates(self):
        with self.temp() as folder:
            folder = Path(folder)
            Image.new('L', (8, 8), 7).save(folder / 'one.png')
            Image.new('L', (8, 8), 8).save(folder / 'two.png')
            first, second = row('a', 'A'), row('q', 'A', 'test')
            first['image_path'], second['image_path'] = 'one.png', 'two.png'
            manifest = folder / 'manifest.jsonl'
            write_jsonl(manifest, [first, second])
            self.assertEqual(len(load_manifest(manifest)), 2)
            second['view'] = 'I01'
            write_jsonl(manifest, [first, second])
            with self.assertRaises(ValueError):
                load_manifest(manifest)
            second['view'], second['group_id'] = 'I02', 'a'
            write_jsonl(manifest, [first, second])
            with self.assertRaises(ValueError):
                load_manifest(manifest)
            second['group_id'], second['image_path'] = 'q', 'one.png'
            write_jsonl(manifest, [first, second])
            with self.assertRaises(ValueError):
                load_manifest(manifest)

    def test_cache_checksum_and_zero_vectors(self):
        with self.temp() as folder:
            folder = Path(folder)
            save_cache(folder, [row('a', 'A')], [[1, 0]], {'kind': 'test'})
            self.assertEqual(load_cache(folder)[1].shape, (1, 2))
            (folder / 'records.jsonl').write_text('{}\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                load_cache(folder)
        with self.assertRaises(ValueError):
            normalize([[0, 0]])

    def test_case_metrics_not_three_view_count(self):
        rows, vectors, config = self.fixture()
        result = list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))[0]
        scores = [{**result, 'sample_id': f'q_{i}', 'view': view} for i, view in enumerate(['I02', 'I03', 'I04'])]
        m = evaluate_rows(scores, [{'group_id': 'q', 'expert_label': 'B'}])
        self.assertEqual(m['by_k']['5']['overall']['groups'], 1)
        self.assertEqual(m['by_k']['5']['overall']['known_label_errors'], 1)

    def test_fusion_conflict_missing_and_no_triple_reference_count(self):
        rows, vectors, config = self.fixture()
        wrong = list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))[0]
        three = [{**wrong, 'sample_id': f'q_{v}', 'view': v} for v in config['views']]
        combined = fuse(three, config)[0]
        self.assertEqual(combined['status'], 'review_recommended')
        self.assertEqual(combined['unique_reference_groups'], 5)
        missing = fuse(three[:2], config)[0]
        self.assertEqual(missing['status'], 'insufficient_evidence')
        self.assertEqual(missing['views_missing'], ['I04'])
        vectors[-1] = [1, 0]
        support = list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))[0]
        three[2] = {**support, 'sample_id': 'q_I04', 'view': 'I04'}
        conflict = fuse(three, config)[0]
        self.assertTrue(conflict['cross_view_conflict'])
        self.assertEqual(conflict['status'], 'insufficient_evidence')
        self.assertIsNone(conflict['suggested_label'])
        self.assertEqual(conflict['output_type'], 'A')

    def test_fusion_duplicate_acquisition_rejected(self):
        rows, vectors, config = self.fixture()
        result = list(audit(rows, vectors, {'L1': ['A', 'B']}, config, 'dev'))[0]
        with self.assertRaises(ValueError):
            fuse([result, {**result, 'sample_id': 'q_repeat'}], config)

    def test_demo_writes_end_to_end_artifacts(self):
        with self.temp() as folder:
            output = Path(folder) / 'demo'
            demo(output)
            metrics = json.loads((output / 'evaluation/metrics.json').read_text(encoding='utf-8'))
            self.assertEqual(metrics['human_labeled_groups'], 20)
            self.assertEqual(metrics['by_k']['5']['overall']['known_label_errors'], 4)
            self.assertEqual(metrics['by_k']['5']['overall']['review_error_recall'], 1)
            with self.assertRaises(FileExistsError):
                demo(output)


if __name__ == '__main__':
    unittest.main()
