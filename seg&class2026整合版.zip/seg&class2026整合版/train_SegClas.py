import argparse
import os
from collections import OrderedDict
from glob import glob
import cv2
import pandas as pd
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
import yaml
from albumentations import transforms
import albumentations as albu
from albumentations.core.composition import Compose, OneOf
from sklearn.model_selection import train_test_split
from torch.optim import lr_scheduler
from tqdm import tqdm

from models.RARA_2262_TC_202512newjoint import RARA_2262_TC_joint


import losses
from dataset import MultiTaskDataset

from metrics import iou_score
from utils import AverageMeter, str2bool, calculate_cls_accuracy

ARCH_NAMES = ['RARA_2262_TC_clas']
LOSS_NAMES = losses.__all__
LOSS_NAMES.append('BCEWithLogitsLoss')

'''

指定参数：
--dataset dsb2018_96 
--arch NestedUNet

'''

def parse_args():
    parser = argparse.ArgumentParser() #创建 ArgumentParser() 对象    命令行解析模块argsparse，此包(package)可以使我们直接在命令行中就可以向程序中传入参数并让程序运行一次

    #基础配置
    parser.add_argument('--name', default=None,
                        help='model name: (default: arch+timestamp)') #网络名字
    parser.add_argument('--epochs', default=300, type=int, metavar='N',
                        help='number of total epochs to run')#迭代多少轮
    parser.add_argument('-b', '--batch_size', default=10, type=int,
                        metavar='N', help='mini-batch size (default: 16)')

    # 模型配置
    parser.add_argument('--arch', '-a', metavar='ARCH', default='RARA_2262_TC_joint',  #UNettest_pre 这里修改使用的网络模型名称，改完后要在下面model里换成相应。
                        help='model architecture: ' +
                        ' | '.join(ARCH_NAMES) +
                        ' (default: NestedUNet)')  #网络架构
    parser.add_argument('--deep_supervision', default=False, type=str2bool)  #监督
    parser.add_argument('--input_channels', default=3, type=int,
                        help='input channels')   #输入个数
    parser.add_argument('--num_classes', default=1, type=int,
                        help='number of classes for segmentation')
    parser.add_argument('--num_img_classes', default=5, type=int,
                        help='number of classes for image classification')  # 新增

    parser.add_argument('--input_w', default=224, type=int,
                        help='image width')
    parser.add_argument('--input_h', default=224, type=int,
                        help='image height') #图像大小
    
    # 损失函数配置
    parser.add_argument('--loss', default='BCEDiceLoss',
                        choices=LOSS_NAMES,
                        help='loss: ' +
                        ' | '.join(LOSS_NAMES) +
                        ' (default: BCEDiceLoss)')

    # ### --- 新增：增加损失权重的参数 --- ###
    parser.add_argument('--seg_loss_weight', default=1.0, type=float, help='Weight for segmentation loss')
    parser.add_argument('--cls_loss_weight', default=0.5, type=float, help='Weight for classification loss')

    
    # 数据集配置
    parser.add_argument('--dataset', default='dsb2018_96',
                        help='dataset name')
    parser.add_argument('--img_ext', default='.jpg',       #.jpg  .tif
                        help='image file extension')
    parser.add_argument('--mask_ext', default='.png',
                        help='mask file extension')

    # 优化器配置
    parser.add_argument('--optimizer', default='SGD',
                        choices=['Adam', 'SGD'],
                        help='loss: ' +
                        ' | '.join(['Adam', 'SGD']) +
                        ' (default: Adam)')
    parser.add_argument('--lr', '--learning_rate', default=1e-3, type=float,
                        metavar='LR', help='initial learning rate')
    parser.add_argument('--momentum', default=0.9, type=float,
                        help='momentum')
    parser.add_argument('--weight_decay', default=1e-4, type=float,
                        help='weight decay')
    parser.add_argument('--nesterov', default=False, type=str2bool,
                        help='nesterov')

    # 学习率调度器配置
    parser.add_argument('--scheduler', default='CosineAnnealingLR',
                        choices=['CosineAnnealingLR', 'ReduceLROnPlateau', 'MultiStepLR', 'ConstantLR'])
    parser.add_argument('--min_lr', default=1e-5, type=float,
                        help='minimum learning rate')
    parser.add_argument('--factor', default=0.1, type=float)
    parser.add_argument('--patience', default=2, type=int)
    parser.add_argument('--milestones', default='1,2', type=str)
    parser.add_argument('--gamma', default=2/3, type=float)
    parser.add_argument('--early_stopping', default=-1, type=int,
                        metavar='N', help='early stopping (default: -1)')
    #其他配置
    parser.add_argument('--num_workers', default=0, type=int)

    config = parser.parse_args()  #使用 parse_args() 解析添加的参数

    return config


def train(config, train_loader, model, criterion_seg, criterion_cls, optimizer,device):
    #添加分类准确率跟踪器
    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter(),
                  'recall':AverageMeter(),
                  'accuracy':AverageMeter(),
                  'f1':AverageMeter(),
                  'cls_acc': AverageMeter(),  # 添加分类准确率
                  'loss_seg': AverageMeter(),  # 添加分割损失
                  'loss_cls': AverageMeter()  # 添加分类损失
                  }

    model.train() #训练模型

    #### 输出训练集验证参数
    pbar = tqdm(total=len(train_loader))
    for input, seg_target, cls_target in train_loader:
        input = input.to(device)
        seg_target = seg_target.to(device)
        cls_target = cls_target.to(device)

        # ### --- 修改：处理模型的两个输出并计算联合损失 --- ###
        # 原: output = model(input)
        #1.前向传播
        seg_output, cls_output = model(input)

        # 2.计算损失
        loss_seg = criterion_seg(seg_output, seg_target)
        loss_cls = criterion_cls(cls_output, cls_target)

        # 加权合并损失
        loss = config['seg_loss_weight'] * loss_seg + config['cls_loss_weight'] * loss_cls

        # 评估分割
        iou = iou_score(seg_output, seg_target)
        #评估分类
        cls_acc = calculate_cls_accuracy(cls_output, cls_target)
        # ### --- 修改结束 --- ###

        #3.反向传播
        optimizer.zero_grad() #清零梯度
        loss.backward()  #反向传播
        optimizer.step()  #更新参数
        ## 最常见、最推荐的做法

        #更新指标
        avg_meters['loss'].update(loss.item(), input.size(0))
        avg_meters['iou'].update(iou[0], input.size(0))
        avg_meters['recall'].update(iou[1], input.size(0))
        avg_meters['accuracy'].update(iou[2], input.size(0))
        avg_meters['f1'].update(iou[3], input.size(0))
        avg_meters['cls_acc'].update(cls_acc.item(), input.size(0))  # 更新分类准确率
        avg_meters['loss_seg'].update(loss_seg.item(), input.size(0))  # 更新分割损失
        avg_meters['loss_cls'].update(loss_cls.item(), input.size(0))  # 更新分类损失

        #更新显示信息
        postfix = OrderedDict([
            ('loss', avg_meters['loss'].avg),
            ('iou', avg_meters['iou'].avg),
            ('recall', avg_meters['recall'].avg),
            ('accuracy', avg_meters['accuracy'].avg),
            ('f1', avg_meters['f1'].avg),
            ('cls_acc', f"{avg_meters['cls_acc'].avg:.4f}"),  # 添加分类准确率
            ('loss_seg', f"{avg_meters['loss_seg'].avg:.4f}"),  # 添加分割损失
            ('loss_cls', f"{avg_meters['loss_cls'].avg:.4f}"),  # 添加分类损失
        ])
        pbar.set_postfix(postfix)
        pbar.update(1)
    pbar.close()

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg),
                        ('recall', avg_meters['recall'].avg),
                        ('accuracy', avg_meters['accuracy'].avg),
                        ('f1', avg_meters['f1'].avg),
                        ('cls_acc', avg_meters['cls_acc'].avg),  # 返回分类准确率
                        ('loss_seg', avg_meters['loss_seg'].avg),  # 返回分割损失
                        ('loss_cls', avg_meters['loss_cls'].avg)  # 返回分类损失
                        ])


def validate(config, val_loader, model, criterion_seg, criterion_cls,device):

    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter(),
                  'recall': AverageMeter(),
                  'accuracy': AverageMeter(),
                  'f1': AverageMeter(),
                  'cls_acc': AverageMeter(),  # 添加分类准确率
                  'loss_seg': AverageMeter(),  # 添加分割损失
                  'loss_cls': AverageMeter()  # 添加分类损失
                  }

    model.eval()   #在模型预测阶段，如果在预测的时候忘记使用model.eval()，会导致不一致的预测结果
    #输出验证集集验证参数
    '''
    在pytorch中，tensor有一个requires_grad参数，如果设置为True，则反向传播时，该tensor就会自动求导。
    tensor的requires_grad的属性默认为False,若一个节点（叶子变量：自己创建的tensor）requires_grad被设置为True，
    那么所有依赖它的节点requires_grad都为True（即使其他相依赖的tensor的requires_grad = False）
    当requires_grad设置为False时,反向传播时就不会自动求导了，因此大大节约了显存或者说内存。
    with torch.no_grad的作用
    在该模块下，所有计算得出的tensor的requires_grad都自动设置为False。
    '''
    with torch.no_grad():
        pbar = tqdm(total=len(val_loader))
        a = 1
        for input, seg_target, cls_target in val_loader:
            input = input.to(device)
            seg_target = seg_target.to(device)
            cls_target = cls_target.to(device)
            seg_output, cls_output = model(input)

            loss_seg = criterion_seg(seg_output, seg_target)
            loss_cls = criterion_cls(cls_output, cls_target)

            loss = config['seg_loss_weight'] * loss_seg + config['cls_loss_weight'] * loss_cls

            #计算分割指标与分类指标
            iou = iou_score(seg_output, seg_target)
            cls_acc = calculate_cls_accuracy(cls_output, cls_target)


            a += 1
            #更新指标
            avg_meters['loss'].update(loss.item(), input.size(0))
            avg_meters['iou'].update(iou[0], input.size(0))
            avg_meters['recall'].update(iou[1], input.size(0))
            avg_meters['accuracy'].update(iou[2], input.size(0))
            avg_meters['f1'].update(iou[3], input.size(0))
            avg_meters['cls_acc'].update(cls_acc.item(), input.size(0))  # 更新分类准确率
            avg_meters['loss_seg'].update(loss_seg.item(), input.size(0))  # 更新分割损失
            avg_meters['loss_cls'].update(loss_cls.item(), input.size(0))  # 更新分类损失

            #更新显示信息
            postfix = OrderedDict([
                ('loss', avg_meters['loss'].avg),
                ('iou', avg_meters['iou'].avg),
                ('recall', avg_meters['recall'].avg),
                ('accuracy', avg_meters['accuracy'].avg),
                ('f1', avg_meters['f1'].avg),
                ('cls_acc', f"{avg_meters['cls_acc'].avg:.4f}"),  # 添加分类准确率
                ('loss_seg', f"{avg_meters['loss_seg'].avg:.4f}"),  # 添加分割损失
                ('loss_cls', f"{avg_meters['loss_cls'].avg:.4f}"),  # 添加分类损失
            ])
            pbar.set_postfix(postfix)
            pbar.update(1)
        pbar.close()

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg),
                        ('recall', avg_meters['recall'].avg),
                        ('accuracy', avg_meters['accuracy'].avg),
                        ('f1', avg_meters['f1'].avg),
                        ('cls_acc', avg_meters['cls_acc'].avg),  # 返回分类准确率
                        ('loss_seg', avg_meters['loss_seg'].avg),  # 返回分割损失
                        ('loss_cls', avg_meters['loss_cls'].avg)  # 返回分类损失
                        ])


def main():
    config = vars(parse_args())
    '''
        下面折叠块实现了：创建一个以网络名称命名的yml文件，并且将网络的各个参数保存在了这个yml文件当中。
    '''
    #设置设备
    device = torch.device('cuda')  #device = torch.device('cuda：0')
    print(f"使用设备: {device}")

    # 创建模型保存目录
    ####配置网络名字
    if config['name'] is None:
        if config['deep_supervision']:
            config['name'] = '%s_%s_wDS' % (config['dataset'], config['arch'])  # %s表示该位置被替换，替换内容为’‘%后面的东西
        else:
            config['name'] = '%s_%s_woDS' % (config['dataset'], config['arch'])
    os.makedirs('modelsresutsave/%s' % config['name'], exist_ok=True)  # 创建文件夹

    print('-' * 20)  # 将字符串重复整数次，上面语句的功能就是打印出连续20个“-”
    for key in config:
        print('%s: %s' % (key, config[key]))  # 打印信息
    print('-' * 20)

    #保存配置文件
    with open('modelsresutsave/%s/config.yml' % config['name'], 'w') as f:  # 如果没有指定的路径，会自动新建文件，无需先去新建。w: 只写，会清除之前写的内容
        yaml.dump(config, f)  # 将config的内容写入f(config.yml)
    '''
        代码中展示了直接调用现成损失函数和自定义损失函数的方法
        资料：https://blog.csdn.net/qq_27825451/article/details/95165265
    '''
    #定义损失函数
    # 定义 loss function (criterion)
    # 分割损失函数
    if config['loss'] == 'BCEWithLogitsLoss':
        criterion_seg = nn.BCEWithLogitsLoss().to(device)
    else:
        criterion_seg = losses.__dict__[config['loss']]().to(device)
    # 分类损失函数 (通常使用交叉熵损失)
    criterion_cls = nn.CrossEntropyLoss().to(device)

    cudnn.benchmark = True

    # ### --- 实例化多任务模型 --- ###
    # create model
    model = RARA_2262_TC_joint(num_classes=config['num_classes'],
                         num_img_classes=config['num_img_classes'])

    # model = RARA_2262_TC_joint(num_classes=config['num_classes'],
    #                            num_img_classes=config['num_img_classes'],
    #                            input_channels=config['input_channels'],
    #                            sharing_strategy='none') #block1,block12,block123,full

    # model = RARA_2262_TC_202512newclass.__dict__[config['arch']]()

    #device = torch.device("cuda")
    model = model.to(device)

    #多块GPU
    # device_ids = [0, 1]  # id为0和1的两块显卡
    # model = torch.nn.DataParallel(model, device_ids=device_ids)

    #model = model.cuda()
    # weights_dict = torch.load('model-s.pth', map_location=device)  # ./models/dsb2018_96_resnet2262T_RA_woDS/model.pth
    # model.load_state_dict(weights_dict, strict=False)

    #获取可训练参数
    params = filter(lambda p: p.requires_grad, model.parameters())
    '''
    filter() 函数用于过滤序列，过滤掉不符合条件的元素，返回由符合条件元素组成的新列表。
    该接收两个参数，第一个为函数，第二个为序列，序列的每个元素作为参数传递给函数进行判断，然后返回 True 或 False，最后将返回 True 的元素放到新列表中。
    lambda 变量 : 表达式     执行表达式并返回结果：
    .requires_grad返回true or false ， 表示参数是否可以训练，   将model.parameters()传入判断，留下可以训练的参数
    model.parameters()保存的是Weights和Bais参数的值，这个函数可以查找网格参数。
    '''

    #设置优化器
    '''
    资料：https://blog.csdn.net/kgzhang/article/details/77479737
    https://blog.csdn.net/djfjkj52/article/details/114443712
    https://blog.csdn.net/qq_34690929/article/details/79932416
    params (iterable) – 待优化参数的iterable或者是定义了参数组的dict
    lr：同样也称为学习率或步长因子，它控制了权重的更新比率（如 0.001）。较大的值（如 0.3）在学习率更新前会有更快的初始学习，而较小的值（如 1.0E-5）会令训练收敛到更好的性能。
    weight_decay (float, 可选) – 权重衰减（L2惩罚）（默认: 0）
    SGD中的Momentum 传统的参数 W 的更新是把原始的 W 累加上一个负的学习率(learning rate) 乘以校正值 (dx). 此方法比较曲折
    '''
    if config['optimizer'] == 'Adam':
        optimizer = optim.Adam(
            params, lr=config['lr'], weight_decay=config['weight_decay'])
    elif config['optimizer'] == 'SGD':
        optimizer = optim.SGD(params, lr=config['lr'], momentum=config['momentum'],
                              nesterov=config['nesterov'], weight_decay=config['weight_decay'])
    else:
        raise NotImplementedError
    # 对优化器做调整/设置学习率调度器
    if config['scheduler'] == 'CosineAnnealingLR':
        scheduler = lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=config['epochs'], eta_min=config['min_lr'])
    elif config['scheduler'] == 'ReduceLROnPlateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, factor=config['factor'], patience=config['patience'],
                                                   verbose=1, min_lr=config['min_lr'])
    elif config['scheduler'] == 'MultiStepLR':
        scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[int(e) for e in config['milestones'].split(',')], gamma=config['gamma'])
    elif config['scheduler'] == 'ConstantLR':
        scheduler = None
    else:
        raise NotImplementedError


    # Data loading code
    # img_ids = glob(os.path.join('inputs', config['dataset'], 'images', '*' + config['img_ext'])) #返回所有图片路径
    # img_ids = [os.path.splitext(os.path.basename(p))[0] for p in img_ids]  #分离文件名和拓展名
    #
    # train_img_ids, val_img_ids = train_test_split(img_ids, test_size=0.2, random_state=0) #随机划分训练集和测试集
     #random_state：是随机数的种子。
     #随机数种子：其实就是该组随机数的编号，在需要重复试验的时候，保证得到一组一样的随机数。比如你每次都填1，其他参数一样的情况下你得到的随机数组是一样的。但填0或不填，每次都会不一样。

    #数据集路径
    train_img_dir = os.path.join('inputs', config['dataset'], 'train', 'images')
    train_mask_dir = os.path.join('inputs', config['dataset'], 'train', 'masks')
    val_img_dir = os.path.join('inputs', config['dataset'], 'val', 'images')
    val_mask_dir = os.path.join('inputs', config['dataset'], 'val', 'masks')

    # 数据增强
    ### compose(   ...   )可以组合很多种不同的变换
    train_transform = Compose([
        albu.RandomRotate90(), #随机旋转
        albu.HorizontalFlip(p=0.25),  # 25% 概率水平翻转
        albu.VerticalFlip(p=0.25),  # 25% 概率垂直翻转
        OneOf([
            albu.HueSaturationValue(),  #HSV色调、饱和度、明度
            albu.RandomBrightnessContrast(p=0.5)
        ], p=1),#按照归一化的概率选择执行哪一个
        albu.Resize(config['input_h'], config['input_w']),   #调整大小
        albu.Normalize(),    #归一化
    ])

    val_transform = Compose([
        albu.Resize(config['input_h'], config['input_w']),
        albu.Normalize(),
    ])
    #### https://albumentations.ai/docs/examples/example_kaggle_salt/
    # endregion

    #定义数据集的类
    # pytorch中的Dataloader使用逻辑和model一样  先定义一个类（class）（在dataset里面），然后在主函数中先调用这个类（xx=dataset（）），然后在使用这个xx（yy=dataset（xx，...））
    # 与model略有不同的是，Daraloader使用的时候，类名称在括号里面
    #下面类的定义在Dataset.py里面 'inputs/dsb2018_96/masks'
    # 使用新的 MultiTaskDataset 类

    #创建数据集
    train_dataset = MultiTaskDataset(
        img_dir=train_img_dir,
        mask_dir=train_mask_dir,
        transform=train_transform
    )
    val_dataset = MultiTaskDataset(
        img_dir=val_img_dir,
        mask_dir=val_mask_dir,
        transform=val_transform
    )

    # 在创建 train_loader 之前添加：
    print(f"训练集大小: {len(train_dataset)}")
    print(f"验证集大小: {len(val_dataset)}")

    if len(train_dataset) == 0:
        print("错误: 训练集为空!")
        print(f"请检查目录: {train_img_dir}")
        print("确保该目录下有类别文件夹，且类别文件夹中有图片文件")
        exit(1)

    if len(val_dataset) == 0:
        print("错误: 验证集为空!")
        print(f"请检查目录: {val_img_dir}")
        exit(1)

    #创建数据加载器
    # 取batch_size个数据，要不要随机洗牌，最后多出来的要不要扔掉
    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config['num_workers'],
        drop_last=True)#不能整除的batch是否就不要了
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=True)


    #更新日志记录/打印的东西
    log = OrderedDict([
        ('epoch', []),
        ('lr', []),
        ('loss', []),
        ('iou', []),
        ('recall', []),
        ('accuracy', []),
        ('f1', []),
        ('cls_acc', []),  # 添加训练分类准确率
        ('loss_seg', []),  # 添加训练分割损失
        ('loss_cls', []),  # 添加训练分类损失
        ('val_loss', []),
        ('val_iou', []),
        ('val_recall', []),
        ('val_accuracy', []),
        ('val_f1', []),
        ('val_cls_acc', []),  # 添加验证分类准确率
        ('val_loss_seg', []),  # 添加验证分割损失
        ('val_loss_cls', []),  # 添加验证分类损失
    ])

    best_iou = 0
    trigger = 0
    for epoch in range(config['epochs']):
        print('Epoch [%d/%d]' % (epoch, config['epochs'])) #打印进度条
        print('-' * 50)

        # 训练一个epoch/  train for one epoch训练模型 并计算训练集上的误差
        train_log = train(config, train_loader, model, criterion_seg, criterion_cls, optimizer,device)
        # evaluate on validation set测试集验证 计算验证集上的误差
        val_log = validate(config, val_loader, model, criterion_seg, criterion_cls,device)
        ###更新学习率/使用优化器
        if config['scheduler'] == 'CosineAnnealingLR':
            scheduler.step()
        elif config['scheduler'] == 'ReduceLROnPlateau':
            scheduler.step(val_log['loss'])

        # 打印详细的epoch结果
        print(f"训练结果: loss={train_log['loss']:.4f}, iou={train_log['iou']:.4f}, cls_acc={train_log['cls_acc']:.4f}")
        print(f"验证结果: loss={val_log['loss']:.4f}, iou={val_log['iou']:.4f}, cls_acc={val_log['cls_acc']:.4f}")
        print('-' * 50)

        #更新日志
        log['epoch'].append(epoch)
        log['lr'].append(config['lr'])

        #训练指标
        log['loss'].append(train_log['loss'])
        log['iou'].append(train_log['iou'])
        log['recall'].append(train_log['recall'])
        log['accuracy'].append(train_log['accuracy'])
        log['f1'].append(train_log['f1'])
        log['cls_acc'].append(train_log['cls_acc'])
        log['loss_seg'].append(train_log['loss_seg'])
        log['loss_cls'].append(train_log['loss_cls'])

        #验证指标
        log['val_loss'].append(val_log['loss'])
        log['val_iou'].append(val_log['iou'])
        log['val_recall'].append(val_log['recall'])
        log['val_accuracy'].append(val_log['accuracy'])
        log['val_f1'].append(val_log['f1'])
        log['val_cls_acc'].append(val_log['cls_acc'])
        log['val_loss_seg'].append(val_log['loss_seg'])
        log['val_loss_cls'].append(val_log['loss_cls'])

        #保存日志
        pd.DataFrame(log).to_csv('modelsresutsave/%s/log.csv' %
                                 config['name'], index=False)  #记录每一次的模型效果

        trigger += 1

        #保存最佳模型（基于IoU)
        if val_log['iou'] > best_iou:
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'best_iou': val_log['iou'],
                'best_cls_acc': val_log['cls_acc'],
            }, 'modelsresutsave/%s/model.pth' % config['name'])

            best_iou = val_log['iou']
            print(f"=> 保存最佳模型 (IoU: {best_iou:.4f}, 分类准确率: {val_log['cls_acc']:.4f})")
            trigger = 0

        # 早停
        if config['early_stopping'] >= 0 and trigger >= config['early_stopping']:
            print("=> early stopping")
            break
    print('bestiou', best_iou)
    print('bestcls_acc', val_log['cls_acc'])

       # torch.cuda().mpty_cache()#清空显存缓冲区


if __name__ == '__main__':
    main()


    '''
    pytorch的使用：
    数据加载：Dataloader
    神经网络工具包：nn.module
    '''
