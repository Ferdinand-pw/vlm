import os
import cv2
import numpy as np
import torch
from torch.utils.data import Dataset


class MultiTaskDataset(Dataset):
    def __init__(self, img_dir, mask_dir, transform=None):
        super().__init__()
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.transform = transform
        self.samples = []

        print(f"初始化数据集:")
        print(f"  图像目录: {img_dir}")
        print(f"  掩码目录: {mask_dir}")

        # 检查目录是否存在
        if not os.path.exists(img_dir):
            raise FileNotFoundError(f"图像目录不存在: {img_dir}")
        if not os.path.exists(mask_dir):
            raise FileNotFoundError(f"掩码目录不存在: {mask_dir}")

        # 1. 扫描类别文件夹
        self.class_names = sorted([d for d in os.listdir(img_dir)
                                   if os.path.isdir(os.path.join(img_dir, d))])

        if not self.class_names:
            raise ValueError(f"在 {img_dir} 中没有找到类别文件夹")

        self.class_to_idx = {name: i for i, name in enumerate(self.class_names)}
        print(f"  发现 {len(self.class_names)} 个类别: {self.class_names}")

        # 2. 遍历所有类别，构建样本列表
        total_samples = 0
        for class_name in self.class_names:
            class_idx = self.class_to_idx[class_name]
            class_img_dir = os.path.join(self.img_dir, class_name)
            class_mask_dir = os.path.join(self.mask_dir, class_name)

            # 确保掩码目录存在
            if not os.path.exists(class_mask_dir):
                print(f"  警告: 类别 {class_name} 的掩码目录不存在，跳过")
                continue

            # 获取图片文件
            img_files = []
            for f in os.listdir(class_img_dir):
                if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
                    img_files.append(f)

            print(f"  类别 {class_name}: 找到 {len(img_files)} 张图片")

            # 为每张图片查找对应的掩码
            valid_pairs = 0
            for img_filename in img_files:
                img_path = os.path.join(class_img_dir, img_filename)

                # 关键修改：处理不同的文件扩展名
                base_name = os.path.splitext(img_filename)[0]

                # 尝试不同的掩码扩展名
                mask_found = False
                for mask_ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tiff']:
                    mask_filename = base_name + mask_ext
                    mask_path = os.path.join(class_mask_dir, mask_filename)

                    if os.path.exists(mask_path):
                        self.samples.append((img_path, mask_path, class_idx))
                        valid_pairs += 1
                        mask_found = True
                        break

                if not mask_found:
                    print(f"    警告: 找不到 {img_filename} 对应的掩码文件")

            total_samples += valid_pairs
            print(f"    有效图像-掩码对: {valid_pairs}")

        print(f"  总共加载 {len(self.samples)} 个有效样本")

        if len(self.samples) == 0:
            raise ValueError("没有找到任何有效的图像-掩码对")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, mask_path, class_label = self.samples[idx]

        # 1. 读取图像
        img = cv2.imread(img_path)
        if img is None:
            raise ValueError(f"无法读取图像: {img_path}")
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        # 2. 读取掩码
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        if mask is None:
            # 创建全零掩码
            h, w = img.shape[:2]
            mask = np.zeros((h, w), dtype=np.uint8)
            print(f"警告: 无法读取掩码 {mask_path}，使用全零掩码")

        # 3. 应用数据增强
        if self.transform is not None:
            augmented = self.transform(image=img, mask=mask)
            img = augmented['image']
            mask = augmented['mask']

        # 4. 转换为张量
        # 图像: (H, W, C) -> (C, H, W)，归一化到 [0, 1]
        img_tensor = torch.from_numpy(img.transpose(2, 0, 1)).float()
        # img_tensor = img_tensor / 255.0 if img_tensor.max() > 1 else img_tensor

        # 掩码: (H, W) -> (1, H, W)，归一化到 [0, 1]
        mask_tensor = torch.from_numpy(mask).float()
        mask_tensor = mask_tensor / 255.0 if mask_tensor.max() > 1 else mask_tensor
        mask_tensor = mask_tensor.unsqueeze(0)  # 添加通道维度

        # 类别标签
        label_tensor = torch.tensor(class_label, dtype=torch.long)

        return img_tensor, mask_tensor, label_tensor