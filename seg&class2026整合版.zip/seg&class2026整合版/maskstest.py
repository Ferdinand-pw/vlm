import os

import cv2
import numpy as np
import torch
import torch.utils.data

'''
img = cv2.imread('inputs/dsb2018_96/masks/0/000002_RT_01_SemAdcDef1_Patt_Side_Left_RID_000002.png', cv2.IMREAD_GRAYSCALE)
print(img.max())
cv2.imshow('img',img)
cv2.waitKey(0)
'''

img = cv2.imread('inputs/dsb2018_96/images/000001_RT_01_SemAdcDef1_Patt_Side_Left_RID_000001.tif')
print(img.max())
cv2.imshow('img',img)
cv2.waitKey(0)


'''
path = 'inputs/dsb2018_96/masks/0'  # 图像所在路径
filelist = os.listdir('inputs/dsb2018_96/masks/0')
print(len(filelist))
for file in filelist:
    orgin_dir = os.path.join(path, file) # 原路径
    print(orgin_dir)  # 检查路径
    #img = cv2.imread(orgin_dir, cv2.IMREAD_GRAYSCALE)  # 读取灰度图
    img = cv2.imread(orgin_dir)
    print(img.shape)  # 打印维度

    cv2.imwrite(orgin_dir, img)  # 覆盖原图
'''
