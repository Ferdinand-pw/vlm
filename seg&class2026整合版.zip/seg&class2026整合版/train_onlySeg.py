import argparse
import os
from collections import OrderedDict
from glob import glob
import cv2
import pandas as pd
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
import yaml
from albumentations import transforms
import albumentations as albu
from albumentations.core.composition import Compose, OneOf
from sklearn.model_selection import train_test_split
from torch.optim import lr_scheduler
from tqdm import tqdm

from models.RARA_2262_202512onlyseg import RARA_2262_onlyseg

from archs import UNettest_pre


import losses
from dataset import MultiTaskDataset

from metrics import iou_score
from utils import AverageMeter, str2bool, calculate_cls_accuracy

ARCH_NAMES = ['RARA_2262_TC_clas']
LOSS_NAMES = losses.__all__
LOSS_NAMES.append('BCEWithLogitsLoss')

'''

数据集放在inputs里，先运行prepare_dataset.py划分数据集，然后再train

'''

def parse_args():
    parser = argparse.ArgumentParser() #创建 ArgumentParser() 对象    命令行解析模块argsparse，此包(package)可以使我们直接在命令行中就可以向程序中传入参数并让程序运行一次

    #基础配置
    parser.add_argument('--name', default=None,
                        help='model name: (default: arch+timestamp)') #网络名字
    parser.add_argument('--epochs', default=300, type=int, metavar='N',
                        help='number of total epochs to run')#迭代多少轮
    parser.add_argument('-b', '--batch_size', default=4, type=int,
                        metavar='N', help='mini-batch size (default: 16)')

    # 模型配置
    parser.add_argument('--arch', '-a', metavar='ARCH', default='RARA_2262_onlyseg',  #RARA_2262_onlyseg这里修改使用的网络模型名称，改完后要在下面model里换成相应。
                        help='model architecture: ' +
                        ' | '.join(ARCH_NAMES) +
                        ' (default: NestedUNet)')  #网络架构
    parser.add_argument('--deep_supervision', default=False, type=str2bool)  #监督
    parser.add_argument('--input_channels', default=3, type=int,
                        help='input channels')   #输入个数
    parser.add_argument('--num_classes', default=1, type=int,
                        help='number of classes for segmentation')

    # parser.add_argument('--num_img_classes', default=5, type=int,
    #                     help='number of classes for image classification')  # 新增

    parser.add_argument('--input_w', default=224, type=int,
                        help='image width')
    parser.add_argument('--input_h', default=224, type=int,
                        help='image height') #图像大小
    
    # 损失函数配置
    parser.add_argument('--loss', default='BCEDiceLoss',
                        choices=LOSS_NAMES,
                        help='loss: ' +
                        ' | '.join(LOSS_NAMES) +
                        ' (default: BCEDiceLoss)')

    # # ### --- 新增：增加损失权重的参数 --- ###
    # parser.add_argument('--seg_loss_weight', default=1.0, type=float, help='Weight for segmentation loss')
    # parser.add_argument('--cls_loss_weight', default=0.5, type=float, help='Weight for classification loss')

    
    # 数据集配置
    parser.add_argument('--dataset', default='dsb2018_96',
                        help='dataset name')
    parser.add_argument('--img_ext', default='.jpg',       #.jpg  .tif
                        help='image file extension')
    parser.add_argument('--mask_ext', default='.png',
                        help='mask file extension')

    # 优化器配置
    parser.add_argument('--optimizer', default='SGD',
                        choices=['Adam', 'SGD'],
                        help='loss: ' +
                        ' | '.join(['Adam', 'SGD']) +
                        ' (default: Adam)')
    parser.add_argument('--lr', '--learning_rate', default=1e-3, type=float,
                        metavar='LR', help='initial learning rate')
    parser.add_argument('--momentum', default=0.9, type=float,
                        help='momentum')
    parser.add_argument('--weight_decay', default=1e-4, type=float,
                        help='weight decay')
    parser.add_argument('--nesterov', default=False, type=str2bool,
                        help='nesterov')

    # 学习率调度器配置
    parser.add_argument('--scheduler', default='CosineAnnealingLR',
                        choices=['CosineAnnealingLR', 'ReduceLROnPlateau', 'MultiStepLR', 'ConstantLR'])
    parser.add_argument('--min_lr', default=1e-5, type=float,
                        help='minimum learning rate')
    parser.add_argument('--factor', default=0.1, type=float)
    parser.add_argument('--patience', default=2, type=int)
    parser.add_argument('--milestones', default='1,2', type=str)
    parser.add_argument('--gamma', default=2/3, type=float)
    parser.add_argument('--early_stopping', default=-1, type=int,
                        metavar='N', help='early stopping (default: -1)')
    #其他配置
    parser.add_argument('--num_workers', default=0, type=int)

    config = parser.parse_args()  #使用 parse_args() 解析添加的参数

    return config


def train(config, train_loader, model, criterion_seg, optimizer,device):
    #添加分类准确率跟踪器
    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter(),
                  'recall':AverageMeter(),
                  'accuracy':AverageMeter(),
                  'f1':AverageMeter()
                  }

    model.train() #训练模型

    #### 输出训练集验证参数
    pbar = tqdm(total=len(train_loader))
    for input, seg_target, _ in train_loader:
        input = input.to(device)
        seg_target = seg_target.to(device)
        # cls_target = cls_target.to(device)

        #1.前向传播
        seg_output = model(input)

        # 2.计算损失
        loss= criterion_seg(seg_output, seg_target)
        # 评估分割
        iou = iou_score(seg_output, seg_target)

        #3.反向传播
        optimizer.zero_grad() #清零梯度
        loss.backward()  #反向传播
        optimizer.step()  #更新参数
        ## 最常见、最推荐的做法

        #更新指标
        avg_meters['loss'].update(loss.item(), input.size(0))
        avg_meters['iou'].update(iou[0], input.size(0))
        avg_meters['recall'].update(iou[1], input.size(0))
        avg_meters['accuracy'].update(iou[2], input.size(0))
        avg_meters['f1'].update(iou[3], input.size(0))

        #更新显示信息
        postfix = OrderedDict([
            ('loss', avg_meters['loss'].avg),
            ('iou', avg_meters['iou'].avg),
            ('recall', avg_meters['recall'].avg),
            ('accuracy', avg_meters['accuracy'].avg),
            ('f1', avg_meters['f1'].avg)
        ])
        pbar.set_postfix(postfix)
        pbar.update(1)
    pbar.close()

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg),
                        ('recall', avg_meters['recall'].avg),
                        ('accuracy', avg_meters['accuracy'].avg),
                        ('f1', avg_meters['f1'].avg)
                        ])


def validate(config, val_loader, model, criterion_seg,device):

    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter(),
                  'recall': AverageMeter(),
                  'accuracy': AverageMeter(),
                  'f1': AverageMeter()
                  }

    model.eval()   #在模型预测阶段，如果在预测的时候忘记使用model.eval()，会导致不一致的预测结果
    with torch.no_grad():
        pbar = tqdm(total=len(val_loader))
        a = 1
        for input, seg_target,_ in val_loader:
            input = input.to(device)
            seg_target = seg_target.to(device)

            seg_output= model(input)

            loss = criterion_seg(seg_output, seg_target)

            #计算分割指标与分类指标
            iou = iou_score(seg_output, seg_target)


            a += 1
            #更新指标
            avg_meters['loss'].update(loss.item(), input.size(0))
            avg_meters['iou'].update(iou[0], input.size(0))
            avg_meters['recall'].update(iou[1], input.size(0))
            avg_meters['accuracy'].update(iou[2], input.size(0))
            avg_meters['f1'].update(iou[3], input.size(0))

            #更新显示信息
            postfix = OrderedDict([
                ('loss', avg_meters['loss'].avg),
                ('iou', avg_meters['iou'].avg),
                ('recall', avg_meters['recall'].avg),
                ('accuracy', avg_meters['accuracy'].avg),
                ('f1', avg_meters['f1'].avg)
            ])
            pbar.set_postfix(postfix)
            pbar.update(1)
        pbar.close()

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg),
                        ('recall', avg_meters['recall'].avg),
                        ('accuracy', avg_meters['accuracy'].avg),
                        ('f1', avg_meters['f1'].avg)
                        ])


def main():
    config = vars(parse_args())
    #设置设备
    device = torch.device('cuda')  #device = torch.device('cuda：0')
    print(f"使用设备: {device}")

    # 创建模型保存目录
    ####配置网络名字
    if config['name'] is None:
        if config['deep_supervision']:
            config['name'] = '%s_%s_wDS' % (config['dataset'], config['arch'])  # %s表示该位置被替换，替换内容为’‘%后面的东西
        else:
            config['name'] = '%s_%s_woDS' % (config['dataset'], config['arch'])
    os.makedirs('modelsresutsave/%s' % config['name'], exist_ok=True)  # 创建文件夹

    print('-' * 20)  # 将字符串重复整数次，上面语句的功能就是打印出连续20个“-”
    for key in config:
        print('%s: %s' % (key, config[key]))  # 打印信息
    print('-' * 20)

    #保存配置文件
    with open('modelsresutsave/%s/config.yml' % config['name'], 'w') as f:  # 如果没有指定的路径，会自动新建文件，无需先去新建。w: 只写，会清除之前写的内容
        yaml.dump(config, f)  # 将config的内容写入f(config.yml)
    # 分割损失函数
    if config['loss'] == 'BCEWithLogitsLoss':
        criterion_seg = nn.BCEWithLogitsLoss().to(device)
    else:
        criterion_seg = losses.__dict__[config['loss']]().to(device)

    cudnn.benchmark = True

    # ### --- 实例化多任务模型 --- ###
    # create model
    model = RARA_2262_onlyseg(num_classes=config['num_classes']).to(device)
    # model = UNettest_pre(num_classes=config['num_classes']).to(device)
    # model = RARA_2262_TC_202512newclass.__dict__[config['arch']]()
    #获取可训练参数
    params = filter(lambda p: p.requires_grad, model.parameters())
    #设置优化器
    if config['optimizer'] == 'Adam':
        optimizer = optim.Adam(
            params, lr=config['lr'], weight_decay=config['weight_decay'])
    elif config['optimizer'] == 'SGD':
        optimizer = optim.SGD(params, lr=config['lr'], momentum=config['momentum'],
                              nesterov=config['nesterov'], weight_decay=config['weight_decay'])
    else:
        raise NotImplementedError
    # 对优化器做调整/设置学习率调度器
    if config['scheduler'] == 'CosineAnnealingLR':
        scheduler = lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=config['epochs'], eta_min=config['min_lr'])
    elif config['scheduler'] == 'ReduceLROnPlateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, factor=config['factor'], patience=config['patience'],
                                                   verbose=1, min_lr=config['min_lr'])
    elif config['scheduler'] == 'MultiStepLR':
        scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[int(e) for e in config['milestones'].split(',')], gamma=config['gamma'])
    elif config['scheduler'] == 'ConstantLR':
        scheduler = None
    else:
        raise NotImplementedError


    # Data loading code
    # img_ids = glob(os.path.join('inputs', config['dataset'], 'images', '*' + config['img_ext'])) #返回所有图片路径
    # img_ids = [os.path.splitext(os.path.basename(p))[0] for p in img_ids]  #分离文件名和拓展名
    #
    # train_img_ids, val_img_ids = train_test_split(img_ids, test_size=0.2, random_state=0) #随机划分训练集和测试集
     #random_state：是随机数的种子。
     #随机数种子：其实就是该组随机数的编号，在需要重复试验的时候，保证得到一组一样的随机数。比如你每次都填1，其他参数一样的情况下你得到的随机数组是一样的。但填0或不填，每次都会不一样。

    #数据集路径
    train_img_dir = os.path.join('inputs', config['dataset'], 'train', 'images')
    train_mask_dir = os.path.join('inputs', config['dataset'], 'train', 'masks')
    val_img_dir = os.path.join('inputs', config['dataset'], 'val', 'images')
    val_mask_dir = os.path.join('inputs', config['dataset'], 'val', 'masks')

    # 数据增强
    ### compose(   ...   )可以组合很多种不同的变换
    train_transform = Compose([
        albu.RandomRotate90(), #随机旋转
        albu.HorizontalFlip(p=0.25),  # 25% 概率水平翻转
        albu.VerticalFlip(p=0.25),  # 25% 概率垂直翻转
        OneOf([
            albu.HueSaturationValue(),  #HSV色调、饱和度、明度
            albu.RandomBrightnessContrast(p=0.5)
        ], p=1),#按照归一化的概率选择执行哪一个
        albu.Resize(config['input_h'], config['input_w']),   #调整大小
        albu.Normalize(),    #归一化
    ])

    val_transform = Compose([
        albu.Resize(config['input_h'], config['input_w']),
        albu.Normalize(),
    ])
    #### https://albumentations.ai/docs/examples/example_kaggle_salt/
    # endregion

    #定义数据集的类
    # pytorch中的Dataloader使用逻辑和model一样  先定义一个类（class）（在dataset里面），然后在主函数中先调用这个类（xx=dataset（）），然后在使用这个xx（yy=dataset（xx，...））
    # 与model略有不同的是，Daraloader使用的时候，类名称在括号里面
    #下面类的定义在Dataset.py里面 'inputs/dsb2018_96/masks'
    # 使用新的 MultiTaskDataset 类

    #创建数据集
    train_dataset = MultiTaskDataset(
        img_dir=train_img_dir,
        mask_dir=train_mask_dir,
        transform=train_transform
    )
    val_dataset = MultiTaskDataset(
        img_dir=val_img_dir,
        mask_dir=val_mask_dir,
        transform=val_transform
    )

    # 在创建 train_loader 之前添加：
    print(f"训练集大小: {len(train_dataset)}")
    print(f"验证集大小: {len(val_dataset)}")

    if len(train_dataset) == 0:
        print("错误: 训练集为空!")
        print(f"请检查目录: {train_img_dir}")
        print("确保该目录下有类别文件夹，且类别文件夹中有图片文件")
        exit(1)

    if len(val_dataset) == 0:
        print("错误: 验证集为空!")
        print(f"请检查目录: {val_img_dir}")
        exit(1)

    #创建数据加载器
    # 取batch_size个数据，要不要随机洗牌，最后多出来的要不要扔掉
    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config['num_workers'],
        drop_last=True)#不能整除的batch是否就不要了
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=True)


    #更新日志记录/打印的东西
    log = OrderedDict([
        ('epoch', []),
        ('lr', []),
        ('loss', []),
        ('iou', []),
        ('recall', []),
        ('accuracy', []),
        ('f1', []),
        ('val_loss', []),
        ('val_iou', []),
        ('val_recall', []),
        ('val_accuracy', []),
        ('val_f1', []),
    ])

    best_iou = 0
    trigger = 0
    for epoch in range(config['epochs']):
        print('Epoch [%d/%d]' % (epoch, config['epochs'])) #打印进度条
        print('-' * 50)

        # 训练一个epoch/  train for one epoch训练模型 并计算训练集上的误差
        train_log = train(config, train_loader, model, criterion_seg, optimizer,device)
        # evaluate on validation set测试集验证 计算验证集上的误差
        val_log = validate(config, val_loader, model, criterion_seg,device)
        ###更新学习率/使用优化器
        if config['scheduler'] == 'CosineAnnealingLR':
            scheduler.step()
        elif config['scheduler'] == 'ReduceLROnPlateau':
            scheduler.step(val_log['loss'])

        # 打印详细的epoch结果
        print(f"训练结果: loss={train_log['loss']:.4f}, iou={train_log['iou']:.4f}")
        print(f"验证结果: loss={val_log['loss']:.4f}, iou={val_log['iou']:.4f}")
        print('-' * 50)

        #更新日志
        log['epoch'].append(epoch)
        log['lr'].append(config['lr'])

        #训练指标
        log['loss'].append(train_log['loss'])
        log['iou'].append(train_log['iou'])
        log['recall'].append(train_log['recall'])
        log['accuracy'].append(train_log['accuracy'])
        log['f1'].append(train_log['f1'])

        #验证指标
        log['val_loss'].append(val_log['loss'])
        log['val_iou'].append(val_log['iou'])
        log['val_recall'].append(val_log['recall'])
        log['val_accuracy'].append(val_log['accuracy'])
        log['val_f1'].append(val_log['f1'])

        #保存日志
        pd.DataFrame(log).to_csv('modelsresutsave/%s/log.csv' %
                                 config['name'], index=False)  #记录每一次的模型效果

        trigger += 1

        #保存最佳模型（基于IoU)
        if val_log['iou'] > best_iou:
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'best_iou': val_log['iou'],
                # 'best_cls_acc': val_log['cls_acc'],
            }, 'modelsresutsave/%s/model.pth' % config['name'])

            best_iou = val_log['iou']
            print(f"=> 保存最佳模型 (IoU: {best_iou:.4f})")
            trigger = 0

        # 早停
        if config['early_stopping'] >= 0 and trigger >= config['early_stopping']:
            print("=> early stopping")
            break
    print('bestiou', best_iou)
    # print('bestcls_acc', val_log['cls_acc'])

       # torch.cuda().mpty_cache()#清空显存缓冲区


if __name__ == '__main__':
    main()


    '''
    pytorch的使用：
    数据加载：Dataloader
    神经网络工具包：nn.module
    '''
