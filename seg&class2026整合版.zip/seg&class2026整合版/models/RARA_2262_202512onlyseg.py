import torch.nn as nn
import torch
import torch.nn.functional as F
from typing import Optional
import math
import numpy as np

class PatchMerging(nn.Module):
    r""" Patch Merging Layer.

    Args:
        dim (int): Number of input channels.
        norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
    """

    def __init__(self, dim = 256, norm_layer=nn.LayerNorm):
        super().__init__()
        self.dim = dim
        self.reduction = nn.Linear(1024, 512, bias=False) #创建一个全连接层.Linear定义一个神经网络的线性层，三个参数表示输入神经元个数，输出神经元个数，偏置。
        self.norm = norm_layer(1024) #只需要一个参数的话，默认对最后一维处理。相关知识：https://blog.csdn.net/weixin_41978699/article/details/122778085

    def forward(self, x):
        """
        x: B, H*W, C
        """
        B, C ,H, W= x.shape
        # assert L == H * W, "input feature has wrong size" #判断一下高宽，不相等的话报错

        x = x.contiguous().view(B, H, W, C) #将输入张量x的形状从[B, C, H, W]转换为[B, H, W, C]。这个操作通常用于将卷积层的输出转换为全连接层的输入。

        # padding
        # 如果输入feature map的H，W不是2的整数倍，需要进行padding
        pad_input = (H % 2 == 1) or (W % 2 == 1)
        if pad_input:
            # to pad the last 3 dimensions, starting from the last dimension and moving forward.
            # (C_front, C_back, W_left, W_right, H_top, H_bottom)
            # 注意这里的Tensor通道是[B, H, W, C]，所以会和官方文档有些不同
            x = F.pad(x, (0, 0, 0, W % 2, 0, H % 2)) # 倒着填充。前两个是C，然后是W和H（W在最右侧一列填充，H在最下方一行填充）
        # 接下来就能保证它是2的整数倍
        x0 = x[:, 0::2, 0::2, :]  # [B, H/2, W/2, C] #表示从高度0 宽度0开始采样
        x1 = x[:, 1::2, 0::2, :]  # [B, H/2, W/2, C] #表示从高度1 宽度0开始采样
        x2 = x[:, 0::2, 1::2, :]  # [B, H/2, W/2, C]
        x3 = x[:, 1::2, 1::2, :]  # [B, H/2, W/2, C]
        x = torch.cat([x0, x1, x2, x3], -1)  # [B, H/2, W/2, 4*C]
        x = x.view(B, -1, 4 * C)  # [B, H/2*W/2, 4*C]

        x = self.norm(x)
        x = self.reduction(x)  # [B, H/2*W/2, 2*C]

        return x

def drop_path_f(x, drop_prob: float = 0., training: bool = False):
    """Drop paths (Stochastic Depth) per sample (when applied in main path of residual blocks).

    This is the same as the DropConnect impl I created for EfficientNet, etc networks, however,
    the original name is misleading as 'Drop Connect' is a different form of dropout in a separate paper...
    See discussion: https://github.com/tensorflow/tpu/issues/494#issuecomment-532968956 ... I've opted for
    changing the layer and argument names to 'drop path' rather than mix DropConnect as a layer name and use
    'survival rate' as the argument.

    """
    if drop_prob == 0. or not training:
        return x
    keep_prob = 1 - drop_prob
    shape = (x.shape[0],) + (1,) * (x.ndim - 1)  # work with diff dim tensors, not just 2D ConvNets
    random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
    random_tensor.floor_()  # binarize
    output = x.div(keep_prob) * random_tensor
    return output

def window_partition(x, window_size: int):
    """
    将feature map按照window_size划分成一个个没有重叠的window
    Args:
        x: (B, H, W, C)
        window_size (int): window size(M)

    Returns:
        windows: (num_windows*B, window_size, window_size, C)
    """
    # 这段代码实现了将输入张量x分成多个大小为window_size x window_size的窗口，
    # 并将每个窗口展平成一个大小为window_size x window_size x C 的向量。
    # 具体地，代码首先获取x的形状，即B、H、W、C的值，
    # 然后使PyTorch的view函数将x重塑为大小为
    # Bx(H // window_size)xwindow_sizex(W // window_size)x window_size x C 的张量。
    # 该操作将输入张量分成了(H // window_size) x(W // window_size) 个小窗口，每个窗口大小为
    # window_size x window_size x C。
    # 接下来，使用permute函数对张量维度进行重排，将其从[B, H // Mh, Mh, W // Mw, Mw, C]
    # 转换为[B, H // Mh, W // Mw, Mw, Mh, C]，这里Mh和Mw都等于window_size。
    # 最后，使用view函数将张量展平为大小为 B x(H // window_size) x(W // window_size) x window_size x window_size x C 的张量，
    # 即每个窗口被展平为一个大小为window_size x window_sizexC的向量。

    B, H, W, C = x.shape
    x = x.view(B, H // window_size, window_size, W // window_size, window_size, C)
    # permute: [B, H//Mh, Mh, W//Mw, Mw, C] -> [B, H//Mh, W//Mh, Mw, Mw, C]
    # view: [B, H//Mh, W//Mw, Mh, Mw, C] -> [B*num_windows, Mh, Mw, C]
    windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size, window_size, C) #将一个 4 维张量变为一个由多个 `window_size x window_size x C` 的小张量组成的大张量
    return windows                                                                           #通常用于卷积神经网络中的滑动窗口操作，即将原张量中的每个小窗口作为一个输入，进行卷积操作

    #`.contiguous()` 函数会返回一个连续的内存空间中的张量，
    # 因为 PyTorch 中的张量在内存中的存储方式并不一定是连续的。
    # 这个函数的作用是将张量的数据存储方式变为连续的，以便进行后续的操作
    #`.view()` 函数会将张量重新组织为指定形状的张量。每个参数表示一个维度的大小， -1 表示该维度的大小应该由代码自动推断。
    # 在这段代码中，`.view(-1, window_size, window_size, C)` 表示将张量重新组织为四维张量，其中第一维的大小由代码自动推断，后三维的大小分别为 `window_size`、`window_size` 和 `C`。

def window_reverse(windows, window_size: int, H: int, W: int):
    """
    将一个个window还原成一个feature map
    Args:
        windows: (num_windows*B, window_size, window_size, C)
        window_size (int): Window size(M)
        H (int): Height of image
        W (int): Width of image

    Returns:
        x: (B, H, W, C)
    """
    B = int(windows.shape[0] / (H * W / window_size / window_size)) # windows.shape[0]就是num_windows*B
    # view: [B*num_windows, Mh, Mw, C] -> [B, H//Mh, W//Mw, Mh, Mw, C]
    x = windows.view(B, H // window_size, W // window_size, window_size, window_size, -1)
    # permute: [B, H//Mh, W//Mw, Mh, Mw, C] -> [B, H//Mh, Mh, W//Mw, Mw, C]
    # view: [B, H//Mh, Mh, W//Mw, Mw, C] -> [B, H, W, C]
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    return x

class WindowAttention(nn.Module):
    r""" Window based multi-head self attention (W-MSA) module with relative position bias.
    It supports both of shifted and non-shifted window.

    Args:
        dim (int): Number of input channels.
        window_size (tuple[int]): The height and width of the window.
        num_heads (int): Number of attention heads.
        qkv_bias (bool, optional):  If True, add a learnable bias to query, key, value. Default: True
        attn_drop (float, optional): Dropout ratio of attention weight. Default: 0.0
        proj_drop (float, optional): Dropout ratio of output. Default: 0.0
    """

    def __init__(self, dim, window_size, num_heads, qkv_bias=True, attn_drop=0., proj_drop=0.):

        super().__init__()
        self.dim = dim
        self.window_size = window_size  # [Mh, Mw]
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5

        # define a parameter table of relative position bias
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * window_size[0] - 1) * (2 * window_size[1] - 1), num_heads))  # [2*Mh-1 * 2*Mw-1, nH]

        # get pair-wise relative position index for each token inside the window
        coords_h = torch.arange(self.window_size[0])
        coords_w = torch.arange(self.window_size[1])
        coords = torch.stack(torch.meshgrid([coords_h, coords_w]))  # [2, Mh, Mw]
        # coords = torch.stack(torch.meshgrid([coords_h, coords_w], indexing="ij"))  # [2, Mh, Mw]
        coords_flatten = torch.flatten(coords, 1)  # [2, Mh*Mw]
        # [2, Mh*Mw, 1] - [2, 1, Mh*Mw]
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]  # [2, Mh*Mw, Mh*Mw]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # [Mh*Mw, Mh*Mw, 2]
        relative_coords[:, :, 0] += self.window_size[0] - 1  # shift to start from 0
        relative_coords[:, :, 1] += self.window_size[1] - 1
        relative_coords[:, :, 0] *= 2 * self.window_size[1] - 1
        relative_position_index = relative_coords.sum(-1)  # [Mh*Mw, Mh*Mw]
        self.register_buffer("relative_position_index", relative_position_index)

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        nn.init.trunc_normal_(self.relative_position_bias_table, std=.02)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x, mask: Optional[torch.Tensor] = None):
        """
        Args:
            x: input features with shape of (num_windows*B, Mh*Mw, C)
            mask: (0/-inf) mask with shape of (num_windows, Wh*Ww, Wh*Ww) or None
        """
        # [batch_size*num_windows, Mh*Mw, total_embed_dim]
        B_, N, C = x.shape
        ##print(x.shape)
        # qkv(): -> [batch_size*num_windows, Mh*Mw, 3 * total_embed_dim]
        # reshape: -> [batch_size*num_windows, Mh*Mw, 3, num_heads, embed_dim_per_head]
        # permute: -> [3, batch_size*num_windows, num_heads, Mh*Mw, embed_dim_per_head]
        qkv = self.qkv(x).reshape(B_, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        # [batch_size*num_windows, num_heads, Mh*Mw, embed_dim_per_head]
        q, k, v = qkv.unbind(0)  # make torchscript happy (cannot use tensor as tuple)

        # transpose: -> [batch_size*num_windows, num_heads, embed_dim_per_head, Mh*Mw]
        # @: multiply -> [batch_size*num_windows, num_heads, Mh*Mw, Mh*Mw]
        q = q * self.scale
        attn = (q @ k.transpose(-2, -1))

        # relative_position_bias_table.view: [Mh*Mw*Mh*Mw,nH] -> [Mh*Mw,Mh*Mw,nH]
        relative_position_bias = self.relative_position_bias_table[self.relative_position_index.view(-1)].view(
            self.window_size[0] * self.window_size[1], self.window_size[0] * self.window_size[1], -1)
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()  # [nH, Mh*Mw, Mh*Mw]
        attn = attn + relative_position_bias.unsqueeze(0)

        if mask is not None:
            # mask: [nW, Mh*Mw, Mh*Mw]
            nW = mask.shape[0]  # num_windows
            # attn.view: [batch_size, num_windows, num_heads, Mh*Mw, Mh*Mw]
            # mask.unsqueeze: [1, nW, 1, Mh*Mw, Mh*Mw]
            attn = attn.view(B_ // nW, nW, self.num_heads, N, N) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, N, N)
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)

        attn = self.attn_drop(attn)

        # @: multiply -> [batch_size*num_windows, num_heads, Mh*Mw, embed_dim_per_head]
        # transpose: -> [batch_size*num_windows, Mh*Mw, num_heads, embed_dim_per_head]
        # reshape: -> [batch_size*num_windows, Mh*Mw, total_embed_dim]
        x = (attn @ v).transpose(1, 2).reshape(B_, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x

class DropPath(nn.Module):
    """Drop paths (Stochastic Depth) per sample  (when applied in main path of residual blocks).
    """
    def __init__(self, drop_prob=None):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        return drop_path_f(x, self.drop_prob, self.training)

class Mlp(nn.Module):
    """ MLP as used in Vision Transformer, MLP-Mixer and related networks
    """
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features

        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer() # 激活函数用GELU
        self.drop1 = nn.Dropout(drop)
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop2 = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop1(x)
        x = self.fc2(x)
        x = self.drop2(x)
        return x

class SwinTransformerBlock(nn.Module):
    def __init__(self, dim, num_heads, window_size=7, shift_size=0,
                 mlp_ratio=4., qkv_bias=True, drop=0., attn_drop=0., drop_path=0.,
                 act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        self.dim = dim
        self.num_heads = 24
        self.window_size = window_size
        self.shift_size = shift_size
        self.mlp_ratio = mlp_ratio
        assert 0 <= self.shift_size < self.window_size, "shift_size must in 0-window_size"
                                                        #shift_size=0 表示用W-MSA
        self.norm1 = norm_layer(dim)
        self.attn = WindowAttention(
            dim, window_size=(self.window_size, self.window_size), num_heads=num_heads, qkv_bias=qkv_bias,
            attn_drop=attn_drop, proj_drop=drop)

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

    def create_mask(self, x, H, W):
        # calculate attention mask for SW-MSA
        # 保证Hp和Wp是window_size的整数倍
        Hp = int(np.ceil(H / self.window_size)) * self.window_size  # ceil函数，对H除以self.window_size进行上取整操作
        Wp = int(np.ceil(W / self.window_size)) * self.window_size

        # 拥有和feature map一样的通道排列顺序，方便后续window_partition
        img_mask = torch.zeros((1, Hp, Wp, 1), device=x.device)  # 专门设置成[1, Hp, Wp, 1]
        # 知识：python数组索引方式。 #  下面这段代码定义了一个三元组h_slices，包含三个切片对象。每个切片对象用于切分一个维度的数据
        h_slices = (slice(0, -self.window_size),
                    slice(-self.window_size, -self.shift_size),
                    slice(-self.shift_size, None))
        w_slices = (slice(0, -self.window_size),
                    slice(-self.window_size, -self.shift_size),
                    slice(-self.shift_size, None))
        cnt = 0
        for h in h_slices:  # 开始遍历每个切片的区域
            for w in w_slices:
                img_mask[:, h, w, :] = cnt
                cnt += 1

        mask_windows = window_partition(img_mask, self.window_size)  # [nW, Mh, Mw, 1]
        mask_windows = mask_windows.view(-1, self.window_size * self.window_size)  # [nW, Mh*Mw]
        attn_mask = mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2)  # [nW, 1, Mh*Mw] - [nW, Mh*Mw, 1]
        # [nW, Mh*Mw, Mh*Mw] #制作attention mask，数字相同的表示在同一个区域，按照上面一行代码，相同数字相减=0；下一行代码把不为0的填-100.
        attn_mask = attn_mask.masked_fill(attn_mask != 0, float(-100.0)).masked_fill(attn_mask == 0, float(0.0))
        return attn_mask

    def forward(self, x):
        ##print(x.shape)
        B, L, C = x.shape
        H = int(math.sqrt(L))
        W = int(math.sqrt(L))
        ##print(H)
        attn_mask = self.create_mask(x, H, W)
        B, L, C = x.shape
        assert L == H * W, "input feature has wrong size"

        shortcut = x
        x = self.norm1(x)
        x = x.view(B, H, W, C)

        # pad feature maps to multiples of window size
        # 把feature map给pad到window size的整数倍
        pad_l = pad_t = 0    # 之前设置padding只会在宽度方向的右侧和高度方向的下侧去padding。所以这里对左侧和上侧设为0，表示不padding
        pad_r = (self.window_size - W % self.window_size) % self.window_size # 如果W是window_size的整数倍，则括号里值为window_size。再加上最后的取余步骤，相当于不要padding
        pad_b = (self.window_size - H % self.window_size) % self.window_size
        x = F.pad(x, (0, 0, pad_l, pad_r, pad_t, pad_b))
        _, Hp, Wp, _ = x.shape

        # cyclic shift
        if self.shift_size > 0:   # >0则SW-MSA，需要将上面的一些行和左边的一些列移动
            shifted_x = torch.roll(x, shifts=(-self.shift_size, -self.shift_size), dims=(1, 2)) # 之前设置x = x.view(B, H, W, C)，则dims=(1, 2)对应H，W
                                                                                                # 负的表示反方向移动。从上往下移动，从左往右移动
        else:
            shifted_x = x
            attn_mask = None

        # partition windows
        x_windows = window_partition(shifted_x, self.window_size)  # [nW*B, Mh, Mw, C]
        x_windows = x_windows.view(-1, self.window_size * self.window_size, C)  # [nW*B, Mh*Mw, C]

        # W-MSA/SW-MSA
        attn_windows = self.attn(x_windows, mask=attn_mask)  # [nW*B, Mh*Mw, C]

        # merge windows
        attn_windows = attn_windows.view(-1, self.window_size, self.window_size, C)  # [nW*B, Mh, Mw, C]
        shifted_x = window_reverse(attn_windows, self.window_size, Hp, Wp)  # [B, H', W', C]

        # reverse cyclic shift
        if self.shift_size > 0:
            x = torch.roll(shifted_x, shifts=(self.shift_size, self.shift_size), dims=(1, 2))
        else:
            x = shifted_x

        if pad_r > 0 or pad_b > 0:
            # 把前面pad的数据移除掉
            x = x[:, :H, :W, :].contiguous()

        x = x.view(B, H * W, C)

        # FFN    # EncoderBlock的两个残差连接
        x = shortcut + self.drop_path(x)
        x = x + self.drop_path(self.mlp(self.norm2(x)))

        return x


## 基础res模块
class BasicBlock(nn.Module):
    expansion = 1  # 每一个conv的卷积核个数的倍数

    def __init__(self, in_channel, out_channel, stride=1, downsample=None):  # downsample对应虚线残差结构
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=in_channel, out_channels=out_channel,
                               kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channel)  # BN处理
        self.relu = nn.ReLU()
        self.conv2 = nn.Conv2d(in_channels=out_channel, out_channels=out_channel,
                               kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channel)
        self.downsample = downsample
        self.in_channel = in_channel
        ### 切片
        if stride != 1 or in_channel != out_channel:
            self.downsample = nn.Sequential(
                nn.Conv2d(self.in_channel, out_channel, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channel))

    def forward(self, x):
        identity = x  # 捷径上的输出值
        if self.downsample is not None:
            identity = self.downsample(x)

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        out += identity
        out = self.relu(out)

        return out

#上采样模块
class UPblock(nn.Module):
    def __init__(self, in_channels,middle_channels,out_channels, stride=1):
        super(UPblock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, middle_channels, kernel_size=1, stride=1, padding=0, bias=False)
        self.bn1 = nn.BatchNorm2d(middle_channels)
        # 下面要用反卷积 https://blog.csdn.net/zbzcDZF/article/details/87881076  outputpadding只加一层
        self.transconv2 = nn.ConvTranspose2d(middle_channels, middle_channels, kernel_size=3, stride=2, padding=1, output_padding=1)
        self.bn2 = nn.BatchNorm2d(middle_channels)

        self.conv3 = nn.Conv2d(middle_channels, out_channels, kernel_size=1, stride=1, padding=0, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU()
    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)

        x = self.transconv2(x)
        x = self.bn2(x)
        x = self.relu(x)

        x = self.conv3(x)
        x = self.bn3(x)
        x = self.relu(x)
        return x


#FRELU模块
class FReLU(nn.Module):
    """
    FReLU https://arxiv.org/abs/2007.11824
    """
    def __init__(self, c1):  # ch_in, kernel
        super().__init__()
        # 定义漏斗条件T(x)  参数池窗口（Parametric Pooling Window ）来创建空间依赖
        # nn.Con2d(in_channels, out_channels, kernel_size, stride, padding, dilation=1, bias=True)
        # 使用 深度可分离卷积 DepthWise Separable Conv + BN 实现T(x)
        self.conv = nn.Conv2d(c1, c1, kernel_size=3, stride=1, padding=1, groups=c1, bias=False)
        self.bn = nn.BatchNorm2d(c1)

    def forward(self, x):
        # f(x)=max(x, T(x))
        return torch.max(x, self.bn(self.conv(x)))

class attentiongate(nn.Module):
    def __init__(self, channel):
        super().__init__()
        self.conv1 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.frelu = FReLU(channel)
        self.conv2 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.bn = nn.BatchNorm2d(channel)
        self.sig = nn.Sigmoid()

    def forward(self, input):
        #print('input', input.shape)
        x = self.conv1(input)
        x = self.frelu(x)
        x = self.conv2(x)
        x = self.bn(x)
        x = self.sig(x)
        #print('x', x.shape)
        x1 = x * input
        xout = x1 + input
        return xout

class VGGBlock(nn.Module):
    def __init__(self, in_channels, middle_channels, out_channels):
        super().__init__() #调用父类的构造函数
        self.relu = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_channels, middle_channels, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(middle_channels)
        self.conv2 = nn.Conv2d(middle_channels, out_channels, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        #卷积 batchnorm rulu激活
        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        return out


class RARA_2262_onlyseg(nn.Module):
    def __init__(self, num_classes=1, input_channels=3, **kwargs):
        super().__init__()

        # 移除所有分类相关参数
        # 移除: num_img_classes参数

        # 完全移除分类分支的所有组件：
        # 移除以下分类相关层：
        # self.conv1, self.bn1, self.layer1, self.layer2, self.layer3
        # self.downsample, self.layer4_1, self.layer4_2
        # self.classification_head

        # 分割分支保持不变
        nb_filter = [64, 128, 256, 512]
        self.pool = nn.MaxPool2d(2, 2)
        self.bn0 = nn.BatchNorm2d(nb_filter[0])
        self.relu = nn.ReLU()

        # 用于第一次卷积
        self.conv0 = nn.Conv2d(input_channels, nb_filter[0], kernel_size=3, stride=1, padding=1, bias=False)
        self.conv1_0 = BasicBlock(nb_filter[0], nb_filter[0])
        self.conv1_1 = BasicBlock(nb_filter[0], nb_filter[0])

        self.conv2_0 = BasicBlock(nb_filter[0], nb_filter[1])
        self.conv2_1 = BasicBlock(nb_filter[1], nb_filter[1])

        self.conv3_0 = BasicBlock(nb_filter[1], nb_filter[2])
        self.conv3_1 = BasicBlock(nb_filter[2], nb_filter[2])
        self.conv3_2 = BasicBlock(nb_filter[2], nb_filter[2])
        self.conv3_3 = BasicBlock(nb_filter[2], nb_filter[2])
        self.conv3_4 = BasicBlock(nb_filter[2], nb_filter[2])
        self.conv3_5 = BasicBlock(nb_filter[2], nb_filter[2])

        self.conv4_0 = BasicBlock(nb_filter[2], nb_filter[3])
        self.conv4_1 = BasicBlock(nb_filter[3], nb_filter[3])

        # 中间模块 - 保持不变
        self.middle1 = attentiongate(nb_filter[3])
        self.middle2 = attentiongate(nb_filter[3])
        self.middle3 = attentiongate(nb_filter[3])
        self.middle4 = attentiongate(nb_filter[3])

        self.middle1_3 = attentiongate(nb_filter[2])
        self.middle2_3 = attentiongate(nb_filter[2])
        self.middle3_3 = attentiongate(nb_filter[2])

        self.middle1_2 = attentiongate(nb_filter[1])
        self.middle2_2 = attentiongate(nb_filter[1])

        self.middle1_1 = attentiongate(nb_filter[0])

        # upgate模块 - 保持不变
        self.upgate3 = VGGBlock(512, 512, 512)
        self.upgate2 = VGGBlock(384, 384, 384)
        self.upgate1 = VGGBlock(256, 256, 256)
        self.upgate0 = VGGBlock(192, 192, 192)

        ## 向上采样区 - 需要调整部分通道数
        # 修改点1: 移除 up00，因为不再需要处理分类特征
        # 原: self.up00 = UPblock(nb_filter[3], nb_filter[3] // 4, nb_filter[2])

        # 修改点2: up3的输入通道从768改为512（移除分类特征）
        # 原: self.up3 = UPblock(768, nb_filter[3] // 4, nb_filter[2])
        self.up3 = UPblock(512, nb_filter[3] // 4, nb_filter[2])  # 512 而不是 768

        # 修改点3: up2的输入通道保持不变（384），因为它接收的是分割分支内部的特征
        self.up2 = UPblock(512, nb_filter[3] // 4, nb_filter[2])  # 保持384不变    nb_filter = [64, 128, 256, 512]

        # up1和up0保持不变
        self.up1 = UPblock(384, nb_filter[1] // 4, 192)
        self.up0 = UPblock(256, nb_filter[0] // 4, 128)

        # 最终输出层
        self.final = nn.Conv2d(192, num_classes, kernel_size=1)

        # 完全移除分类头
        # 移除: self.classification_head

    # 完全移除 _make_layer 方法，因为分类分支被移除
    # 注意: 如果你的分割分支中的BasicBlock需要这个方法，请告诉我
    # 但根据你的代码，分割分支没有使用_make_layer

    def forward(self, input):
        # 完全移除分类分支的所有计算

        # 移除以下分类分支代码:
        # x = self.conv1(input)
        # x = self.bn1(x)
        # x = self.relu(x)
        # x = self.layer1(x)
        # x = self.layer2(x)
        # x = self.layer3(x)
        # x = self.downsample(x)
        # x = self.layer4_1(x)
        # cls_bottleneck_feature = self.layer4_2(x)
        # cls_feature_transposed = cls_bottleneck_feature.transpose(1, 2)
        # classification_output = self.classification_head(cls_feature_transposed)
        # x00 = x.view(-1, 7, 7, 512)
        # x00 = x00.permute(0, 3, 1, 2)

        # 分割分支 - 保持不变
        x0_0 = self.conv0(input)
        x0_0 = self.bn0(x0_0)
        x0_0 = self.relu(x0_0)

        x1_0 = self.pool(x0_0)
        x1_0 = self.conv1_0(x1_0)
        x1_0 = self.conv1_1(x1_0)

        x2_0 = self.pool(x1_0)
        x2_0 = self.conv2_0(x2_0)
        x2_0 = self.conv2_1(x2_0)

        x3_0 = self.pool(x2_0)
        x3_0 = self.conv3_0(x3_0)
        x3_0 = self.conv3_1(x3_0)
        x3_0 = self.conv3_2(x3_0)
        x3_0 = self.conv3_3(x3_0)
        x3_0 = self.conv3_4(x3_0)
        x3_0 = self.conv3_5(x3_0)

        x4_0 = self.pool(x3_0)
        x4_0 = self.conv4_0(x4_0)
        x4_0 = self.conv4_1(x4_0)

        # attentiongate模块
        x4_0 = self.middle1(x4_0)
        x4_0 = self.middle2(x4_0)
        x4_0 = self.middle3(x4_0)
        x4_0 = self.middle4(x4_0)

        # 修改点4: 移除分类特征的上采样和拼接
        # 原: x00 = self.up00(x00)
        # 原: x4_0 = torch.cat([x00, x4_0], 1)
        # 现在: 直接使用x4_0，不进行拼接

        # 分类特征已经移除，所以x4_0保持不变，不进行拼接
        # 注意: x4_0的形状现在是 [batch_size, 512, height, width]

        x3_0 = self.middle1_3(x3_0)
        x3_0 = self.middle2_3(x3_0)
        x3_0 = self.middle3_3(x3_0)

        # 修改点5: up3的输入现在是x4_0（512通道）而不是拼接后的768通道
        x3_1 = torch.cat([x3_0, self.up3(x4_0)], 1)
        x3_1 = self.upgate3(x3_1)

        x2_0 = self.middle1_2(x2_0)
        x2_0 = self.middle2_2(x2_0)

        x2_1 = torch.cat([x2_0, self.up2(x3_1)], 1)
        x2_1 = self.upgate2(x2_1)

        x1_0 = self.middle1_1(x1_0)

        x1_1 = torch.cat([x1_0, self.up1(x2_1)], 1)
        x1_1 = self.upgate1(x1_1)

        x0_1 = torch.cat([x0_0, self.up0(x1_1)], 1)
        x0_1 = self.upgate0(x0_1)

        segmentation_output = self.final(x0_1)

        # 修改点6: 只返回分割输出，不返回分类输出
        return segmentation_output


