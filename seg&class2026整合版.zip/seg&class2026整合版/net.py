import torch
from torchvision import transforms
import archs
import archs_AUNet_attentiongate
import archs_RESUNET


model = archs.__dict__['UNettest_pre'](1,3)
print(model)

# unet
# model = archs.__dict__[config['arch']](config['num_classes'],
#                                       config['input_channels'])    #定义 选择msodel

# AUNet
# model = archs_AUNet.__dict__[config['arch']]()  # 定义 选择model

# AUNet_SE
# model = archs_AUNet_se.__dict__[config['arch']]()  # 定义 选择model

# AUNET Attentiongate
#model = archs_AUNet_attentiongate.__dict__[config['arch']]()

# dlinknet
# model = archs_Dlink.__dict__[config['arch']]()  # 定义 选择model

# 深度可分离Unet
# model = archs_D.__dict__[config['arch']]()  # 定义 选择model

# RESUNet
# model = archs_RESUNET.__dict__[config['arch']]()  # 定义 选择model