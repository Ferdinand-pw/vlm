import numpy as np
import torch
import torch.nn.functional as F


def iou_score(output, target):
    smooth = 1e-5

    if torch.is_tensor(output):
        output = torch.sigmoid(output).data.cpu().numpy()
    if torch.is_tensor(target):
        target = target.data.cpu().numpy()
    #print(target.shape)
    #print(output.shape)
    a = output.max()
    #print(a)
    output_ = output > 0.5
    target_ = target > 0.5

    #print(output_.shape)
    #print(target_.shape)

    intersection = (output_ & target_).sum()
    union = (output_ | target_).sum()
    iou = (intersection + smooth) / (union + smooth)

    recall = ((output_ & target_).sum() + smooth) / (target_.sum() + smooth)
    accuracy = ((output_ & target_).sum() + smooth) / (output_.sum() + smooth)
    f1 = (2 * recall * accuracy + smooth) / (recall + accuracy +smooth)


    return [iou, recall, accuracy, f1]


def dice_coef(output, target):
    smooth = 1e-5

    output = torch.sigmoid(output).view(-1).data.cpu().numpy()
    target = target.view(-1).data.cpu().numpy()
    intersection = (output * target).sum()

    return (2. * intersection + smooth) / \
        (output.sum() + target.sum() + smooth)
