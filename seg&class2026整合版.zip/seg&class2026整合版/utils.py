import argparse
import torch

def calculate_cls_accuracy(cls_output, cls_target):
    """
    计算分类准确率
    Args:
        cls_output: 模型输出 [batch_size, num_classes]
        cls_target: 真实标签 [batch_size]
    Returns:
        accuracy: 准确率
    """
    _, cls_pred = torch.max(cls_output, 1)
    correct = (cls_pred == cls_target).float().sum()
    accuracy = correct / cls_target.size(0)
    return accuracy


def str2bool(v):
    if v.lower() in ['true', 1]:
        return True
    elif v.lower() in ['false', 0]:
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')


def count_params(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count
