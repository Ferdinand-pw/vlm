# 文件名: prepare_dataset_fixed.py
import os
import shutil
from sklearn.model_selection import train_test_split
import argparse


def split_dataset(base_dir, split_ratio=0.8):
    """
    自动将数据集划分为训练集和验证集，创建符合 MultiTaskDataset 的结构。

    Args:
        base_dir (str): 数据集的根目录, e.g., 'inputs/dsb2018_96'
        split_ratio (float): 训练集所占的比例。

    创建的结构:
    base_dir/
    ├── train/
    │   ├── images/
    │   │   ├── class_A/
    │   │   └── class_B/
    │   └── masks/
    │       ├── class_A/
    │       └── class_B/
    └── val/
        ├── images/
        │   ├── class_A/
        │   └── class_B/
        └── masks/
            ├── class_A/
            └── class_B/
    """
    print(f"开始处理数据集: {base_dir}")

    # 1. 定义原始路径
    source_images_dir = os.path.join(base_dir, 'images')
    source_masks_dir = os.path.join(base_dir, 'masks')

    # 2. 创建训练集和验证集目录
    train_dir = os.path.join(base_dir, 'train')
    val_dir = os.path.join(base_dir, 'val')

    if not os.path.isdir(source_images_dir):
        print(f"错误: 原始图片路径不存在 {source_images_dir}")
        return
    if not os.path.isdir(source_masks_dir):
        print(f"错误: 原始掩码路径不存在 {source_masks_dir}")
        return

    # 3. 遍历每个类别
    class_names = sorted([d for d in os.listdir(source_images_dir)
                          if os.path.isdir(os.path.join(source_images_dir, d))])
    print(f"发现类别: {class_names}")

    for class_name in class_names:
        print(f"\n正在处理类别: {class_name}")

        # 创建目标文件夹（在 train/ 和 val/ 下创建类别文件夹）
        train_class_img_dir = os.path.join(train_dir, 'images', class_name)
        train_class_mask_dir = os.path.join(train_dir, 'masks', class_name)
        val_class_img_dir = os.path.join(val_dir, 'images', class_name)
        val_class_mask_dir = os.path.join(val_dir, 'masks', class_name)

        os.makedirs(train_class_img_dir, exist_ok=True)
        os.makedirs(train_class_mask_dir, exist_ok=True)
        os.makedirs(val_class_img_dir, exist_ok=True)
        os.makedirs(val_class_mask_dir, exist_ok=True)

        # 获取当前类别的所有图片文件名
        current_class_images_dir = os.path.join(source_images_dir, class_name)
        image_files = [f for f in os.listdir(current_class_images_dir)
                       if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]

        if not image_files:
            print(f"警告: 类别 {class_name} 没有图片文件")
            continue

        # 使用sklearn进行划分
        train_files, val_files = train_test_split(image_files, train_size=split_ratio, random_state=42)
        print(f"  - 划分完成: {len(train_files)} 张训练图片, {len(val_files)} 张验证图片")

        # 4. 复制训练集
        for filename in train_files:
            # 复制图片
            img_src = os.path.join(source_images_dir, class_name, filename)
            img_dst = os.path.join(train_class_img_dir, filename)
            shutil.copy(img_src, img_dst)

            # 构建对应的掩码文件名
            mask_filename = os.path.splitext(filename)[0] + '.png'
            mask_src = os.path.join(source_masks_dir, class_name, mask_filename)
            mask_dst = os.path.join(train_class_mask_dir, mask_filename)

            if os.path.exists(mask_src):
                shutil.copy(mask_src, mask_dst)
            else:
                # 尝试其他扩展名
                for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tiff']:
                    alt_mask_filename = os.path.splitext(filename)[0] + ext
                    alt_mask_src = os.path.join(source_masks_dir, class_name, alt_mask_filename)
                    if os.path.exists(alt_mask_src):
                        shutil.copy(alt_mask_src, mask_dst)
                        break
                else:
                    print(f"警告: 找不到 {class_name}/{filename} 对应的掩码文件")

        # 5. 复制验证集
        for filename in val_files:
            # 复制图片
            img_src = os.path.join(source_images_dir, class_name, filename)
            img_dst = os.path.join(val_class_img_dir, filename)
            shutil.copy(img_src, img_dst)

            # 构建对应的掩码文件名
            mask_filename = os.path.splitext(filename)[0] + '.png'
            mask_src = os.path.join(source_masks_dir, class_name, mask_filename)
            mask_dst = os.path.join(val_class_mask_dir, mask_filename)

            if os.path.exists(mask_src):
                shutil.copy(mask_src, mask_dst)
            else:
                # 尝试其他扩展名
                for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tiff']:
                    alt_mask_filename = os.path.splitext(filename)[0] + ext
                    alt_mask_src = os.path.join(source_masks_dir, class_name, alt_mask_filename)
                    if os.path.exists(alt_mask_src):
                        shutil.copy(alt_mask_src, mask_dst)
                        break
                else:
                    print(f"警告: 找不到 {class_name}/{filename} 对应的掩码文件")

    print("\n" + "=" * 50)
    print("数据集划分完成！")
    print("=" * 50)
    print(f"\n训练集路径: {os.path.join(train_dir, 'images')}")
    print(f"验证集路径: {os.path.join(val_dir, 'images')}")

    # 统计总数
    total_train = sum(len(os.listdir(os.path.join(train_dir, 'images', c))) for c in class_names)
    total_val = sum(len(os.listdir(os.path.join(val_dir, 'images', c))) for c in class_names)
    print(f"\n训练集样本数: {total_train}")
    print(f"验证集样本数: {total_val}")
    print(f"总样本数: {total_train + total_val}")

    print("\n现在你可以使用以下路径来训练:")
    print(f"train_img_dir = '{os.path.join(train_dir, 'images')}'")
    print(f"train_mask_dir = '{os.path.join(train_dir, 'masks')}'")
    print(f"val_img_dir = '{os.path.join(val_dir, 'images')}'")
    print(f"val_mask_dir = '{os.path.join(val_dir, 'masks')}'")


def verify_structure(base_dir):
    """
    验证目录结构是否正确
    """
    print("\n" + "=" * 50)
    print("验证目录结构")
    print("=" * 50)

    train_img_dir = os.path.join(base_dir, 'train', 'images')
    val_img_dir = os.path.join(base_dir, 'val', 'images')

    if not os.path.exists(train_img_dir):
        print(f"错误: 训练集目录不存在 {train_img_dir}")
        return False

    if not os.path.exists(val_img_dir):
        print(f"错误: 验证集目录不存在 {val_img_dir}")
        return False

    # 检查训练集
    print(f"\n检查训练集: {train_img_dir}")
    class_names = sorted([d for d in os.listdir(train_img_dir)
                          if os.path.isdir(os.path.join(train_img_dir, d))])

    if not class_names:
        print("错误: 训练集 images 目录下没有类别文件夹")
        return False

    print(f"发现类别: {class_names}")
    for class_name in class_names:
        class_dir = os.path.join(train_img_dir, class_name)
        files = os.listdir(class_dir)
        image_files = [f for f in files if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        print(f"  {class_name}: {len(image_files)} 张图片")

        if len(image_files) == 0:
            print(f"  警告: 类别 {class_name} 没有图片文件")

    return True


if __name__ == '__main__':
    # 配置你的数据集
    dataset_name = "dsb2018_96"  # 修改为你的数据集名称
    base_directory = os.path.join('inputs', dataset_name)

    # 检查原始数据是否存在
    if not os.path.exists(base_directory):
        print(f"错误: 数据集目录不存在 {base_directory}")
        print("请确保:")
        print(f"1. 在 inputs/ 目录下有 {dataset_name} 文件夹")
        print(f"2. {dataset_name}/ 目录下有 images/ 和 masks/ 文件夹")
        print(f"3. images/ 和 masks/ 下都有类别文件夹")
    else:
        # 划分数据集
        split_dataset(base_directory, split_ratio=0.8)

        # 验证结构
        verify_structure(base_directory)