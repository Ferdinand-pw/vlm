数据集按类分好，放在inputs里（images和masks名称对应）；
第一次运行时，先运行prepare_dataset.py划分数据集，然后再运行train；（若已经手动划分好train和val可跳过这一步）；
train_onlySeg.py是只进行分类；train_SegClas.py是分类联合分割。