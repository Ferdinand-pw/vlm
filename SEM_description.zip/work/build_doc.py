from pathlib import Path
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

root = Path(__file__).resolve().parents[1]
source = root / 'deliverables/SEM_技术方案_项目启动修订版.md'
doc = Document()
section = doc.sections[0]
section.page_width, section.page_height = Cm(21), Cm(29.7)
section.top_margin, section.bottom_margin = Cm(2), Cm(1.9)
section.left_margin, section.right_margin = Cm(2.1), Cm(2.1)
for name, size in [('Normal', 11), ('Title', 22), ('Heading 1', 15)]:
    style = doc.styles[name]
    style.font.name = 'Microsoft YaHei'
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor(0, 0, 0)
    style.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    style.paragraph_format.space_after = Pt(7)
    style.paragraph_format.line_spacing = 1.18
doc.styles['Heading 1'].paragraph_format.space_before = Pt(12)
doc.styles['Heading 1'].paragraph_format.keep_with_next = True
for line in source.read_text(encoding='utf-8').splitlines():
    if not line.strip():
        continue
    if line.startswith('# '):
        doc.add_paragraph(line[2:], 'Title')
    elif line.startswith('## '):
        doc.add_paragraph(line[3:], 'Heading 1')
    else:
        p = doc.add_paragraph(line)
        p.paragraph_format.widow_control = True
footer = section.footer.paragraphs[0]
footer.alignment = 2
field = OxmlElement('w:fldSimple')
field.set(qn('w:instr'), 'PAGE')
footer._p.append(field)
doc.core_properties.title = 'SEM缺陷多维度结构化描述技术方案'
doc.core_properties.subject = '512预处理 I01参考 属性角色与视觉复核'
doc.save(root / 'deliverables/SEM_技术方案_项目启动修订版.docx')
print('DOCX saved')
