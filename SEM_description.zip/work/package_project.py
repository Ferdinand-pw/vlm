from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
project = root / 'sem_project'
destination = root / 'deliverables/SEM_project_startup.zip'
with ZipFile(destination, 'w', ZIP_DEFLATED) as archive:
    for item in sorted(project.rglob('*')):
        relative = item.relative_to(project)
        if '__pycache__' in relative.parts or 'drafts' in relative.parts:
            continue
        if item.suffix in {'.pyc', '.pyo'}:
            continue
        name = 'sem_project/' + relative.as_posix()
        if item.is_dir():
            archive.writestr(name + '/', '')
        else:
            archive.write(item, name)
with ZipFile(destination) as archive:
    assert archive.testzip() is None
    assert 'sem_project/scripts/data/resize_dataset.py' in archive.namelist()
    assert 'sem_project/models/pretrained/qwen/' in archive.namelist()
print(destination)
