# 实验过程目录

一次实验一个不可混用的run_id，保存完整配置、数据版本、模型版本、日志、指标及案例结果。训练checkpoint也放在本次run内。已选定权重再归档到models/finetuned。更换I01、Prompt、复核或预处理时建立新run，避免复用旧resume输出。
