#!/usr/bin/env python3
"""Create empty workspace directories. Never move, delete or overwrite files."""
import argparse
from pathlib import Path

DIRECTORIES = [
    'data/raw', 'data/interim/task_a', 'data/interim/task_b',
    'data/processed', 'data/manifests', 'data/splits', 'data/annotations',
    'models/pretrained/dinov3', 'models/pretrained/qwen',
    'models/finetuned/normal_abnormal', 'models/finetuned/defect_type',
    'models/finetuned/attributes', 'models/release',
    'src/sem/data', 'src/sem/vision', 'src/sem/generation',
    'src/sem/review', 'src/sem/measurement', 'src/sem/reporting',
    'scripts/data', 'scripts/train', 'scripts/infer', 'scripts/evaluate', 'scripts/export',
    'configs/experiments', 'prompts', 'runs', 'reports', 'logs', 'tests',
    'docs', 'legacy/v0',
]


def initialize(root):
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    for relative in DIRECTORIES:
        (root / relative).mkdir(parents=True, exist_ok=True)
    return root


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    print(initialize(args.root))
