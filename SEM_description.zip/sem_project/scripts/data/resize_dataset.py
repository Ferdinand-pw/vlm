#!/usr/bin/env python3
"""Create a separate letterboxed SEM dataset and reversible provenance manifest.

Input: a tree such as train/class/*.png. Originals are never changed.
Output must not already exist. Partial failures leave an incomplete run; use a
new output directory after resolving the error. Supports 8-bit L/RGB only.
"""
import argparse
import hashlib
import json
from pathlib import Path
from PIL import Image

EXTENSIONS = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff'}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def geometry(width, height, size):
    scale = min(size / width, size / height)
    nw, nh = max(1, round(width * scale)), max(1, round(height * scale))
    return {'original_wh': [width, height], 'output_wh': [size, size],
            'resized_wh': [nw, nh], 'scale_xy': [nw / width, nh / height],
            'pad_left_top': [(size - nw) // 2, (size - nh) // 2]}


def restore_box(box, transform):
    """Pixel EDGE xyxy, upper-left origin, transformed image -> source image.

    Reject boxes in padding or outside the image rather than silently clipping.
    Caller maps source-view coordinates to the user input separately if needed.
    """
    x1, y1, x2, y2 = box
    px, py = transform['pad_left_top']
    nw, nh = transform['resized_wh']
    if not (px <= x1 < x2 <= px + nw and py <= y1 < y2 <= py + nh):
        raise ValueError('Box must be ordered and inside the valid image region')
    sx, sy = transform['scale_xy']
    return [(x1 - px) / sx, (y1 - py) / sy,
            (x2 - px) / sx, (y2 - py) / sy]


def run(source, output, size=512):
    source, output = Path(source).resolve(), Path(output).resolve()
    if not source.is_dir():
        raise ValueError('Source must be a directory')
    if size <= 0 or size % 16:
        raise ValueError('Size must be a positive multiple of 16')
    if output == source or output.is_relative_to(source) or source.is_relative_to(output):
        raise ValueError('Source and output trees must be separate')
    if output.exists():
        raise FileExistsError('Use a new output directory; no implicit overwrite/resume')
    files = sorted(p for p in source.rglob('*') if p.is_file() and p.suffix.lower() in EXTENSIONS)
    if not files:
        raise ValueError('No supported images found')
    # Preflight all inputs so unsupported depth, frames or orientation do not
    # silently corrupt data. Keep exact pixel orientation for RGB direction rules.
    for path in files:
        if not path.resolve().is_relative_to(source):
            raise ValueError(f'Source link escapes dataset: {path}')
        with Image.open(path) as im:
            if im.mode not in {'L', 'RGB'} or getattr(im, 'n_frames', 1) != 1:
                raise ValueError(f'Explicit conversion required for {path}: {im.mode}')
            if im.getexif().get(274, 1) != 1:
                raise ValueError(f'Explicit orientation normalization required: {path}')
            im.load()
    output.mkdir(parents=True)
    summary = {'status': 'incomplete', 'source': str(source), 'size': size,
               'policy': 'letterbox_lanczos_black_v1', 'count': 0}
    summary_path = output / 'preprocessing.json'
    summary_path.write_text(json.dumps(summary, indent=2), encoding='utf-8')
    with (output / 'manifest.jsonl').open('w', encoding='utf-8') as manifest:
        for path in files:
            rel = path.relative_to(source)
            # Keep the original suffix in the stem to avoid a.jpg/a.png collisions.
            destination = output / rel.parent / (rel.name + '.png')
            destination.parent.mkdir(parents=True, exist_ok=True)
            before = digest(path)
            with Image.open(path) as im:
                transform = geometry(*im.size, size)
                resized = im.resize(tuple(transform['resized_wh']), Image.Resampling.LANCZOS)
                canvas = Image.new(im.mode, (size, size), 0)
                canvas.paste(resized, tuple(transform['pad_left_top']))
                canvas.save(destination)
            if digest(path) != before:
                raise RuntimeError(f'Source changed while processing: {path}')
            record = {'source_path': str(path), 'source_relative_path': rel.as_posix(),
                      'source_sha256': before, 'derived_path': str(destination),
                      'derived_sha256': digest(destination), 'transform': transform,
                      'policy': summary['policy']}
            manifest.write(json.dumps(record, ensure_ascii=False) + '\n')
            summary['count'] += 1
    summary['status'] = 'complete'
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--size', type=int, default=512)
    args = parser.parse_args()
    print(json.dumps(run(args.source, args.output, args.size), ensure_ascii=False, indent=2))
