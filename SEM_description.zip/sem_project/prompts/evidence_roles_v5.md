# SEM 图像证据角色补充规范

这是待接入 worker 的规范，不是已完成的推理实现。调用端应将角色说明紧邻对应图像插入多模态消息；不能只把路径写入文字。图片缺失时按角色识别，不使用固定“第二张”之类编号。

## 输入角色

- input_image：用户输入的完整图像，是本次报告坐标基准。记录 input_view 和尺寸。
- overview_I00：同案例含缺陷主图；若它就是 input_image，不重复输入。
- normal_reference_I01：同案例正常参考，用于理解正常图案、间隔和连续性。它不包含待描述目标，不对它另行计数，不把其坐标当成输入图坐标。
- local_gray：同一目标的可用灰度局部图，注明 target_id、view_code。
- detector_rgb：I02→R、I03→G、I04→B，仅用于对应局部目标；颜色不是材料色，也不是结构标签色。
- structure_label_map：如有，另附图例，不能与探测器 RGB 的颜色含义混用。

## 证据边界

I01 的参考资格由配对审核确认，不能仅凭文件名断言完全正常。未配准时可作结构参照，不作逐像素差异证据。不同倍率或视野的图像没有可靠映射时，坐标、缺陷数量、尺寸不能跨图复制。缺失 I01 或 RGB 时仍分析可用图像，把依赖缺失证据的字段标为无法判断；不补其他案例图片。

报告分别记录 input_image_status 和 case_status。入口 I01 正常并不代表案例不存在缺陷；配套图发现异常但输入图无法定位时，BBox 留空并注明位置待映射。正常/异常头、类型头的输出是候选，不作为关闭其他图像检查的开关。

图案可以是凸起结构，也可以是规则孔或沟槽；不强制把图案定义为凸起实体。凹凸依赖可见证据和已验证的设备方向规则。尺寸只采用可靠轮廓与标定，不把 ROI 当缺陷尺寸。严重程度按已确认的企业规则处理，否则保留待定义。

## 内部字段

每个目标至少记录 target_id、type_candidate、shape、texture、interaction_object、interaction_relation、relief、bbox、direction、size。每个属性携带 value、status（supported / uncertain / conflict / missing）、evidence_ids；未知值用 null。最终中文报告由程序渲染，内部证据字段不必全部展示。
