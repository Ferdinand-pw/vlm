"""SEM project package. Task modules will be migrated after baseline verification."""
