import sys
import tempfile
import unittest
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts' / 'data'))
from resize_dataset import run, digest, geometry, restore_box


class ResizeTests(unittest.TestCase):
    def test_mapping_and_originals(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / 'raw' / 'train' / 'a'
            source.mkdir(parents=True)
            path = source / 'sample.png'
            Image.new('L', (1000, 500), 127).save(path)
            before = digest(path)
            result = run(root / 'raw', root / 'resized')
            self.assertEqual(result['count'], 1)
            self.assertEqual(digest(path), before)
            with Image.open(root / 'resized/train/a/sample.png.png') as im:
                self.assertEqual(im.size, (512, 512))
                self.assertEqual(im.getpixel((0, 0)), 0)
                self.assertEqual(im.getpixel((256, 256)), 127)
            self.assertEqual(restore_box([0, 128, 512, 384], geometry(1000, 500, 512)),
                             [0, 0, 1000, 500])
            with self.assertRaises(ValueError):
                restore_box([0, 0, 512, 512], geometry(1000, 500, 512))
            with self.assertRaises(FileExistsError):
                run(root / 'raw', root / 'resized')

    def test_depth_and_nested_output_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / 'raw'
            source.mkdir()
            Image.new('I;16', (50, 50)).save(source / 'depth.tif')
            with self.assertRaises(ValueError):
                run(source, Path(temp) / 'out')
            self.assertFalse((Path(temp) / 'out').exists())
            with self.assertRaises(ValueError):
                run(source, source / 'out')


if __name__ == '__main__':
    unittest.main()
