# SEM 项目起步包

当前状态：数据预处理工具可独立运行；I01输入与复核已形成规范，尚未接入真实Qwen worker。legacy/v0目录为用户附件的原样副本，不是完整可运行工程。三份source_views附件相同，仅保留一份。

本地根目录为 `D:/AI_wp/SEM_description/sem_project`；公司服务器建议使用 `/input/sem_project`。目录内按相对路径组织，结构完全一致。详细分工见[目录与迁移说明](docs/目录与迁移说明.md)，方案正文见[技术方案](docs/技术方案.md)。模型、数据目录是占位，未放入真实权重和数据。

先在项目根目录执行 `python scripts/init_workspace.py`，可补齐压缩包中不保留的空目录。配置分别放在 `configs/paths.local.json` 和 `configs/paths.server.json`，不把个人绝对路径写死在业务代码里。当前resize命令仍显式传参，路径配置供后续流水线接入使用。

## 先运行512派生集

保留已有train/val/test/class目录结构，不替你重新划分案例。正式实验应先完成按案例/重复缺陷分组划分。

```bash
python -m pip install -r requirements.txt
python scripts/data/resize_dataset.py --help
python scripts/data/resize_dataset.py --source /input/sem_project/data/interim/task_b --output /input/sem_project/data/processed/task_b_512_v1 --size 512
python -m unittest discover -s tests -v
```

工具生成新PNG、manifest.jsonl和preprocessing.json。状态为complete才算本次派生完成。输入位深不支持时明确拒绝，不自动压缩16位；输出已存在时拒绝覆盖。请使用全新输出目录重试，不把未完成目录用于训练。

派生文件名称保留原扩展名，例如a.jpg变为a.jpg.png，避免同名不同格式覆盖。ImageFolder式训练一般可读取，但应核对你的训练代码。现有test1200.tsv与旧batch脚本仍用原图，不能直接将--test-root切换到派生目录：原始文件名及哈希匹配规则都不同。旧--source-map也不能绕过前置哈希匹配。

训练使用新派生目录前，需要检查dinov3_sem_train_hf.py是否还有CenterCrop或随机裁剪、是否重复resize、归一化配置是否一致。保持--image-size 512；模型训练和推理使用同一预处理，避免只换训练输入。两个任务A/B应由案例清单分别导出，旧混合目录resize之后不会自动变成规范A/B数据集。

## 待接入的修改清单

1. source_views：支持I00至I04入口；独立查找I01；RGB只检查三个局部通道而不要求与入口图同尺寸。匹配依据案例及目标身份，拒绝歧义。
2. batch_run50：取消DINO normal直接跳过RGB的硬门控；将input_image/source_image/dino_image分离；用manifest双向哈希验证原图与派生图；保存I01状态。
3. sem_batch_worker / qwen_task1：按prompts/evidence_roles_v5.md实际加载图片并插入多模态消息。新增字段本身不会让Qwen看到I01。
4. 新增复核调用：按prompts/reviewer_v1.md看同案例图像、初稿和程序校验结果；最多修订一次；保留初稿、复核、最终稿及人工复核状态。
5. sem_report_format与导出器：同步处理null、范围限定、复核状态和证据ID；旧格式校验不等于语义正确。
6. resume：将模型/图像/Prompt/预处理/生成参数/Schema版本纳入缓存身份。新实验用新output-root，避免复用旧输出。

## 缺少的文件与环境

需补充dinov3_sem_train_hf.py、sem_batch_worker.py、qwen_task1.py、sem_report_format.py；提供少量同案例I00至I04或完整案例路径清单，检查命名、尺寸、位深和倍率。服务器/input路径当前并未挂载到本工作区，因此没有运行真实SEM数据resize或GPU推理。

训练命令解冻了末4层；请确认classifier.pth是否保存了更新后的骨干、正常异常头、类型头以及类别映射。不要仅凭文件名认定它是完整模型。当前模型目录名仅作为部署标识，实际规格以config及加载日志为准。

工具的restore_box只负责派生图→原始源图的缩放补边回映射；不负责I02→I00的跨视野配准。测试使用合成图，覆盖原图不变、尺寸补边、坐标回映射、补边框拒绝、16位拒绝及覆盖保护，不代表SEM识别效果。
