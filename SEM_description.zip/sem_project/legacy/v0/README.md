# 原实验附件留档

batch_run50.py、source_views.py、export_results.py、prompt_task1_v4.md来自本次用户提供的附件，未修改业务逻辑。export_results.py是为整理存档采用的名称。三份source_views附件哈希相同，仅保留一份。

缺少dinov3_sem_train_hf.py、sem_batch_worker.py、qwen_task1.py和sem_report_format.py，不能直接运行完整流程。原脚本在此留档，后续接入到src和scripts时另存版本。
