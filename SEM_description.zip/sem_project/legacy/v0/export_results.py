#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Export SEM batch results into a review-friendly Excel workbook.

Primary mode (recommended):
    python create_image_description_excel.py \
        --batch-root /input/qwen38_sem/runs/batch50_v3 \
        --output /input/qwen38_sem/runs/batch50_v3/sem_50_review.xlsx

To include all 50 entries even when some haven't run yet, append:
    --list /input/qwen38_sem/task1_full_pipeline/test50.tsv

Legacy mode (two folders, compatible with the original script):
    python create_image_description_excel.py -i /path/to/pngs -m /path/to/mds -o review.xlsx

Dependencies: pip install openpyxl pillow
This script only reads existing files. It NEVER reruns DINO or Qwen.
"""
from __future__ import annotations

import argparse
import io
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

from PIL import Image, ImageOps, ImageDraw, ImageFont
from openpyxl import Workbook, load_workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

# Excel limit is 32767 characters per cell.
EXCEL_TEXT_LIMIT = 32767
ILLEGAL_CHARS = re.compile(r"[\x00-\x08\x0b-\x0c\x0e-\x1f]")
FILL_HEADER = PatternFill("solid", fgColor="17324F")
FILL_TITLE = PatternFill("solid", fgColor="122A43")
FILL_SUBTITLE = PatternFill("solid", fgColor="E7F3F4")
FILL_ALT = PatternFill("solid", fgColor="F4F7FA")
FILL_BLUE = PatternFill("solid", fgColor="E8F1FE")
FILL_GREEN = PatternFill("solid", fgColor="E8F5EA")
FILL_ORANGE = PatternFill("solid", fgColor="FFF0D8")
FILL_RED = PatternFill("solid", fgColor="FCE8E8")
FONT_IMPORTED = "167049"
FONT_INPUT = "1E5AA8"
FONT_STATIC = "69798A"

# Displayed columns: original A,B,C,D,E,F,H,K,L,Q,R only.
# G,I,J,M,N,O,P,S,T were explicitly removed; names are not reintroduced.
COLS = [
    "序号", "原始SEM图", "三探测器RGB图", "预测BBox叠加图", "文件名",
    "测试集类别", "DINO候选", "结构化描述（原文）", "格式错误",
    "人工结论", "人工备注",
]


def excel_string(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    text = ILLEGAL_CHARS.sub("", str(value))
    if len(text) > EXCEL_TEXT_LIMIT:
        text = text[:EXCEL_TEXT_LIMIT - 12] + "\n[内容已截断]"
    # Avoid spreadsheet-formula injection from model-generated or external text.
    if text.lstrip().startswith(("=", "+", "-", "@")):
        text = "'" + text
    return text


def read_json(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        result = json.loads(path.read_text(encoding="utf-8-sig"))
        return result if isinstance(result, dict) else {}
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        print(f"WARN: Could not parse {path}: {exc}")
        return {}


def read_text(path: Path) -> str:
    if not path.is_file():
        return ""
    try:
        return path.read_text(encoding="utf-8-sig").strip()
    except (OSError, UnicodeError) as exc:
        print(f"WARN: Could not read {path}: {exc}")
        return ""


def available_file(value: Any) -> Path | None:
    if not isinstance(value, (str, Path)) or not str(value):
        return None
    path = Path(value).expanduser()
    return path if path.is_file() else None


def extract_dino_probability(dino: dict) -> float | None:
    stage = dino.get("stage1_normal_vs_defect") or {}
    try:
        if isinstance(stage, dict) and "defect" in stage:
            probability = float(stage["defect"])
            return probability if 0.0 <= probability <= 1.0 else None
    except (TypeError, ValueError):
        pass
    return None


def parse_tsv(path: Path) -> list[dict]:
    entries = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) != 2:
            print(f"WARN: Ignored malformed TSV line {line_number}: {line[:100]}")
            continue
        cls, filename = (part.strip() for part in parts)
        if not cls or not filename:
            continue
        if cls.lower() in ("class", "类别") and filename.lower() in ("filename", "文件名"):
            continue
        entries.append({"index": len(entries) + 1, "class": cls, "filename": filename})
    return entries


def find_batch_dir(root: Path, index: int, cls: str) -> Path:
    expected = root / f"{index:03d}_{cls}"
    if expected.is_dir():
        return expected
    matches = sorted(p for p in root.glob(f"{index:03d}_*") if p.is_dir())
    return matches[0] if len(matches) == 1 else expected


def collect_batch(root: Path, sample_list: Path | None, test_root: Path | None) -> list[dict]:
    summary = read_json(root / "batch_summary.json")
    by_index = {}
    for result in summary.get("results", []):
        if isinstance(result, dict):
            try:
                by_index[int(result["index"])] = result
            except (ValueError, KeyError, TypeError):
                continue

    if sample_list is not None:
        entries = parse_tsv(sample_list)
    elif by_index:
        entries = [by_index[i] for i in sorted(by_index)]
    else:
        entries = []
        for folder in sorted(root.iterdir()):
            if folder.is_dir():
                match = re.match(r"^(\d+)_([^/]+)$", folder.name)
                if match:
                    request = read_json(folder / "task1_request.json")
                    entries.append({
                        "index": int(match.group(1)),
                        "class": match.group(2),
                        "filename": Path(str(request.get("original_input", ""))).name,
                    })

    rows = []
    for item in entries:
        try:
            index = int(item["index"])
        except (KeyError, ValueError, TypeError):
            continue
        summary_row = by_index.get(index, {})
        cls = str(item.get("class") or summary_row.get("class") or "")
        filename = str(item.get("filename") or summary_row.get("filename") or "")
        folder = find_batch_dir(root, index, cls)
        request = read_json(folder / "task1_request.json")
        dino = read_json(folder / "dino_prediction.json") or request.get("dino") or {}
        report_json = read_json(folder / "qwen_report.json")
        selection = read_json(folder / "source_selection.json")

        original = available_file(request.get("original_input"))
        if original is None and test_root is not None and cls and filename:
            original = available_file(test_root / cls / filename)
        if original is None:
            original = available_file(request.get("source_path"))
        rgb = available_file(request.get("composite_image"))
        if rgb is None:
            rgb = available_file(folder / "detectors_02R_03G_04B.png")

        report = report_json.get("final") or read_text(folder / "qwen_report.md") or summary_row.get("qwen_report", "")
        status = report_json.get("status") or summary_row.get("status") or "未运行"
        errors = report_json.get("format_errors", summary_row.get("format_errors", []))
        if isinstance(errors, list):
            errors = "\n".join(str(x) for x in errors)
        if not errors and report_json.get("error"):
            errors = str(report_json["error"])
        if not errors and summary_row.get("error"):
            errors = str(summary_row["error"])
        candidate = dino.get("candidate") or summary_row.get("dino_candidate") or ""
        # Use the actual DINO decision, never the TSV ground-truth label.
        # Explicit is_defect=False takes precedence over a potentially stale candidate.
        is_normal = (dino.get("is_defect") is False or
                     (dino.get("is_defect") is None and str(candidate).strip().lower() == "normal"))
        if is_normal:
            rgb = None  # Normal prediction: never embed or link the RGB composite in Excel.
        rows.append({
            "index": index, "filename": filename or (original.name if original else ""),
            "class": cls, "layer": request.get("layer", ""),
            "dino_candidate": candidate, "dino_prob": extract_dino_probability(dino),
            "status": status, "report": report, "errors": errors,
            "original": original, "rgb": rgb, "dino_is_normal": is_normal,
            "source_selection": selection.get("selection_status", ""),
        })
    return rows


def collect_legacy(image_folder: Path, md_folder: Path) -> list[dict]:
    pngs = sorted(p for p in image_folder.iterdir() if p.is_file() and p.suffix.lower() == ".png")
    descriptions = {}
    for path in sorted(md_folder.iterdir()):
        if path.is_file() and path.suffix.lower() in (".md", ".txt"):
            descriptions.setdefault(path.stem.lower(), path)
    rows = []
    for i, image in enumerate(pngs, start=1):
        desc_path = descriptions.get(image.stem.lower())
        rows.append({
            "index": i, "filename": image.name, "class": "", "layer": "",
            "dino_candidate": "", "dino_prob": None,
            "status": "已读取" if desc_path else "缺少描述",
            "report": read_text(desc_path) if desc_path else "",
            "errors": "" if desc_path else "未找到同名MD/TXT文件",
            "original": image, "rgb": None, "source_selection": "",
        })
    return rows


# Qwen task-one relative BBox: left-bottom origin; x grows right, y grows up.
# Read only the report's explicitly emitted boxes. Never infer boxes from filename/label/RGB.
BBOX_REGEX = re.compile(
    r"相对位置\s*[\[［]\s*(\d{1,4})\s*[,，]\s*(\d{1,4})\s*[,，]\s*"
    r"(\d{1,4})\s*[,，]\s*(\d{1,4})\s*[\]］]"
)
BBOX_COLORS = ("#FF3333", "#00C8E8", "#FFB000", "#D866FF", "#50CC77")


def extract_prediction_boxes(report: str) -> list[tuple[int, int, int, int]]:
    """Extract valid 0..1000 Qwen BBoxes from a report, in report order."""
    if not isinstance(report, str) or not report.strip():
        return []
    boxes = []
    for m in BBOX_REGEX.finditer(report):
        x_min, y_min, x_max, y_max = map(int, m.groups())
        if 0 <= x_min < x_max <= 1000 and 0 <= y_min < y_max <= 1000:
            boxes.append((x_min, y_min, x_max, y_max))
        else:
            print(f"WARN: Skip invalid Qwen BBox {m.group(0)}")
    return boxes


def relative_bbox_to_pixels(bbox: tuple[int, int, int, int], width: int, height: int):
    """Convert 0..1000 bottom-left relative coordinates to PIL top-left pixel coords."""
    x_min, y_min, x_max, y_max = bbox
    left = round(x_min * width / 1000)
    top = round((1000 - y_max) * height / 1000)
    right = round(x_max * width / 1000)
    bottom = round((1000 - y_min) * height / 1000)
    return (max(0, min(left, width - 1)), max(0, min(top, height - 1)),
            max(0, min(right, width - 1)), max(0, min(bottom, height - 1)))


def embed_bbox_thumbnail(ws, target: str, path: Path | None, report: str,
                         width: int, height: int, image_refs: list) -> int:
    """Annotate original SEM ONLY; RGB is never used to calculate or render a BBox."""
    boxes = extract_prediction_boxes(report)
    if path is None:
        ws[target] = "未找到原始SEM图"
        ws[target].font = Font(color="C36B18", size=10)
        return 0
    if not boxes:
        ws[target] = "报告无有效预测BBox"
        ws[target].font = Font(color="C36B18", size=10)
        ws[target].alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        return 0
    try:
        with Image.open(path) as src:
            src.load()
            image = ImageOps.exif_transpose(src).convert("RGB")
        # Thumbnail first to keep the colored outlines and box index legible in Excel.
        image.thumbnail((width, height), Image.Resampling.LANCZOS)
        drawer = ImageDraw.Draw(image)
        for index, bbox in enumerate(boxes, start=1):
            left, top, right, bottom = relative_bbox_to_pixels(bbox, *image.size)
            color = BBOX_COLORS[(index - 1) % len(BBOX_COLORS)]
            line_width = max(2, round(min(image.size) / 110))
            drawer.rectangle((left, top, right, bottom), outline=color, width=line_width)
            tag = str(index)
            font = ImageFont.load_default()
            tagbox = drawer.textbbox((0, 0), tag, font=font)
            tagwidth = tagbox[2] - tagbox[0] + 7
            tagheight = tagbox[3] - tagbox[1] + 6
            # Prefer just above BBox; move inside image if near top edge.
            tagx = max(0, min(left, image.width - tagwidth))
            tagy = top - tagheight if top >= tagheight else min(image.height - tagheight, top + 1)
            drawer.rectangle((tagx, tagy, tagx + tagwidth, tagy + tagheight), fill=color)
            drawer.text((tagx + 3, tagy + 2 - tagbox[1]), tag, fill="black", font=font)
        buf = io.BytesIO()
        image.save(buf, format="PNG", optimize=True)
        buf.seek(0)
        image_refs.append(buf)
        ximg = XLImage(buf)
        ximg.width, ximg.height = image.size
        ws.add_image(ximg, target)
        return len(boxes)
    except Exception as exc:
        ws[target] = f"BBox图像生成失败: {type(exc).__name__}"
        print(f"WARN: BBox image embedding failed for {path}: {exc}")
        return 0


def embed_thumbnail(ws, target: str, path: Path | None, width: int, height: int, image_refs: list) -> bool:
    if path is None:
        ws[target] = "未找到图像"
        ws[target].font = Font(color="C36B18", size=10)
        return False
    try:
        with Image.open(path) as src:
            src.load()
            image = ImageOps.exif_transpose(src).convert("RGB")
            image.thumbnail((width, height), Image.Resampling.LANCZOS)
            buf = io.BytesIO()
            # PNG is lossless: avoid introducing artifacts in the SEM image.
            image.save(buf, format="PNG", optimize=True)
        buf.seek(0)
        image_refs.append(buf)  # Keep stream alive until wb.save finishes.
        ximg = XLImage(buf)
        ximg.width, ximg.height = image.size
        ws.add_image(ximg, target)
        return True
    except Exception as exc:
        ws[target] = f"图片读取失败: {type(exc).__name__}"
        print(f"WARN: Image embedding failed for {path}: {exc}")
        return False


def add_dropdown(ws, column: str, options: list[str], last_row: int):
    validation = DataValidation(type="list", formula1='"' + ",".join(options) + '"', allow_blank=True)
    validation.error = "请从列表中选择"
    validation.errorTitle = "无效值"
    validation.showErrorMessage = True
    validation.errorStyle = "stop"
    validation.promptTitle = "人工审核"
    validation.prompt = "请选择审核结果，可留空。"
    validation.showInputMessage = True
    ws.add_data_validation(validation)
    validation.add(f"{column}2:{column}{max(last_row, 2)}")


def add_summary_sheet(wb, records: list[dict], source_label: str):
    ws = wb.create_sheet("汇总概览", 0)
    ws.sheet_view.showGridLines = False
    ws.merge_cells("A1:E2")
    title = ws["A1"]
    title.value = "SEM 图像结构化描述 · 人工审核"
    title.fill = FILL_TITLE
    title.font = Font(size=17, bold=True, color="FFFFFF")
    title.alignment = Alignment(vertical="center", indent=1)
    ws.row_dimensions[1].height = 26
    ws.row_dimensions[2].height = 21

    ws.merge_cells("A4:E4")
    ws["A4"] = "批量来源：" + source_label
    ws["A4"].font = Font(color=FONT_STATIC, size=10)
    ws["A4"].alignment = Alignment(wrap_text=True)
    ws.row_dimensions[4].height = 30

    last = max(len(records) + 1, 100)
    report_range = f"'逐图核对'!H2:H{last}"
    errors_range = f"'逐图核对'!I2:I{last}"
    review_range = f"'逐图核对'!J2:J{last}"
    # Qwen status column was removed at user request: do not reference it.
    summary_items = [
        ("图像条数", f"=COUNTA('逐图核对'!A2:A{last})"),
        ("已有Qwen描述", f'=COUNTIF({report_range},"?*")'),
        ("格式错误记录", f'=COUNTIF({errors_range},"?*")'),
        ("人工审核通过", f'=COUNTIF({review_range},"通过")'),
        ("需要修改", f'=COUNTIF({review_range},"需修改")'),
        ("未通过", f'=COUNTIF({review_range},"不通过")'),
        ("待审核", f'=COUNTIF({review_range},"待审核")'),
    ]
    for i, (label, formula) in enumerate(summary_items, start=6):
        ws[f"A{i}"] = label
        ws[f"A{i}"].font = Font(color="33506D", size=11)
        ws[f"B{i}"] = formula
        ws[f"B{i}"].font = Font(bold=True, size=12, color="176F6C")
        ws[f"B{i}"].fill = FILL_SUBTITLE
        ws[f"B{i}"].alignment = Alignment(horizontal="center")
        ws.row_dimensions[i].height = 27

    ws.merge_cells("A15:E15")
    ws["A15"] = "使用提示"
    ws["A15"].fill = FILL_HEADER
    ws["A15"].font = Font(color="FFFFFF", bold=True)
    notes = [
        "1. 逐图核对：B列是完全无标记的SEM原图；C列是RGB合成图；D列是独立BBox标注图。",
        "2. 仅J列『人工结论』和K列『人工备注』需要人工填写；J列支持下拉选择。",
        "3. F列测试集类别仅供对照，G列DINO候选是模型预测，两者不要混淆。",
        "4. H列保留Qwen结构化描述原文；I列保留报告格式错误信息。",
        "5. BBox为以原图左下角为原点的0–1000相对坐标，彩框位置需人工核对。",
        "6. DINO判断正常时，C列RGB图不显示；原始SEM不受影响。",
        "7. 已按要求移除Layer、DINO缺陷概率、Qwen状态、四项细分审核以及两列路径。",
        "8. 汇总中的描述及格式错误数量按当前表格非空单元格统计。",
    ]
    for i, note in enumerate(notes, start=16):
        ws.merge_cells(start_row=i, start_column=1, end_row=i, end_column=5)
        c = ws.cell(i, 1, note)
        c.alignment = Alignment(wrap_text=True, vertical="center")
        c.font = Font(size=10, color="435466")
        ws.row_dimensions[i].height = 26
    for col, width in {"A": 25, "B": 19, "C": 20, "D": 20, "E": 22}.items():
        ws.column_dimensions[col].width = width


def create_image_description_excel(
    batch_root: str | Path | None = None,
    output_excel: str | Path = "sem_50_review.xlsx",
    image_size: tuple[int, int] = (230, 230),
    sample_list: str | Path | None = None,
    test_root: str | Path | None = None,
    image_folder: str | Path | None = None,
    md_folder: str | Path | None = None,
) -> dict:
    """Read SEM batch outputs and embed images + descriptions in a review workbook."""
    if image_folder or md_folder:
        if not (image_folder and md_folder):
            raise ValueError("Legacy mode requires both image_folder and md_folder")
        images, descriptions = Path(image_folder), Path(md_folder)
        if not images.is_dir() or not descriptions.is_dir():
            raise FileNotFoundError(f"Missing image/description directory: {images}, {descriptions}")
        rows = collect_legacy(images, descriptions)
        source_label = f"{images} + {descriptions}"
    else:
        root = Path(batch_root or "/input/qwen38_sem/runs/batch50_v3").expanduser()
        if not root.is_dir():
            raise NotADirectoryError(f"Batch result root does not exist: {root}")
        list_path = Path(sample_list) if sample_list else None
        if list_path and not list_path.is_file():
            raise FileNotFoundError(list_path)
        rows = collect_batch(root, list_path, Path(test_root) if test_root else None)
        source_label = str(root)
    if not rows:
        raise ValueError("No SEM entries found. Check batch_summary.json / --list / input folders")

    width, height = image_size
    if width < 40 or height < 40 or width > 1000 or height > 1000:
        raise ValueError("Image width and height must each be in [40, 1000]")
    wb = Workbook()
    ws = wb.active
    ws.title = "逐图核对"
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "B2"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.sheet_properties.outlinePr.summaryBelow = True
    ws.sheet_view.zoomScale = 80

    for col_num, name in enumerate(COLS, 1):
        cell = ws.cell(1, col_num, name)
        cell.fill = FILL_HEADER
        cell.font = Font(name="Microsoft YaHei", size=10, bold=True, color="FFFFFF")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 35

    widths = {
        "A": 8, "B": width / 7.2 + 4, "C": width / 7.2 + 4,
        "D": width / 7.2 + 4, "E": 55, "F": 20, "G": 20,
        "H": 84, "I": 30, "J": 17, "K": 50,
    }
    for col, colwidth in widths.items():
        ws.column_dimensions[col].width = colwidth

    image_refs = []
    statuses = Counter()
    for row_number, entry in enumerate(rows, start=2):
        statuses[entry["status"]] += 1
        values = {
            "A": entry["index"], "E": entry["filename"], "F": entry["class"],
            "G": entry["dino_candidate"], "H": entry["report"],
            "I": entry["errors"],
        }
        for col, value in values.items():
            cell = ws[f"{col}{row_number}"]
            cell.value = value if col == "A" else excel_string(value)
            cell.alignment = Alignment(vertical="top", wrap_text=col in ("E", "H", "I"))
            cell.font = Font(name="Microsoft YaHei", size=10,
                             color=FONT_IMPORTED if col not in ("A", "E") else FONT_STATIC)
            if row_number % 2 == 0:
                cell.fill = FILL_ALT
        for col in ("J", "K"):
            cell = ws[f"{col}{row_number}"]
            cell.font = Font(name="Microsoft YaHei", size=10, color=FONT_INPUT)
            cell.fill = FILL_BLUE
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        # About 0.75 pt per image pixel, max Excel row height is 409.5 pt.
        text_lines = str(entry["report"]).count("\n") + 1 if entry["report"] else 1
        text_height = 16 * text_lines + 16
        ws.row_dimensions[row_number].height = min(405, max(height * 0.75 + 12, text_height))
        # B: always embed the untouched SEM image. C: original RGB position.
        # D: independent SEM-with-predicted-BBox visualization only.
        embed_thumbnail(ws, f"B{row_number}", entry["original"], width, height, image_refs)
        if entry.get("dino_is_normal", False):
            cell = ws[f"C{row_number}"]
            cell.value = "DINO判定正常，无需三通道图"
            cell.font = Font(name="Microsoft YaHei", size=10, color=FONT_STATIC)
            cell.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        else:
            embed_thumbnail(ws, f"C{row_number}", entry["rgb"], width, height, image_refs)
        embed_bbox_thumbnail(ws, f"D{row_number}", entry["original"], entry["report"],
                             width, height, image_refs)
        if entry["errors"]:
            ws[f"I{row_number}"].fill = FILL_ORANGE

    maxrow = len(rows) + 1
    add_dropdown(ws, "J", ["通过", "需修改", "不通过", "待审核"], maxrow)
    ws.auto_filter.ref = f"A1:K{maxrow}"
    ws.print_title_rows = "1:1"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    add_summary_sheet(wb, rows, source_label)
    wb.active = 1  # Open the workbook on the per-image review sheet.
    try:
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
    except AttributeError:
        pass
    output = Path(output_excel).expanduser()
    output.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output)
    for stream in image_refs:
        stream.close()
    # Verify the written file can be reopened and all sample rows remain present.
    check = load_workbook(output, read_only=False)
    try:
        assert check["逐图核对"].max_row == maxrow
        assert len(check["逐图核对"]._images) <= 3 * len(rows)
    finally:
        check.close()
    print(f"Excel created: {output}")
    print(f"Samples: {len(rows)} | Status: {dict(statuses)} | Embedded images: {len(image_refs)}")
    return {"total": len(rows), "status_counts": dict(statuses), "output": str(output)}


def main():
    parser = argparse.ArgumentParser(description="将50张SEM图像及Qwen结构化报告导出到Excel，供人工审核")
    parser.add_argument("--batch-root", default=None, help="批处理输出根目录，含batch_summary.json和001_类别/等子目录")
    parser.add_argument("--list", dest="sample_list", default=None, help="可选test50.tsv：按列表顺序导出全部50张，包括失败/未运行样本")
    parser.add_argument("--test-root", default=None, help="可选测试集根目录，在请求JSON缺少原始图路径时回退")
    parser.add_argument("--output", "-o", default="sem_50_review.xlsx", help="Excel保存路径")
    parser.add_argument("--width", "-w", type=int, default=230, help="嵌入图像最大宽度(像素)")
    parser.add_argument("--height", "--ht", type=int, default=230, help="嵌入图像最大高度(像素)")
    parser.add_argument("--image_folder", "-i", default=None, help="兼容旧脚本：PNG图像文件夹")
    parser.add_argument("--md_folder", "-m", default=None, help="兼容旧脚本：MD/TXT文件夹")
    args = parser.parse_args()
    create_image_description_excel(
        batch_root=args.batch_root, output_excel=args.output,
        image_size=(args.width, args.height), sample_list=args.sample_list,
        test_root=args.test_root, image_folder=args.image_folder, md_folder=args.md_folder,
    )


if __name__ == "__main__":
    main()


"""
python /input/qwen38_sem/scripts/create_image_description_excel.py \
  --batch-root /input/qwen38_sem/runs/batch50_v5 \
  --list /input/qwen38_sem/task1_full_pipeline/test50.tsv \
  --output /input/qwen38_sem/runs/batch50_v5/sem_50_review.xlsx \
  --width 230 \
  --height 230

  python /input/qwen38_sem/scripts/create_image_description_excel.py \
  --batch-root /input/qwen38_sem/runs/batch50_test_46_scan \
  --list /input/qwen38_sem/task1_full_pipeline/test50_only_46.tsv \
  --output /input/qwen38_sem/runs/batch50_v1/sem_46_review.xlsx \
  --width 230 \
  --height 230
"""