#!/usr/bin/env python3
"""SEM batch: DINO once, Qwen once, in separate Python/Conda environments.

Requires existing source_views.py, qwen_task1.py, dinov3_sem_train_hf.py,
plus bundled sem_batch_worker.py. Does not change the proven single-image scripts.

--qwen-mode subprocess is a slower exact-baseline mode that invokes the original
qwen_task1.py once per image (for inputs with a valid three-detector composite).
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import time
import traceback
from pathlib import Path

from source_views import compose_views, find_views, layer_from_path, sha256_file
from sem_report_format import validate_result

VIEW_REGEX = r"I(?P<view>0[0-4])(?=[A-Z]|$)"  # Real SEM filenames use I02K..., not I02.png
PREFIX = "@@SEM_BATCH_RESULT@@"
SUCCESS = {"complete", "invalid_format"}


def save_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def python_prefix(python, conda_env, conda_exe):
    if python and conda_env:
        raise ValueError("Specify either --*-python or --*-conda-env, not both")
    if conda_env:
        if not shutil.which(conda_exe):
            raise FileNotFoundError(f"Conda executable unavailable: {conda_exe}")
        return [conda_exe, "run", "--no-capture-output", "-n", conda_env, "python", "-u"]
    if python:
        if not Path(python).is_file():
            raise FileNotFoundError(python)
        return [str(Path(python).resolve()), "-u"]
    return [sys.executable, "-u"]


class Worker:
    def __init__(self, command, log_path: Path, name: str):
        self.name = name
        log_path.parent.mkdir(parents=True, exist_ok=True)
        self.error_log = log_path
        self.err_stream = log_path.open("w", encoding="utf-8")
        self.proc = subprocess.Popen(
            command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=self.err_stream, text=True, encoding="utf-8", bufsize=1)
        ready = self._receive()
        if ready.get("kind") != "ready":
            raise RuntimeError(f"{name} worker did not initialize: {ready}")
        print(f"[{name}] Ready: {json.dumps(ready, ensure_ascii=False)}", flush=True)

    def _receive(self):
        while True:
            line = self.proc.stdout.readline()
            if not line:
                raise RuntimeError(f"{self.name} worker exited (code={self.proc.poll()}). "
                                   f"Inspect {self.error_log}")
            line = line.rstrip("\n")
            if line.startswith(PREFIX):
                return json.loads(line[len(PREFIX):])
            print(f"[{self.name}] {line}", flush=True)

    def run(self, request):
        self.proc.stdin.write(json.dumps(request, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()
        response = self._receive()
        if response.get("kind") != "result" or response.get("id") != request["id"]:
            raise RuntimeError(f"{self.name} unexpected response: {response}")
        return response

    def close(self):
        try:
            if self.proc.poll() is None:
                self.proc.stdin.write('{"action":"stop"}\n')
                self.proc.stdin.flush()
                self.proc.stdin.close()
                try:
                    self.proc.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
                    self.proc.wait(timeout=10)
        except (OSError, BrokenPipeError, ValueError):
            if self.proc.poll() is None:
                self.proc.kill()
                self.proc.wait()
        finally:
            self.err_stream.close()


def load_entries(tsv: Path, limit: int):
    entries = []
    with tsv.open("r", encoding="utf-8-sig") as fh:
        for line_no, line in enumerate(fh, 1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            fields = line.split("\t")
            if len(fields) != 2:
                raise ValueError(f"Line {line_no}: expected <class>\\t<filename>, got {line!r}")
            cls, filename = fields
            if cls.lower() in {"class", "label"} and filename.lower() in {"filename", "file"}:
                continue
            if not filename or Path(filename).name != filename or not cls:
                raise ValueError(f"Invalid file entry at TSV line {line_no}")
            entries.append((cls, filename))
            if limit and len(entries) >= limit:
                break
    if not entries:
        raise ValueError(f"No entries in {tsv}")
    return entries


def _indexed_candidates(filename, args):
    """Read the index, keeping only existing files underneath --source-root."""
    root = Path(args.source_root).resolve()
    with sqlite3.connect(args.index_db) as db:
        names = [Path(row[0]).resolve() for row in db.execute(
            "SELECT path FROM files WHERE name=?", (filename,))]
    return sorted({p for p in names if p.is_file() and p.is_relative_to(root)}, key=str)


def _view_signature(path, args):
    """Represent the evidence Qwen would see, not just a filename or layer."""
    try:
        views = find_views(path, args.view_regex)
        return [sha256_file(views[code]) for code in ("02", "03", "04")], None
    except Exception as exc:
        return None, str(exc)


def choose_image(cls, filename, args):
    """Return (DINO input, exact original, match status, audit record).

    Duplicate *identical* originals are interchangeable only if their layer
    agrees and their available RGB detector evidence is consistent.
    Differing layers / differing complete view sets must never be guessed.
    """
    test_path = Path(args.test_root) / cls / filename
    input_path = test_path.resolve() if test_path.is_file() else None
    paths = _indexed_candidates(filename, args)
    if not paths:
        raise FileNotFoundError(f"No indexed original for {filename!r} under {args.source_root}")
    # If the class is represented in source paths, keep only that class. The
    # TSV label is used for lookup, never as the DINO or Qwen prediction.
    class_paths = [p for p in paths if cls in p.parts]
    if class_paths:
        paths = class_paths
    elif input_path is None:
        raise FileNotFoundError(f"No test image and no indexed source in class {cls!r}: {filename}")
    if input_path is not None:
        expected_hash = sha256_file(input_path)
        paths = [p for p in paths if sha256_file(p) == expected_hash]
        if not paths:
            raise ValueError(f"No byte-identical source image for test file {input_path}")
    elif len(paths) > 1:
        hashes = {sha256_file(p) for p in paths}
        if len(hashes) != 1:
            raise ValueError(f"Multiple DIFFERENT images share {cls}/{filename}; "
                             f"supply --source-map to choose a verified path: {list(map(str, paths))}")

    audit = {"class": cls, "filename": filename,
             "test_image": str(input_path) if input_path else None,
             "candidate_count": len(paths), "candidates": []}
    if len(paths) == 1:
        chosen = paths[0]
        status = "unique_exact_original" if input_path is None else "unique_byte_identical_original"
    else:
        for p in paths:
            signature, issue = _view_signature(p, args)
            layer = layer_from_path(p, anchor=None, parent=args.layer_parent)
            audit["candidates"].append({"path": str(p), "layer": layer,
                                        "has_full_rgb_views": signature is not None,
                                        "rgb_view_sha256": signature,
                                        "view_error": issue})

        # Explicit, reviewed choice when different layers or RGB evidence exist.
        mapping = getattr(args, "source_map_data", {})
        mapped = mapping.get(f"{cls}/{filename}", mapping.get(filename))
        if mapped is not None:
            chosen = Path(mapped).resolve()
            if chosen not in paths:
                raise ValueError(f"--source-map selects {chosen}, not an indexed, matching source "
                                 f"for {cls}/{filename}: {list(map(str, paths))}")
            status = "explicit_source_map_exact_match"
        elif input_path in paths:
            chosen = input_path  # Exact indexed path is unambiguous.
            status = "same_indexed_path"
        else:
            layers = {item["layer"] for item in audit["candidates"]}
            if len(layers) != 1:
                details = [(item["layer"], item["path"]) for item in audit["candidates"]]
                raise ValueError(f"Byte-identical sources have DIFFERENT layers for {cls}/{filename}: "
                                 f"{details}. Provide --source-map with the reviewed original path.")
            good = [item for item in audit["candidates"] if item["rgb_view_sha256"] is not None]
            signatures = {tuple(item["rgb_view_sha256"]) for item in good}
            if len(signatures) > 1:
                details = [(item["path"], item["rgb_view_sha256"]) for item in good]
                raise ValueError(f"Identical originals have DIFFERENT I02/I03/I04 images "
                                 f"for {cls}/{filename}: {details}. Provide --source-map.")
            # Prefer a complete detector set. If several are equivalent, use a
            # stable lexical path; never choose arbitrarily based on iterdir order.
            eligible = good if good else audit["candidates"]
            chosen = Path(sorted(item["path"] for item in eligible)[0])
            status = ("duplicate_identical_same_layer_equivalent_rgb" if good
                      else "duplicate_identical_same_layer_single_view")
    audit["selected_source"] = str(chosen)
    audit["selection_status"] = status
    audit["dino_input"] = str(input_path or chosen)
    return input_path or chosen, chosen, status, audit


def prepare_one(index, cls, filename, args, dino):
    out_dir = Path(args.output_root) / f"{index:03d}_{cls}"
    out_dir.mkdir(parents=True, exist_ok=True)
    img, source, source_status, source_audit = choose_image(cls, filename, args)
    save_json(out_dir / "source_selection.json", source_audit)
    layer = layer_from_path(source, anchor=None, parent=args.layer_parent)
    response = dino.run({"id": index, "image": str(img)})
    if not response.get("ok"):
        raise RuntimeError(f"DINO failed: {response.get('error')}\n{response.get('traceback')}")
    dino_prediction = response["result"]
    save_json(out_dir / "dino_prediction.json", dino_prediction)
    composite_path = out_dir / "detectors_02R_03G_04B.png"
    composite = None
    views = {}
    composite_error = None
    try:
        if not dino_prediction.get("is_defect", True):
            raise ValueError("DINO classified normal; RGB composite intentionally skipped")
        # If original filename has I05, view_key() deliberately rejects it.
        # We never forge an I02/I03/I04 three-channel composite.
        views = find_views(source, args.view_regex)
        composite = compose_views(views, img, composite_path, out_dir / "channels.json")
    except Exception as exc:
        composite_error = str(exc)
        composite_path = None
        print(f"  INFO: no valid RGB composite; using single-view fallback: {exc}", flush=True)
        if args.require_composite:
            raise
    request = {
        "status": "prepared_from_real_files", "original_input": str(img),
        "original_sha256": sha256_file(img), "source_path": str(source),
        "source_match_status": source_status, "layer": layer,
        "views": {code: str(path) for code, path in views.items()} if composite else {},
        "composite_image": str(composite_path) if composite_path else None,
        "composite_metadata": composite, "composite_error": composite_error,
        "dino": dino_prediction,
        "report_candidate": None,
    }
    save_json(out_dir / "task1_request.json", request)
    return request


def baseline_qwen(request_path, out_dir, args, qwen_prefix):
    request = json.loads(request_path.read_text(encoding="utf-8-sig"))
    if not request.get("composite_image"):
        raise RuntimeError("Original qwen_task1.py requires two images. "
                           "For single-view fallback use --qwen-mode persistent")
    output = out_dir / "qwen_report.json"
    command = qwen_prefix + [str(Path(__file__).with_name("qwen_task1.py")),
                             "--request", str(request_path), "--prompt", str(Path(args.prompt).resolve()),
                             "--backend", "local-hf", "--model-dir", str(Path(args.qwen_model_dir).resolve()),
                             "--max-new-tokens", str(args.max_new_tokens), "--output", str(output)]
    started = time.perf_counter()
    with (out_dir / "qwen_subprocess_stdout.txt").open("w", encoding="utf-8") as out, \
         (out_dir / "qwen_subprocess_stderr.txt").open("w", encoding="utf-8") as err:
        proc = subprocess.run(command, stdout=out, stderr=err, check=False)
    if proc.returncode:
        raise RuntimeError(f"Original qwen_task1.py exit={proc.returncode}; see {out_dir / 'qwen_subprocess_stderr.txt'}")
    result = json.loads(output.read_text(encoding="utf-8-sig"))
    result.setdefault("generation_seconds", round(time.perf_counter() - started, 3))
    return validate_result(result, request["layer"])


def summarize(rows, path, started):
    counts = Counter(row.get("status", "unknown") for row in rows)
    save_json(path, {"total": len(rows), "elapsed_seconds": round(time.perf_counter()-started, 1),
                     "status_counts": dict(counts), "results": rows})
    return counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--list", required=True, help="TSV: class<TAB>filename")
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--test-root", required=True)
    parser.add_argument("--index-db", required=True)
    parser.add_argument("--source-map", help="Optional JSON: class/filename or filename -> reviewed original path")
    parser.add_argument("--layer-parent", type=int, default=2)
    parser.add_argument("--view-regex", default=VIEW_REGEX)
    parser.add_argument("--dino-script", required=True)
    parser.add_argument("--dino-model-dir", required=True)
    parser.add_argument("--dino-head", required=True)
    parser.add_argument("--dino-device", default="cuda")
    parser.add_argument("--prompt", required=True)
    parser.add_argument("--qwen-model-dir", required=True)
    parser.add_argument("--max-new-tokens", type=int, default=2048)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--dino-python")
    parser.add_argument("--dino-conda-env")
    parser.add_argument("--qwen-python")
    parser.add_argument("--qwen-conda-env")
    parser.add_argument("--conda-exe", default="conda")
    parser.add_argument("--qwen-mode", choices=("persistent", "subprocess"), default="persistent")
    parser.add_argument("--reasoning-effort", choices=("low", "medium", "high", "xhigh"), default="low")
    parser.add_argument("--enable-thinking", action="store_true")
    parser.add_argument("--require-composite", action="store_true", help="Fail instead of single-view fallback")
    parser.add_argument("--resume", action="store_true", help="Reuse valid DINO requests, skip completed Qwen reports")
    parser.add_argument("--limit", type=int, default=0, help="Smoke test first N samples")
    args = parser.parse_args()
    if args.max_new_tokens < 1 or args.limit < 0:
        parser.error("Token count must be positive; limit must be nonnegative")
    if args.qwen_mode == "subprocess" and (args.enable_thinking or args.reasoning_effort != "low"):
        parser.error("Thinking/effort controls require --qwen-mode persistent; original qwen_task1.py has no matching CLI options")
    if not Path(args.index_db).is_file():
        parser.error(f"Index does not exist: {args.index_db}")
    args.source_map_data = {}
    if args.source_map:
        args.source_map_data = json.loads(Path(args.source_map).read_text(encoding="utf-8-sig"))
        if (not isinstance(args.source_map_data, dict) or
                any(not isinstance(k, str) or not isinstance(v, str)
                    for k, v in args.source_map_data.items())):
            parser.error("--source-map must be a JSON object mapping names to source paths")
    entries = load_entries(Path(args.list), args.limit)
    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    summary_path = root / "batch_summary.json"
    print(f"Batch contains {len(entries)} samples. Qwen mode={args.qwen_mode}", flush=True)
    print("DINO and Qwen run in separate processes. DINO worker will close before Qwen starts.", flush=True)
    dino_prefix = python_prefix(args.dino_python, args.dino_conda_env, args.conda_exe)
    qwen_prefix = python_prefix(args.qwen_python, args.qwen_conda_env, args.conda_exe)
    worker_script = str(Path(__file__).resolve().with_name("sem_batch_worker.py"))
    rows = [{"index": i, "class": cls, "filename": filename, "status": "pending"}
            for i, (cls, filename) in enumerate(entries, 1)]
    needs_dino = []
    for row in rows:
        folder = root / f"{row['index']:03d}_{row['class']}"
        req_path = folder / "task1_request.json"
        report_path = folder / "qwen_report.json"
        if args.resume and req_path.is_file():
            try:
                req = json.loads(req_path.read_text(encoding="utf-8-sig"))
                valid = (req.get("status") == "prepared_from_real_files" and
                         Path(req.get("original_input", "")).is_file() and
                         sha256_file(Path(req["original_input"])) == req.get("original_sha256") and
                         bool(req.get("layer")) and isinstance(req.get("dino"), dict))
                if req.get("composite_image"):
                    valid &= Path(req["composite_image"]).is_file()
                if valid:
                    row["status"] = "prepared"
                    if report_path.is_file():
                        old = json.loads(report_path.read_text(encoding="utf-8-sig"))
                        if (old.get("status") in SUCCESS and
                            old.get("enable_thinking", False) == args.enable_thinking and
                            old.get("reasoning_effort", "low") == args.reasoning_effort):
                            # Recheck older invalid_format reports under the new 9-line
                            # convention without rerunning the GPU models.
                            previous = (old.get("status"), old.get("format_errors"), old.get("format_rule"))
                            validate_result(old, req["layer"])
                            if (old.get("status"), old.get("format_errors"), old.get("format_rule")) != previous:
                                save_json(report_path, old)
                            row["status"] = old["status"]
                            row["dino_candidate"] = req["dino"]["candidate"]
                            row["qwen_report"] = old.get("final", "")
                            row["format_errors"] = old.get("format_errors", [])
                    continue
            except Exception:
                pass
        needs_dino.append(row)
    if needs_dino:
        print(f"Stage 1: DINO once for {len(needs_dino)} samples", flush=True)
        command = dino_prefix + [worker_script, "--role", "dino", "--dino-script", args.dino_script,
                                 "--dino-model-dir", args.dino_model_dir, "--dino-head", args.dino_head,
                                 "--dino-device", args.dino_device]
        dino = Worker(command, root / "dino_worker_stderr.log", "DINO")
        try:
            for row in needs_dino:
                i, cls, filename = row["index"], row["class"], row["filename"]
                print(f"[DINO {i:02d}/{len(entries)}] {cls} {filename}", flush=True)
                try:
                    req = prepare_one(i, cls, filename, args, dino)
                    row["status"] = "prepared"
                    row["dino_candidate"] = req["dino"]["candidate"]
                    row["single_view_fallback"] = req["composite_image"] is None
                except Exception as exc:
                    row["status"] = "preparation_error"
                    row["error"] = str(exc)
                    save_json(root / f"{i:03d}_{cls}" / "pipeline_error.json",
                              {"status": "preparation_error", "error": str(exc), "traceback": traceback.format_exc()})
                    print(f"  ERROR: {exc}", flush=True)
                summarize(rows, summary_path, started)
        finally:
            dino.close()
    waiting = [row for row in rows if row["status"] == "prepared"]
    if not waiting:
        counts = summarize(rows, summary_path, started)
        print(f"No Qwen requests pending. Status: {dict(counts)}", flush=True)
        return
    print(f"Stage 2: Qwen ({args.qwen_mode}) for {len(waiting)} samples", flush=True)
    qwen = None
    if args.qwen_mode == "persistent":
        command = qwen_prefix + [worker_script, "--role", "qwen",
                                 "--qwen-model-dir", args.qwen_model_dir, "--prompt", args.prompt,
                                 "--reasoning-effort", args.reasoning_effort]
        if args.enable_thinking:
            command.append("--enable-thinking")
        qwen = Worker(command, root / "qwen_worker_stderr.log", "QWEN")
    try:
        for row in waiting:
            i, cls = row["index"], row["class"]
            folder = root / f"{i:03d}_{cls}"
            req_path = folder / "task1_request.json"
            print(f"[QWEN {i:02d}/{len(entries)}] {cls} {row['filename']}", flush=True)
            try:
                if qwen:
                    response = qwen.run({"id": i, "request": str(req_path),
                                         "max_new_tokens": args.max_new_tokens})
                    if not response.get("ok"):
                        raise RuntimeError(response.get("error", "Unknown Qwen error") + "\n" + response.get("traceback", ""))
                    result = response["result"]
                else:
                    result = baseline_qwen(req_path, folder, args, qwen_prefix)
                row["status"] = result["status"]
                row["dino_candidate"] = result.get("dino_candidate") or row.get("dino_candidate")
                row["qwen_report"] = result.get("final", "")
                row["format_errors"] = result.get("format_errors", [])
            except Exception as exc:
                result = {"status": "error", "error": str(exc), "traceback": traceback.format_exc()}
                row["status"] = "error"
                row["error"] = str(exc)
                print(f"  ERROR: {exc}", flush=True)
            save_json(folder / "qwen_report.json", result)
            (folder / "qwen_report.md").write_text(
                (result.get("final", "").strip() if result.get("status") in SUCCESS else "") + "\n",
                encoding="utf-8")
            counts = summarize(rows, summary_path, started)
            print(f"  status={row['status']} | counts={dict(counts)}", flush=True)
            if row["status"] == "error" and "Image features and image tokens do not match" in row.get("error", ""):
                print("FATAL: vision token mismatch in Qwen Python environment. "
                      "Compare with the Python/Conda environment of the proven single-image run. "
                      "Stopping to avoid 50 identical errors.", flush=True)
                break
    finally:
        if qwen:
            qwen.close()
    counts = summarize(rows, summary_path, started)
    print(f"Done in {time.perf_counter()-started:.1f}s. Status: {dict(counts)}", flush=True)
    print(f"Summary: {summary_path}", flush=True)


if __name__ == "__main__":
    main()