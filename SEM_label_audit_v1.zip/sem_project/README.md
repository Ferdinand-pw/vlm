# SEM机台类型可信度实验

请先阅读docs/机台类型可信度实验使用说明.md。
默认I02/I03/I04三视图，原标签保留，分数非概率。
快速演示：python scripts/evaluate/label_audit.py demo --output runs/demo_new
真实特征提取需要公司本地HF格式DINOv3 ViT与兼容GPU环境。
